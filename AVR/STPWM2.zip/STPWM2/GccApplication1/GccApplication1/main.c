/*
 * GccApplication1.c
 *
 * Created: 21.01.2016 8:36:20
 * Author : Михеенко Е
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

