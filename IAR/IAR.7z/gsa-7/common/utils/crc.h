//==============================================================================
//
//==============================================================================

#ifndef _CRC_H_
#define _CRC_H_

unsigned short CRC16 (unsigned char *nData, unsigned short wLength);

#endif // _CRC_H_
