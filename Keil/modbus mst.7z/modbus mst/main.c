//////////////






#include <LPC17xx.H>
#include <system_LPC17xx.h>
#include <lpc17xx_pinsel.h>
#include <lpc17xx_uart.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <lpc17xx_timer.h>
#include <port.h>
#include <mbcrc.h>
//#include <mb.h>
//#include <mb_port.h>


#define REG_INPUT_START 	1
#define REG_INPUT_NREGS 	4

#define	DE	LPC_GPIO0 -> FIOSET |= 0x6001E
#define RE	LPC_GPIO0 -> FIOCLR |= 0x6001E




static USHORT   usRegInputStart = REG_INPUT_START;
static USHORT   usRegInputBuf[REG_INPUT_NREGS];

typedef enum
{
    MB_ENOERR,                  /*!< no error. */
    MB_ENOREG,                  /*!< illegal register address. */
    MB_EINVAL,                  /*!< illegal argument. */
    MB_ETIMEDOUT                /*!< timeout error occurred. */
} ErrorCode;



uint8_t cmddata[6];



union Data
{
	uint8_t 	SLAVE_ADDR;
	uint8_t 	FUNC;
	uint16_t	START_REG_ADDR;
	uint16_t 	REG_NUM;
	uint16_t 	MBCRC16;
} DataPacket;




bool MBMCommand( uint8_t addr, uint8_t func, uint16_t reg_addr, uint16_t reg_num );
ErrorCode UART_SendData( uint8_t sendbyte);
ErrorCode	MBMasterRXHandle( union Data *lp, uint8_t byte);
void RxIntEnable( void );
void RxIntDisable( void );



void UART_Cfg( uint32_t baudrate);
void Port_Cfg( void );



int main( void )
{
	Port_Cfg();
	UART_Cfg(115200);
	
	__enable_irq();
	
	while(1)
	{
		
	};
	
}
	


void Port_Cfg( void )
{
	
	LPC_PINCON -> PINSEL0 |= (1 << 30);		//Tx P0.15
	LPC_PINCON -> PINSEL1 |= 1;						//Rx P0.16
	
};


void UART_Cfg( uint32_t baudrate)
{
	
	UART_CFG_Type		UART0CFGSTR;
	
	
	UART0CFGSTR.Baud_rate = baudrate;
	UART0CFGSTR.Databits = UART_DATABIT_8;
	UART0CFGSTR.Parity = UART_PARITY_NONE;
	UART0CFGSTR.Stopbits = UART_STOPBIT_1;
	
	
	UART_Init(LPC_UART0, &UART0CFGSTR);
	UART_TxCmd(LPC_UART0, ENABLE);
	
	
};


USHORT mbCRC16;
bool MBMCommand( uint8_t addr, uint8_t func, uint16_t reg_addr, uint16_t reg_num )
{
	

	
	DataPacket.SLAVE_ADDR = addr;
	DataPacket.FUNC = func;
	DataPacket.START_REG_ADDR = reg_addr;
	DataPacket.REG_NUM = reg_num;
	
	
	cmddata[0] = addr;
	cmddata[1] = func;
	cmddata[2] = reg_addr;
	cmddata[3] = reg_num;
	
	
	
	
	

	
	
	mbCRC16 = usMBCRC16( (UCHAR *)cmddata, 6 );
	
	
};


ErrorCode UART_SendData( uint8_t sendbyte)
{
	DE;
	for( int i =0; i <= sizeof(cmddata) / sizeof(cmddata[0]); i++)
	{
		
		UART_SendByte(LPC_UART0, cmddata[i]);
		Wait_UART();		
	};
	
	
	
};



void wait_UART( void )
{
	
	while(UART_CheckBusy(LPC_UART0) && SET){};
		bool busyflag == true;
	while(busyflag)
	{
		UART_CheckBusy
	}		
		
		
}



//eMBErrorCode
//eMBRegInputCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs )
//{
//    eMBErrorCode    eStatus = MB_ENOERR;
//    int             iRegIndex;

//    if( ( usAddress >= REG_INPUT_START )
//        && ( usAddress + usNRegs <= REG_INPUT_START + REG_INPUT_NREGS ) )
//    {
//        iRegIndex = ( int )( usAddress - usRegInputStart );
//        while( usNRegs > 0 )
//        {
//            *pucRegBuffer++ =
//                ( unsigned char )( usRegInputBuf[iRegIndex] >> 8 );
//            *pucRegBuffer++ =
//                ( unsigned char )( usRegInputBuf[iRegIndex] & 0xFF );
//            iRegIndex++;
//            usNRegs--;
//        }
//    }
//    else
//    {
//        eStatus = MB_ENOREG;
//    }

//    return eStatus;
//}

//eMBErrorCode
//eMBRegHoldingCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNRegs,
//                 eMBRegisterMode eMode )
//{
//    return MB_ENOREG;
//}


//eMBErrorCode
//eMBRegCoilsCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNCoils,
//               eMBRegisterMode eMode )
//{
//    return MB_ENOREG;
//}

//eMBErrorCode
//eMBRegDiscreteCB( UCHAR * pucRegBuffer, USHORT usAddress, USHORT usNDiscrete )
//{
//    return MB_ENOREG;
//}









