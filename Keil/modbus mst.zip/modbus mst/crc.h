


unsigned short CRC16 (unsigned char *nData, unsigned short wLength);