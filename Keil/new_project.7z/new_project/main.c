
//////rfm12b - 433s1  hoperf

#include <LPC17xx.H>
#include <system_LPC17xx.h>
#include <lpc17xx_pinsel.h>
//#include <lpc17xx_gpio.h>
//#include <lpc17xx_systick.h>
//#include <lpc17xx_uart.h> 
#include <lpc17xx_ssp.h>
//#include <lpc17xx_pwm.h>
//#include <stdbool.h>
//#include <stdlib.h>
//#include <stdint.h>
//#include <LPC17xx_timer.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
//#include <lpc17xx_spi.h>

#define SSP1		LPC_SSP1
#define SSP0		LPC_SSP0

#define DISPLAY_DATA			0xFA00
#define DISPLAY_CMD				0xF800
#define DISPLAY_ROWS_COUNT		2
#define DISPLAY_ROW_LEN			40

#define DISPROW1_HDR			"Read ADC:"

//static uint16_t m_DispRows[DISPLAY_ROWS_COUNT][DISPLAY_ROW_LEN];

void delay(uint32_t count);
uint8_t select_channel_adc(uint8_t channel);
#include <LPC17xx.H>
#include <system_LPC17xx.h>
#include <lpc17xx_pinsel.h>
//#include <lpc17xx_gpio.h>
//#include <lpc17xx_systick.h>
//#include <lpc17xx_uart.h>
#include <lpc17xx_ssp.h>
//#include <lpc17xx_pwm.h>
//#include <stdbool.h>
//#include <stdlib.h>
//#include <stdint.h>
//#include <LPC17xx_timer.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <lpc17xx_timer.h>



#define Rx_CS_ON			LPC_GPIO0 -> FIOCLR = (1 << 20);
#define Rx_CS_OFF			LPC_GPIO0 -> FIOSET = (1 << 20);	
#define Tx_CS_ON			LPC_GPIO0 -> FIOCLR = (1 << 3);
#define Tx_CS_OFF			LPC_GPIO0 -> FIOSET = (1 << 3);
void delay(uint32_t count);





void rfm_init_Tx( void );
void rfm_init_Rx( void );
void rfm_send(uint8_t output_byte);
void rfm_receive( void );
void wait_ssp_bsy( void );
void wait_nirq( void );


	SSP_CFG_Type SSPCFG;





uint16_t rByte;
uint16_t sByte;









typedef struct {

	uint16_t	CONF_SETTING_CMD;
	uint16_t 	POWER_MNG_CMD;
	uint16_t 	FREQ_SET_CMD;
	uint16_t 	DATA_RATE_CMD;
	uint16_t 	RECEIVER_CTRL_CMD;
	uint16_t 	DATA_FILTER_CMD;
	uint16_t 	FIFO_RESET_MODE_CMD;
	uint16_t 	SYNCHRON_PATTERN_CMD;
	uint16_t 	RECEIVER_FIFO_READ_CMD;
	uint16_t 	AFC_CMD;
	uint16_t 	TX_CFG_CTRL_CMD;
	uint16_t 	PLL_SETTING_CMD;
	uint16_t 	TRANSMITTER_REG_WRITE_CMD;
	uint16_t 	WAKEUP_TIMER_CMD;
	uint16_t 	LOW_DUTY_CYCLE_CMD;
	uint16_t	LOW_BAT_CLOCK_DIVIDER_CMD;
	uint16_t	STATUS_READ_CMD; 
	
	}	RFM12_INIT_TYPE;

RFM12_INIT_TYPE rm12_struct;





int main (){
	
	
	//LPC_SC -> PCONP |= ( 1 << 10 );

	LPC_PINCON -> PINSEL0 = 0xA8000;
	LPC_PINCON -> PINSEL0 |= 0x80000000;
//	LPC_PINCON -> PINSEL0 |= (1<<31);
	LPC_PINCON -> PINSEL1 |= 0x28;

	LPC_GPIO0 -> FIODIR |= (1 << 3)|(1 << 7)|(1 << 9);
	LPC_GPIO0 -> FIODIR |= (1 << 18)|(1<<15)|(1 << 20);
	



	
	Tx_CS_OFF;
	Rx_CS_OFF;

	delay(100);
	
	
	
	SSPCFG.Databit = SSP_DATABIT_16;
	SSPCFG.CPHA = SSP_CPHA_FIRST;
	SSPCFG.CPOL = SSP_CPOL_HI;
	SSPCFG.Mode = SSP_MASTER_MODE;
	SSPCFG.FrameFormat = SSP_FRAME_SPI;
	SSPCFG.ClockRate = 12000;
	
	
	
	SSP_Init(SSP1, &SSPCFG);
	SSP_Init(SSP0, &SSPCFG);
	

	SSP_Cmd(SSP1, ENABLE);
	SSP_Cmd(SSP0, ENABLE);
	
	__enable_irq();
	LPC_GPIOINT->IO0IntEnF |= (1 << 19);
//	LPC_GPIOINT->IO0IntEnR |= (1 << 19);
	NVIC_EnableIRQ(EINT3_IRQn);
		
		
#ifdef ENABLE_DISPLAY	
	
	ADC_CS_OFF
	delay(100);
	DISP_CS_ON
	
	
	delay(100);
	SSP_SendData(SSP1, 0xF80C);		//Disp On
	delay(100);	
	
	
	SSP_SendData(SSP1, 0xF828);		//Func_set
	delay(100);
	
	SSP_SendData(SSP1, clear);
	delay(100);
	
	
	SSP_SendData(SSP1, home);
	delay(10000);
	
		
		
#endif // ENABLE_DISPLAY

	
		

	sByte = 0x35;
	Tx_CS_ON;
	Rx_CS_ON;
	SysTick_Config(SystemCoreClock / 1000);
	rfm_init_Tx();
	rfm_init_Rx();
  while(1){

	Tx_CS_ON;
	Rx_CS_ON;
		
		
	rfm_send(sByte);
	
	delay(100);

	rfm_receive();	
		
	Tx_CS_OFF;
	Rx_CS_OFF;
	delay(10);	



		
}
	
}
void rfm_init_Tx( void )
{

//////writeCmd(0x80E7); //EL,EF,868band,12.0pF
//////writeCmd(0x8239); //!er,!ebb,ET,ES,EX,!eb,!ew,DC
//////writeCmd(0xA640); //frequency select
//////writeCmd(0xC647); //4.8kbps
//////writeCmd(0x94A0); //VDI,FAST,134kHz,0dBm,-103dBm
//////writeCmd(0xC2AC); //AL,!ml,DIG,DQD4
//////writeCmd(0xCA81); //FIFO8,SYNC,!ff,DR
//////writeCmd(0xCED4); //SYNC=2DD4 ,
//////AG
//////writeCmd(0xC483); //@PWR,NO RSTRIC,!st,!fi,OE,EN
//////writeCmd(0x9850); //!mp,90kHz,MAX OUT
//////writeCmd(0xCC17); //OB1 ,
//////ACOB0, LPX,Iddy,CDDIT,CBW0
//////writeCmd(0xE000); //NOT USED
//////writeCmd(0xC800); //NOT USED
//////writeCmd(0xC040); //1.66MHz,2.2V
	
	
	
	
	
	SSP_SendData(SSP1, 0x80D7);
	  wait_ssp_bsy();
	SSP_SendData(SSP1, 0x8239);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xA640);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xC647);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0x94A0);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xC2AC);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xCA11);  //0xCA81
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xCED4);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xC483);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0x9850);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xCC17);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xE000);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xC800);
		wait_ssp_bsy();
	SSP_SendData(SSP1, 0xC040);
		wait_ssp_bsy();

	
	
//////		SSP_SendData(SSP1, 0x80D8);
//////	  wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0x8239);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xA640);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xC647);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0x94A0);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xC2AC);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xCA81);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xCED4);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xC483);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0x9850);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xCC77);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xE000);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xC800);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP1, 0xC040);
//////		wait_ssp_bsy();
	
	
	
	
	
	//	rm12_struct.CONF_SETTING_CMD = 0x80D8;//EL,EF,433band,12.5pF
//	rm12_struct.POWER_MNG_CMD = 0x8239;//!er,!ebb,ET,ES,EX,!eb,!ew,DC
//	rm12_struct.FREQ_SET_CMD = 0xA640;//A140=430.8MHz
//	rm12_struct.DATA_RATE_CMD=(0xC647);//4.8kbps
//	rm12_struct.RECEIVER_CTRL_CMD=(0x94A0);//VDI,FAST,134kHz,0dBm,-103dBm
//	rm12_struct.DATA_FILTER_CMD=(0xC2AC);//AL,!ml,DIG,DQD4
//	rm12_struct.FIFO_RESET_MODE_CMD=(0xCA81);//FIFO8,SYNC,!ff,DR
//	rm12_struct.SYNCHRON_PATTERN_CMD=(0xCED4);//SYNC=2DD4;
//	rm12_struct.AFC_CMD=(0xC483);//@PWR,NO RSTRIC,!st,!fi,OE,EN       AFC
//	rm12_struct.TX_CFG_CTRL_CMD=(0x9850);//!mp,9810=30kHz,MAX OUT
//	rm12_struct.PLL_SETTING_CMD=(0xCC77);//OB1,OB0,!lpx,!ddy,DDIT,BW0
//	rm12_struct.WAKEUP_TIMER_CMD=(0xE000);//NOT USE
//	rm12_struct.LOW_DUTY_CYCLE_CMD=(0xC800);//NOT USE
//	rm12_struct.LOW_BAT_CLOCK_DIVIDER_CMD=(0xC040);//1.66MHz,2.2V 
	
	
	

}


void rfm_init_Rx( void )
{

////writeCmd(0x80E7); //EL,EF,868band,12.0pF
////writeCmd(0x8299); //er,!ebb,ET,ES,EX,!eb,!ew,DC (bug was here)
////writeCmd(0xA640); //freq select
////writeCmd(0xC647); //4.8kbps
////writeCmd(0x94A0); //VDI,FAST,134kHz,0dBm,-103dBm
////writeCmd(0xC2AC); //AL,!ml,DIG,DQD4
////writeCmd(0xCA81); //FIFO8,SYNC,!ff,DR (FIFO level = 8)
////writeCmd(0xCED4); //SYNC=2DD4;
////writeCmd(0xC483); //@PWR,NO RSTRIC,!st,!fi,OE,EN
////writeCmd(0x9850); //!mp,90kHz,MAX OUT
////writeCmd(0xCC17); //!OB1,!OB0, LPX,!ddy,DDIT,BW0
////writeCmd(0xE000); //NOT USE
////writeCmd(0xC800); //NOT USE
////writeCmd(0xC040); //1.66MHz,2.2V

	
	
	
	
	SSP_SendData(SSP0, 0x80D7);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0x8299);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xA640);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xC647);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0x94A0);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xC2AC);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xCA11);			//0xCA81
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xCED4);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xC483);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0x9850);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xCC17);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xE000);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xC800);
		wait_ssp_bsy();
	SSP_SendData(SSP0, 0xC040);
		wait_ssp_bsy();









//////	SSP_SendData(SSP0, 0x80D8);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0x8299);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xA640);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xC647);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0x94A0);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xC2AC);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xCA81);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xCED4);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xC483);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0x9850);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xCC77);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xE000);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xC800);
//////		wait_ssp_bsy();
//////	SSP_SendData(SSP0, 0xC040);
//////		wait_ssp_bsy();




}





void rfm_send(uint8_t output_byte)
{
	
	
	SSP_SendData(SSP1, 0x0000);
	for(int i = 0; i < 3; i++)
	{
		wait_nirq();
		SSP_SendData(SSP1, 0xB8AA);\
			//wait_ssp_bsy();
		//delay(100);
	};
	wait_nirq();
	SSP_SendData(SSP1, 0xB82D);
		//wait_ssp_bsy();
	//delay(100);
	wait_nirq();
	SSP_SendData(SSP1, 0xB8D4);
		//wait_ssp_bsy();
	//delay(100);
			
	float sByte = 0xB800 +  output_byte;
	wait_nirq();
	SSP_SendData(SSP1, sByte);
	//wait_ssp_bsy();


	//delay(100);
	
		for(int i = 0; i < 3; i++)
	{
		wait_nirq();
		SSP_SendData(SSP1, 0xB8AA);	
			//wait_ssp_bsy();		
		//delay(100);
	};
	
	//while( LPC_GPIO0 -> FIOPIN0 & (1 << 2));
	
	
}

void rfm_receive( void )
{
		//delay(100);
		//Tx_CS_OFF;
			wait_ssp_bsy();
		SSP_SendData(SSP0, 0x0000);
				
		rByte = SSP_ReceiveData(SSP0);


};



void delay(uint32_t count) 
{
	volatile uint32_t tmp = count;
	while((--tmp) != 0) {
	};
}
void SysTick_Handler(void) 
{
	




};


void EINT3_IRQHandler(void)
{
	rfm_receive();
	
};

void wait_ssp_bsy( void )
{
		while( SSP1 -> SR & (1 << 4)) {};
		while( SSP0 -> SR & (1 << 4)) {};
};


void wait_nirq( void )
{
		while (LPC_GPIO0 -> 	FIOPIN & (1 << 2));
		
};


