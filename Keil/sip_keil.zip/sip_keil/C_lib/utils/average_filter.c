//===========================================================================
//
//===========================================================================

#include "average_filter.h"
//#include "..\project.h"
#include "utils.h"

void uint_filter_init(lpIntFilterData_t lpFdata) {
	if(lpFdata == NULL)
		return;
	
	lpFdata->isFull = false;
	lpFdata->count = 0;
	lpFdata->wrIndex = 0;
	lpFdata->zIndex = 0;
	lpFdata->isInit = true;
}

void uint_filter_put(lpIntFilterData_t lpFdata, uint32_t data) {
	if(lpFdata == NULL)
		return;
	
	if(lpFdata->lpBuf == NULL)
		return;
	
	if(!lpFdata->isInit) {
		uint_filter_init(lpFdata);
	}
	
//	__istate_t intr = __get_interrupt_state();
//	__disable_interrupt();
	EnterCritSection(); //
	
	if(lpFdata->isFull) {
		lpFdata->lpBuf[lpFdata->wrIndex++] = data;
		lpFdata->zIndex++;
		if(lpFdata->wrIndex >= lpFdata->bufSize) {
			lpFdata->wrIndex = 0;
			lpFdata->zIndex = 0;
		}
	}
	else {
		lpFdata->lpBuf[lpFdata->wrIndex++] = data;
		lpFdata->count++;
		if(lpFdata->count >= lpFdata->bufSize) {
			lpFdata->isFull = true;
			lpFdata->wrIndex = 0;
		}
	}
	
	//__set_interrupt_state(intr);
	ExitCritSection(); //
}

uint32_t uint_filter_get(lpIntFilterData_t lpFdata) {
	if(lpFdata == NULL)
		return 0;
	
	if(lpFdata->lpBuf == NULL)
		return 0;
	
	if(!lpFdata->isInit)
		return 0;
	
	uint32_t result = 0;
	uint32_t zero = lpFdata->zIndex;
	uint32_t count = lpFdata->count;
	
	for(uint32_t i = 0, j = zero; i < count; i++, j++) {
		
		if(j >= lpFdata->bufSize)
			j = 0;
		
		result += lpFdata->lpBuf[j];
	}
	
	lpFdata->value = result / count;
	
	return lpFdata->value;
}

void float_filter_init(lpFloatFilterData_t lpFdata) {
	if(lpFdata == NULL)
		return;
	
	lpFdata->isFull = false;
	lpFdata->count = 0;
	lpFdata->wrIndex = 0;
	lpFdata->zIndex = 0;
	lpFdata->isInit = true;
}

void float_filter_put(lpFloatFilterData_t lpFdata, float data) {
	if(lpFdata == NULL)
		return;
	
	if(lpFdata->lpBuf == NULL)
		return;
	
	if(!lpFdata->isInit) {
		float_filter_init(lpFdata);
	}
	
//	__istate_t intr = __get_interrupt_state();
//	__disable_interrupt();
	EnterCritSection(); //
	
	if(lpFdata->isFull) {
		lpFdata->lpBuf[lpFdata->wrIndex++] = data;
		lpFdata->zIndex++;
		if(lpFdata->wrIndex >= lpFdata->bufSize) {
			lpFdata->wrIndex = 0;
			lpFdata->zIndex = 0;
		}
	}
	else {
		lpFdata->lpBuf[lpFdata->wrIndex++] = data;
		lpFdata->count++;
		if(lpFdata->count >= lpFdata->bufSize) {
			lpFdata->isFull = true;
			lpFdata->wrIndex = 0;
		}
	}
	
	//__set_interrupt_state(intr);
	ExitCritSection(); //
}

float float_filter_get(lpFloatFilterData_t lpFdata) {
	if(lpFdata == NULL)
		return 0;
	
	if(lpFdata->lpBuf == NULL)
		return 0;
	
	if(!lpFdata->isInit)
		return 0;
	
	float result = 0;
	uint32_t zero = lpFdata->zIndex;
	uint32_t count = lpFdata->count;
	
	for(uint32_t i = 0, j = zero; i < count; i++, j++) {
		
		if(j >= lpFdata->bufSize)
			j = 0;
		
		result += lpFdata->lpBuf[j];
	}
	
	lpFdata->value = result / ((float)count);
	
	return lpFdata->value;
}

void ushort_filter_init(lpUshortFilterData_t lpFdata) {
	if(lpFdata == NULL)
		return;
	
	lpFdata->isFull = false;
	lpFdata->count = 0;
	lpFdata->wrIndex = 0;
	lpFdata->zIndex = 0;
	lpFdata->isInit = true;
}

void ushort_filter_put(lpUshortFilterData_t lpFdata, uint16_t data) {
	if(lpFdata == NULL)
		return;
	
	if(lpFdata->lpBuf == NULL)
		return;
	
	if(!lpFdata->isInit) {
		ushort_filter_init(lpFdata);
	}
	
	EnterCritSection(); //
	
	if(lpFdata->isFull) {
		lpFdata->lpBuf[lpFdata->wrIndex++] = data;
		lpFdata->zIndex++;
		if(lpFdata->wrIndex >= lpFdata->bufSize) {
			lpFdata->wrIndex = 0;
			lpFdata->zIndex = 0;
		}
	}
	else {
		lpFdata->lpBuf[lpFdata->wrIndex++] = data;
		lpFdata->count++;
		if(lpFdata->count >= lpFdata->bufSize) {
			lpFdata->isFull = true;
			lpFdata->wrIndex = 0;
		}
	}
	
	ExitCritSection(); //
}

uint16_t ushort_filter_get(lpUshortFilterData_t lpFdata) {
	if(lpFdata == NULL)
		return 0;
	
	if(lpFdata->lpBuf == NULL)
		return 0;
	
	if(!lpFdata->isInit)
		return 0;
	
	uint32_t result = 0;
	uint32_t zero = lpFdata->zIndex;
	uint32_t count = lpFdata->count;
	
	for(uint32_t i = 0, j = zero; i < count; i++, j++) {
		
		if(j >= lpFdata->bufSize)
			j = 0;
		
		result += lpFdata->lpBuf[j];
	}
	
	lpFdata->value = (uint16_t)(result / count);
	
	return lpFdata->value;
}
