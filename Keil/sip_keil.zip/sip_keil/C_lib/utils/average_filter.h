//===========================================================================
//
//===========================================================================

#ifndef _AVERAGEFILTER_H_
#define _AVERAGEFILTER_H_

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <float.h>

typedef struct { // UIntFilterData_t
	uint32_t *lpBuf;
	uint32_t bufSize;
	uint32_t count;
	uint32_t wrIndex;
	uint32_t zIndex;
	
	uint32_t value;
	
	bool isFull;
	bool isInit;
} UIntFilterData_t, *lpIntFilterData_t;

typedef struct { // FloatFilterData_t
	float *lpBuf;
	uint32_t bufSize;
	uint32_t count;
	uint32_t wrIndex;
	uint32_t zIndex;
	
	float value;
	
	bool isFull;
	bool isInit;
} FloatFilterData_t, *lpFloatFilterData_t;

typedef struct { // UshortFilterData_t
	uint16_t *lpBuf;
	uint32_t bufSize;
	uint32_t count;
	uint32_t wrIndex;
	uint32_t zIndex;
	
	uint16_t value;
	
	bool isFull;
	bool isInit;
} UshortFilterData_t, *lpUshortFilterData_t;

//-----------------------------------------------------------------------------
// UInt average filter
void uint_filter_init(lpIntFilterData_t lpFdata);

void uint_filter_put(lpIntFilterData_t lpFdata, uint32_t data);

uint32_t uint_filter_get(lpIntFilterData_t lpFdata);

//-----------------------------------------------------------------------------
// Float average filter
void float_filter_init(lpFloatFilterData_t lpFdata);

void float_filter_put(lpFloatFilterData_t lpFdata, float data);

float float_filter_get(lpFloatFilterData_t lpFdata);

//-----------------------------------------------------------------------------
// Ushort average filter
void ushort_filter_init(lpUshortFilterData_t lpFdata);

void ushort_filter_put(lpUshortFilterData_t lpFdata, uint16_t data);

uint16_t ushort_filter_get(lpUshortFilterData_t lpFdata);
//-----------------------------------------------------------------------------

#endif // _AVERAGEFILTER_H_
