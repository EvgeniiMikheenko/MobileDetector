//=============================================================================
//						        soft_pwm.c
//=============================================================================

#include "soft_pwm.h"
#include <stdint.h>

static __inline uint32_t PercentageToTicks(uint8_t duty, uint32_t period) {
	if(duty == 0)
		return 0;
	
	if(duty >= 100)
		return period;
	
	return (period / 100) * duty;
}

bool SoftPwmInit(lpSwPwmData_t lpData, uint32_t period, PWMSetValue lpFunc) {
	if(lpData == NULL)
		return false;
	//
	lpData->Period = period;
	lpData->Duty = 0;
	lpData->DutyNew = 0;
	lpData->Counter = 0;
	lpData->DutyTicks = 0;
	lpData->Value = false;
	lpData->lpSetValueFunc = lpFunc;
	//
	return true;
}

bool SoftPwmPoll(lpSwPwmData_t lpData) {
	if(lpData == NULL)
		return false;
	//
	if(lpData->Duty == 0) {
		lpData->Duty = lpData->DutyNew;
		lpData->Value = false;
		lpData->Counter = 0;
		
		if(lpData->lpSetValueFunc != NULL) {
			lpData->lpSetValueFunc(lpData->Value);
		}
		
		return lpData->Value;
	}
	
	if(lpData->Duty >= 100) { 
		lpData->Duty = lpData->DutyNew;
		lpData->Value = true;
		lpData->Counter = 0;
		
		if(lpData->lpSetValueFunc != NULL) {
			lpData->lpSetValueFunc(lpData->Value);
		}
		
		return lpData->Value;
	}
	
	lpData->Counter++;
	
	if(lpData->Counter >= lpData->Period) {
		lpData->Counter = 0;
		lpData->Duty = lpData->DutyNew;
		
		if(lpData->Duty == 0) {
			lpData->Value = false;
		}
		else {
			lpData->Value = true;
		}
		
		if(lpData->lpSetValueFunc != NULL) {
			lpData->lpSetValueFunc(lpData->Value);
		}
		return lpData->Value;
	}
	
	lpData->DutyTicks = PercentageToTicks(lpData->Duty, lpData->Period);
	
	if(lpData->DutyTicks >= lpData->Counter) {
		lpData->Value = true;
	}
	else {
		lpData->Value = false;
	}
	
	if(lpData->lpSetValueFunc != NULL) {
		lpData->lpSetValueFunc(lpData->Value);
	}
	
	return lpData->Value;
}
