//=============================================================================
//						        soft_pwm.h
//=============================================================================

#ifndef _SOFT_PWM_H_
#define _SOFT_PWM_H_

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

typedef void (*PWMSetValue)(bool value);

typedef struct {
	uint32_t 	Period;
	uint8_t 	Duty;
	uint8_t		DutyNew;
	uint32_t 	Counter;
	uint32_t	DutyTicks;
	bool 		Value;
	PWMSetValue lpSetValueFunc;
} SwPwmData_t, *lpSwPwmData_t;

bool SoftPwmInit(lpSwPwmData_t lpData, uint32_t period, PWMSetValue lpFunc);

bool SoftPwmPoll(lpSwPwmData_t lpData);

#endif // _SOFT_PWM_H_
