//=============================================================================
//
//=============================================================================

#include "ton_timer.h"

extern uint32_t GetSystemTime(void);

void ton_timer_init(lpTonTimerData_t lpData) {
	if(lpData == NULL)
		return;
	
	lpData->startTime = GetSystemTime();
	lpData->enable = false;
	lpData->outValue = false;
}

void ton_timer_reset(lpTonTimerData_t lpData) {
	if(lpData == NULL)
		return;
	
	lpData->startTime = GetSystemTime();
	lpData->enable = false;
	lpData->outValue = false;
}

bool ton_timer_run(lpTonTimerData_t lpData, uint32_t interval, bool enable) {
	uint32_t time;
	
	if(lpData == NULL)
		return false;
	
	if(enable && (!lpData->enable)) {
		lpData->startTime = GetSystemTime();
	}
	
	lpData->enable = enable;
	lpData->interval = interval;
	
	if(!lpData->enable) {
		lpData->outValue = false;
		lpData->startTime = GetSystemTime();
		return false;
	}
	
	time = GetSystemTime() - lpData->startTime;
	
	if(lpData->outValue)
		return true;
	
	if(time >= lpData->interval) {
		lpData->outValue = true;
	}
	
	return lpData->outValue;
}

uint32_t ton_timer_get_time_remaining(lpTonTimerData_t lpData, uint32_t interval) {
	if(lpData == NULL)
		return 0;
	
	if((!lpData->enable)) {
		return interval;
	}
	//
	if(lpData->outValue)
		return 0;
	//
	uint32_t time = GetSystemTime() - lpData->startTime;
	return lpData->interval - time;
}

void on_off_filter_init(lpOnOffFilterData_t lpData, uint32_t onTime, uint32_t offTime) {
	if(lpData == NULL)
		return;
	
	if(lpData->isInit) {
		return;
	}
	
	lpData->isFirstStart = true;
	lpData->outValue = false;
	
	lpData->onInterval = onTime;
	lpData->onStartTime = GetSystemTime();
	
	lpData->offInterval = offTime;
	lpData->offStartTime = GetSystemTime();
	
	lpData->isInit = true;
	lpData->enable = false;
}

bool on_off_filter_run(lpOnOffFilterData_t lpData, bool enable, uint32_t onTime, uint32_t offTime) {
	uint32_t time;
	
	if(lpData == NULL)
		return false;
	
	lpData->enable = enable;
	
	if(!lpData->isInit) {
		on_off_filter_init(lpData, onTime, offTime);
		lpData->isFirstStart = false;
	}
	
	lpData->onInterval = onTime;
	lpData->offInterval = offTime;
	
	if(lpData->outValue) {
		// ������� ��������� : ���
		
		if(enable) {
			// newState = enable
			lpData->offStartTime = GetSystemTime();
			return lpData->outValue;
		}
		
		// newState = disable
		time = GetSystemTime();
		
		if((time - lpData->offStartTime) >= lpData->offInterval) {
			// ����� OFF ������� - ���������
			lpData->outValue = false;
			// ���������� ����� ������� ���������
			lpData->onStartTime = time;
		}
		
		return lpData->outValue;
	}
	
	// ������� ��������� : ����
	time = GetSystemTime();
	
	if(!enable) {
		// ON reset
		lpData->onStartTime = time;
		// OFF reset
		lpData->offStartTime = time;
		
		return lpData->outValue;
	}
	
	// newState = enable
	
	if((time - lpData->onStartTime) >= lpData->onInterval) {
		// ����� ON ������� - ��������
		lpData->outValue = true;
		// ���������� ����� ������� ���������
		lpData->offStartTime = time;
	}
	
	return lpData->outValue;
}

void on_off_filter_reset(lpOnOffFilterData_t lpData) {
	if(lpData == NULL)
		return;
	
	lpData->isInit = false;
}
