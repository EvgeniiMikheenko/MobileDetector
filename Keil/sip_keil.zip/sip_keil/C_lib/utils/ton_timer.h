//=============================================================================
//
//=============================================================================

#ifndef _TON_TIMER_H_
#define _TON_TIMER_H_

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct {
	uint32_t startTime;
	uint32_t interval;
	bool enable;
	bool outValue;
} TonTimerData_t, *lpTonTimerData_t;

typedef struct {
	bool isFirstStart;
	bool outValue;
	bool isInit;
	bool enable;
	
	uint32_t onInterval;
	uint32_t onStartTime;
	
	uint32_t offInterval;
	uint32_t offStartTime;
	
} OnOffFilterData_t, *lpOnOffFilterData_t;

void ton_timer_init(lpTonTimerData_t lpData);

void ton_timer_reset(lpTonTimerData_t lpData);

bool ton_timer_run(lpTonTimerData_t lpData, uint32_t interval, bool enable);

uint32_t ton_timer_get_time_remaining(lpTonTimerData_t lpData, uint32_t interval);

void on_off_filter_init(lpOnOffFilterData_t lpData, uint32_t onTime, uint32_t offTime);

bool on_off_filter_run(lpOnOffFilterData_t lpData, bool enable, uint32_t onTime, uint32_t offTime);

void on_off_filter_reset(lpOnOffFilterData_t lpData);

#endif // _TON_TIMER_H_
