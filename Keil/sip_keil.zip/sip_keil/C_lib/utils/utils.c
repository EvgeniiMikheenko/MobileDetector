//=============================================================================
//								utils.c
//=============================================================================
//#include "..\project.h"
#include "utils.h"


static volatile int CriticalSecCntr = 0;

int EnterCritSection(void) {
	if(CriticalSecCntr == 0) {
		
		__disable_interrupt(); //asm("CPSID i");
	}
	// avoid lost of one count in case of simultaneously calling from both places
	++CriticalSecCntr;
	return 1;
}

int ExitCritSection(void) {
	if(--CriticalSecCntr == 0) {
		__enable_interrupt();// asm("CPSIE i");
	}
	return 0;
}
