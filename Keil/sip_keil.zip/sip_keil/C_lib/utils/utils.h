//=============================================================================
//								utils.h
//=============================================================================

#ifndef _UTILS_H_
#define _UTILS_H_

#ifdef __cplusplus
	extern "C" {
#endif

#include <stdint.h>
#include <LPC17xx.h> 

#ifdef __IAR_SYSTEMS_ICC__
	#include <intrinsics.h>
#else

	#define __disable_interrupt __disable_irq
	#define __enable_interrupt __enable_irq
	//
	typedef uint32_t __istate_t;

	#define __get_interrupt_state __get_PRIMASK

	#define __set_interrupt_state __set_PRIMASK
	//
#endif

//-----------------------------------------------------------------------------
inline static int _irqDis(void)
{
    __disable_interrupt();//__ASM volatile ("cpsid i" : : : "memory");
    return 1;
}

inline static int _irqEn(void)
{
    __enable_interrupt();//__ASM volatile ("cpsie i" : : : "memory");
    return 0;
}

#define ATOMIC_BLOCK_FORCEON \
    for(int flag = _irqDis(); flag; flag = _irqEn())
//-----------------------------------------------------------------------------	

inline static __istate_t _iDisGetPrimask(void)
{
    __istate_t result;
    result = __get_interrupt_state(); //__ASM volatile ("MRS %0, primask" : "=r" (result) );
    __disable_interrupt();// __ASM volatile ("cpsid i" : : : "memory");
    return result;
}

inline static __istate_t _iSetPrimask(__istate_t priMask)
{
    __set_interrupt_state(priMask); //__ASM volatile ("MSR primask, %0" : : "r" (priMask) : "memory");
    return 0;
}

#define ATOMIC_BLOCK_RESTORATE \
     for(__istate_t mask = _iDisGetPrimask(), flag = 1; flag; flag = _iSetPrimask(mask))
//-----------------------------------------------------------------------------

inline static int _irqDisCond(int flag)
{
    if (flag)
        __disable_interrupt();// __ASM volatile ("cpsid i" : : : "memory");
    return 1;
}

inline static int _irqEnCond(int flag)
{
    if (flag)
        __enable_interrupt();// __ASM volatile ("cpsie i" : : : "memory");
    return 0;
}

#define ATOMIC_BLOCK_FORCEON_COND(condition) \
    for(int cond = condition, flag = __irqDisCond(cond); flag; flag = _irqEnCond(cond))
//-----------------------------------------------------------------------------

static __inline __istate_t _irqDisGetPrimaskCond(int flag)
{
	__istate_t result = 0;
    if (flag)
    {
        
        result = __get_interrupt_state(); //__ASM volatile ("MRS %0, primask" : "=r" (result) );
        __disable_interrupt();// __ASM volatile ("cpsid i" : : : "memory");
    }
    
	return result;
}

static __inline __istate_t _irqSetPrimaskCond(int priMask)
{
    __set_interrupt_state(priMask); //__ASM volatile ("MSR primask, %0" : : "r" (priMask) : "memory");
    return 0;
}

#define ATOMIC_BLOCK_RESTORATE_COND(condition) \
    for(__istate_t cond = condition, mask = _irqDisGetPrimaskCond(cond), flag = 1; flag; flag = cond ? _irqSetPrimaskCond(mask) : 0)
//-----------------------------------------------------------------------------

int EnterCritSection(void);
int ExitCritSection(void);

#define CRITICAL_SECTION() \
	for(int flag = EnterCritSection(); flag; flag = ExitCritSection())

#ifdef __cplusplus
	}
#endif

#endif // _UTILS_H_
