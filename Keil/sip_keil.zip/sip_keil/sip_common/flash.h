
#ifndef flash_h
#define flash_h
#define OSCILLATOR_CLOCK_FREQUENCY 4000000   
#define CPU_FREQ  (OSCILLATOR_CLOCK_FREQUENCY*25)
void ParamDataRestore(void);
unsigned ParamDataStore(void);
int FlashStore(void*addr);
unsigned long  __inline GetFlashData(int i);
//#define FLASH_LOCATION 0x18000
#define FLASH_LOCATION 0x78000
//#define FLASH_SECTOR 7 // LPC2131 Seven Sector
//#define FLASH_SECTOR 10// LPC2364 Ten Sector
#define FLASH_SECTOR 29// LPC2364 Ten Sector
#endif
