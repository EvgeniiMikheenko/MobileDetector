//=============================================================================
//
//=============================================================================

#ifndef _FPGA_H_
#define _FPGA_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

int FPGA_Load(void);

#endif // _FPGA_H_
