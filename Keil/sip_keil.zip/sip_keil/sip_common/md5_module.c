//=============================================================================
//
//=============================================================================

#include "md5_module.h"
#include <ton_timer.h>
#include <utils.h>
#include <crc16.h>
#include "flash.h"
#include "project.h"
#include "host.h"

#ifdef _USE_SIP1_DEVICE_
	#include "hub.h"
#endif // _USE_SIP1_DEVICE_

MD5_CTX MD5context;
unsigned char MD5digest[16];

extern Params_Struct Params;
extern Params_Struct * Flash_Params;

void calc_md5(void) {
	MD5Init(&MD5context);
	MD5Update(&MD5context, 0, 524288);
	MD5Final((unsigned char*)MD5digest, &MD5context);
}

void check_md5 (void) {
	//
	static TonTimerData_t updTmrData;
	
	bool en = (Params.FPGA_OUT.FPGA_Flags & SAVE_TO_FLASH_FLAG || (Flash_Params->CPU_IN.Substance != Params.CPU_OUT.Substance));
	
	if(!ton_timer_run(&updTmrData, 500, en)) {
		return;
	}
	
	ton_timer_reset(&updTmrData);
	
	//if (en)
	//{
#ifdef _USE_SIP1_DEVICE_
		hub_heater_off();
#endif // _USE_SIP1_DEVICE_

		Params.CPU_IN.Substance = Params.CPU_OUT.Substance;
		Params.CRC = CalcCrc16((unsigned char *) & Params, FLASH_SIZE);

		if (Params.CRC != Flash_Params->CRC) {

			EnterCritSection();
			
			FlashStore(& Params);
			MD5Init(&MD5context);
			MD5Update(&MD5context, 0, 524288);
			MD5Final((unsigned char*)MD5digest,&MD5context);
			// Reset modbus
			host_reset();
			
			ExitCritSection();
		}
		
	//}
}
