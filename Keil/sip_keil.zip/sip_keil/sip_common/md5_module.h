//=============================================================================
//
//=============================================================================

#ifndef _MD5_MODULE_H_
#define _MD5_MODULE_H_

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <md5.h>

extern MD5_CTX MD5context;
extern unsigned char MD5digest[];

void check_md5 (void);

void calc_md5(void);

#endif // _MD5_MODULE_H_
