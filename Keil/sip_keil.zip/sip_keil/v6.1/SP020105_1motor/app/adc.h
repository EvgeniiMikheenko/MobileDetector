//=============================================================================
//							adc.h
//=============================================================================

#ifndef _ADC_H_
#define _ADC_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "project.h"
#include "board.h"

#define ADC_BUF_SIZE 				32
#define ADC_BUF_LOW 				8
#define ADC_BUF_HIGH 				24
#define ADC_CHANNEL_COUNT 			8

#define ADC_FAIL_COUNT  			1000

extern int adc_channel;
extern ADC_Data_Struct 				ADC_Data[];

#define Temp1_Camera_ADC 			ADC_Data[3].Data
#define Temp2_Camera_ADC 			ADC_Data[DIP_REPAIR ? 3 : 6].Data
#define Flow2_ADC        			ADC_Data[4].Data
#define Flow1_ADC        			ADC_Data[0].Data
#define AirPressure_ADC  			ADC_Data[1].Data
#define Temp_Case_ADC    			ADC_Data[7].Data
#define Humidity_ADC     			ADC_Data[2].Data

extern unsigned short int 			ADC_Buf[][ADC_BUF_SIZE];
extern unsigned short int 			ADC_BufSort[][ADC_BUF_SIZE];

unsigned int Read_ADC(void);
float ADC_Temp(unsigned ADC);
float ADC_Temp_Case(unsigned ADC);
float ADC_Pressure(unsigned ADC);
float ADC_Humidity(unsigned ADC);
float ADC_Flow(unsigned ADC);

void init_adc_data(void);



#endif // _ADC_H_
