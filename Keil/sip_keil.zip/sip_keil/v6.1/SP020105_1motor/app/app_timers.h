//=============================================================================
//								app_timers.h
//=============================================================================

#ifndef _APP_TIMERS_H_
#define _APP_TIMERS_H_

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "project.h"

#include "utils/ton_timer.h"

static const int OnOffTimersCount = 13;

#define FLOW_ERROR_ON_TIME			180000 /* = 3 ������ ( 3 * 60 * 1000) */
#define FLOW_ERROR_OFF_TIME			 60000 /* = 1 ������ ( 1 * 60 * 1000) */

typedef enum {
	TimerIndexFlowOutOfRange 		= 0,
	TimerIndexAlarmEnable 			= 1,
	TimerIndexSetHV 				= 2,
	TimerIndexFlowStable 			= 3,
	TimerIndexTemp1Stable 			= 4,
	TimerIndexLockAlarm 			= 5,
	TimerIndexDeviceAlarmOff 		= 6,
	TimerIndexZone1Found 			= 7,
	TimerIndexZone2Found 			= 8,
	TimerIndexZone3Found 			= 9,
	TimerIndexZone4Found 			= 10,
	TimerIndexFlowError 			= 11,
	TimerIndexModeOkResetDisable 	= 12
} AppTimerIndexes;

bool run_on_off_timer(uint8_t num, bool en, uint32_t onTime, uint32_t offTime);

bool get_timer_value(uint8_t num);

bool get_timer_is_enable(uint8_t num);

void reset_on_off_timer(uint8_t num);

static bool get_alarm_status(void) { return get_timer_value(TimerIndexAlarmEnable);}

static bool run_flow_error_timer(bool en) { 
	return run_on_off_timer(TimerIndexFlowError, en, FLOW_ERROR_ON_TIME, FLOW_ERROR_OFF_TIME); 
}

static bool get_flow_error_timer_status() { return get_timer_value(TimerIndexFlowError); }

#endif // _APP_TIMERS_H_
