//=============================================================================
//									buttons.c
//=============================================================================

#include "buttons.h"

extern Params_Struct Params;

int buttons 				= 0;
int buttons_prev 			= 0;
int buttons_time 			= 0;
int button_pressed 			= 0;
uint16_t but_test 			= 0;

#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_
	int kostyl 					= 0;
#endif

void button_poll(void) {
	buttons_prev = buttons;
	buttons = LPC_GPIO1->FIOPIN & (BUTTON1_MASK + BUTTON2_MASK + BUTTON3_MASK + BUTTONP_MASK);

	if ((buttons == buttons_prev) && (buttons != 0x0)) {
		
		if(buttons_time < BUTTONS_COUNTER_MAX)
			buttons_time++;
		
		if (buttons_time >= BUTTONS_PRESS_TIME) {
			button_pressed = 1;
		}
	}
	else {
		buttons_time = 0;
		button_pressed = 0;
	}
}
