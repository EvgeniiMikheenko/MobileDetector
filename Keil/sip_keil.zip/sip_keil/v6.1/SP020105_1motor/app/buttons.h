//=============================================================================
//									buttons.h
//=============================================================================

#ifndef _BUTTON_H_
#define _BUTTON_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "board.h"
#include "project.h"

int button_proc(int display_mode);

void button_poll(void);

#endif // _BUTTON_H_
