//=============================================================================
//								flow_total.c
//=============================================================================

#include "flow_total.h"
#include "pid/pid.h"
#include "utils/ton_timer.h"

#ifndef USE_FIXED_TOTAL_FLOW

extern Params_Struct Params;
extern Flags_t m_flags;
extern bool m_isStarted;

extern bool CheckReperData(void);
extern bool IsManualMode(void);


static float GetFlowTotalSp(void);
float GetFlowTotalPv(void);
void SetFlowTotalPwm(float value);

PidData_t m_flowTotalPidData =  {		
	0.5, //float kP;
	0.35, //float kI;
	0.01, //float kD;
	
	1000, //float pvMax;
	-1000, //float pvMin;
	
	PWM1_CYCLES_COUNT, // float outMax;
	-PWM1_CYCLES_COUNT, //float outMin;
	
	false, //float outValue;
	
	0, //uint32_t lastTime;
	0.0, //float lastPv;
	0.0, //float errSum;
	
	false, //bool enable;
	false, //bool isInit;
	false, //bool isStarted;
	false, //bool isIntegralCorrectorEn;
	
	0.0, //float pValue;
	0.0, //float iValue;
	0.0, //float dValue;
	
	GetFlowTotalPv, //GetFloat lpGetPv;
	GetFlowTotalSp, //GetFloat lpGetSp;
	
	SetFlowTotalPwm //SetFloat lpSetOutput;
};

void flow_total_set__pid_enable(bool en) {
	if(en) {
		pid_enable(&m_flowTotalPidData);
		return;
	}
	
	pid_disable(&m_flowTotalPidData);
}

void flow_total_pid_poll(void) {
	static TonTimerData_t flowTotalTimerData;
	
	if(!ton_timer_run(&flowTotalTimerData, 10, true))
		return;
	
	ton_timer_reset(&flowTotalTimerData);
	pid_poll(&m_flowTotalPidData);
}

void flow_total_set_pid_factors(void) {
	m_flowTotalPidData.kP = Params.Config.FlowTotalPidFactors.kP.value;
	m_flowTotalPidData.kI = Params.Config.FlowTotalPidFactors.kI.value;
	m_flowTotalPidData.kD = Params.Config.FlowTotalPidFactors.kD.value;
}

void flow_total_update_pid_data(void) {
	Params.FlowTotalPidData.pValue.value = m_flowTotalPidData.pValue;
	Params.FlowTotalPidData.iValue.value = m_flowTotalPidData.iValue;
	Params.FlowTotalPidData.dValue.value = m_flowTotalPidData.dValue;
	Params.FlowTotalPidData.errSumm.value = m_flowTotalPidData.errSum;
	Params.FlowTotalPidData.outValue.value = m_flowTotalPidData.outValue;
}

uint16_t flow_total_get_power_value(void) {
	return (uint16_t)m_flowTotalPidData.outValue;
}

void SetFlowTotalPwm(float value) {
	
	if(value < 0)
		value = 0;
	
#if PUMP_MODE == INVERSION_PUMP_MODE
	Board_SetPumpTotalDuty((uint32_t)PWM1_CYCLES_COUNT - value);
#else
	Board_SetPumpTotalDuty((uint32_t)value);
#endif
}

float GetFlowTotalPv(void) { 
	return (float)Params.CPU_OUT.Flow_Total / 10.0; 
}

static float GetFlowTotalSp(void) { 
	if((!m_isStarted) || (Params.CPU_OUT.Device_Mode == 0) || ((m_flags.IsTemp1Stable == 0) && (m_flags.IsModeOk == 0)) ||
		((!CheckReperData()) && (!IsManualMode()))) {
		return FLOW_SP_MAX;
	}
		
	return (float)Params.CPU_IN.Flow_Total_Setpoint / 10.0; 
}

#endif // USE_FIXED_TOTAL_FLOW
