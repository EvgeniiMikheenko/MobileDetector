//=============================================================================
//
//=============================================================================

#include "fpga.h"
#include "board.h"

extern const char image[];

int FPGA_Load(void)
{
	int i = 0, j = 0;
	Board_ClrFpgaNConfig();
	while (FPGA_NSTATUS != 0)
	{
		if (i++ == 1000000)
			return 0;
	}

	Board_SetFpgaNConfig();
	i = 0;
	while (FPGA_NSTATUS == 0)
	{
		if (i++ == 1000000)
			return 0;
	}
	for (i = 0; i < 200000; i++)
	{
		for (j = 0; j < 8; j++)
		{
			if ((image[i] >> j) & 1)
				Board_SetFpgaData0();
			else
				Board_ClrFpgaData0();
				Board_SetFpgaDclk();
				Board_SetFpgaDclk();
				Board_ClrFpgaDclk();
				Board_ClrFpgaDclk();
		}
	if (FPGA_CONF_DONE)
		return 1;
	}
	return 0;
}
