//=============================================================================
//									heater1.c
//=============================================================================

#include "heater1.h"
#include "utils/soft_pwm.h"
#include "pid/pid.h"

extern Params_Struct Params;

extern uint32_t GetSystemTime(void);

//-----------------------------------------------------------------------------
// 
static void 	set_heater1_pwm_value(bool value);
static void 	SetHeater1Pwm(float value);
//
//-----------------------------------------------------------------------------

SwPwmData_t m_Heater1PwmData = {
	1000,
	0,
	0,
	0,
	0,
	false,
	set_heater1_pwm_value
};

PidData_t m_heater1PidData =  {		
	20.0, //float kP;
	0.03, //float kI;
	0.075, //float kD;
	
	200, //float pvMax;
	-100, //float pvMin;
	
	1000, // float outMax;
	-1000, //float outMin;
	
	false, //float outValue;
	
	0, //uint32_t lastTime;
	0.0, //float lastPv;
	0.0, //float errSum;
	
	false, //bool enable;
	false, //bool isInit;
	false, //bool isStarted;
	true, //bool isIntegralCorrectorEn;
	
	0.0, //float pValue;
	0.0, //float iValue;
	0.0, //float dValue;
	
	GetTemp1Pv, //GetFloat lpGetPv;
	GetTemp1Sp, //GetFloat lpGetSp;
	
	SetHeater1Pwm //SetFloat lpSetOutput;
};

void heater1_init(void) {
	pid_init_data(&m_heater1PidData);
	pid_enable(&m_heater1PidData);
}

void heater1_set_enable(bool en) {
	if(en) {
		pid_enable(&m_heater1PidData);
		return;
	}
	
	pid_disable(&m_heater1PidData);
	set_heater1_pwm_value(false);
}

void heater1_reset(void) {
	pid_reset(&m_heater1PidData);
}

void heater1_pid_poll(void) {
	static uint32_t heaterPwmTime = 0;
	
	if((GetSystemTime() - heaterPwmTime) < PID_POOL_INTERVAL)
		return;
	
	heaterPwmTime = GetSystemTime();
	pid_poll(&m_heater1PidData);
}

void heater1_set_pid_factors(void) {
	m_heater1PidData.kP = Params.Config.Heater1PidFactors.kP.value;
	m_heater1PidData.kI = Params.Config.Heater1PidFactors.kI.value;
	m_heater1PidData.kD = Params.Config.Heater1PidFactors.kD.value;
}

void heater1_update_pid_data(void) {
	Params.Heater1PidData.pValue.value 		= m_heater1PidData.pValue;
	Params.Heater1PidData.iValue.value 		= m_heater1PidData.iValue;
	Params.Heater1PidData.dValue.value 		= m_heater1PidData.dValue;
	Params.Heater1PidData.errSumm.value 	= m_heater1PidData.errSum;
	Params.Heater1PidData.outValue.value 	= m_heater1PidData.outValue;
}

void heater1_soft_pwm_poll(void) {
	SoftPwmPoll(&m_Heater1PwmData);
}

uint16_t heater1_get_power_value(void) {
	return (uint16_t)(m_Heater1PwmData.Duty * 10);
}

//-----------------------------------------------------------------------------
// Private
//
void set_heater1_pwm_value(bool value) {
	if(value) {
		HEATER1_ON;
		LED_HEATER_ON;
	}
	else {
		HEATER1_OFF;
		LED_HEATER_OFF;
	}
}

void SetHeater1Pwm(float value) {
	value /= 10;
	
	if(value < 0)
		value = 0;
	
	m_Heater1PwmData.DutyNew = (uint8_t)(value);
}

float GetTemp1Sp(void) { 
	if(Params.CPU_OUT.Substance == 1)
		return (float)Params.CPU_IN.T1_Setpoint / 10.0; 
	
	if(Params.CPU_OUT.Substance == 2)
		return (float)Params.CPU_IN.T2_Setpoint / 10.0; 
	
	return (float)Params.CPU_IN.T1_Setpoint / 10.0;
}

int GetTreg(void) {
	int result = 0;
	if ((!(Params.CPU_OUT.Flags & FAIL_FLAG_TEMP1)) && (!(Params.CPU_OUT.Flags & FAIL_FLAG_TEMP2)))
		result = (Params.CPU_OUT.Temp1 + Params.CPU_OUT.Temp2) / 2;
	else {
		if (!(Params.CPU_OUT.Flags & FAIL_FLAG_TEMP1))
			result = Params.CPU_OUT.Temp1;
		else {
			if (!(Params.CPU_OUT.Flags & FAIL_FLAG_TEMP2))
				result = Params.CPU_OUT.Temp2;
		}
	}
	
	return result;
}

float 	GetTemp1Pv(void) { 
	return (float)GetTreg() / 10.0; 
}
