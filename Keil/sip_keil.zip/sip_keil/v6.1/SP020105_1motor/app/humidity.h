//=============================================================================
//
//=============================================================================

#ifndef _HUMIDITY_H_
#define _HUMIDITY_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "project.h"
#include "board.h"


void huminidity_danger(void);


#endif // _HUMIDITY_H_
