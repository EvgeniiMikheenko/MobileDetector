//=============================================================================
//							indicator.h
//=============================================================================

#ifndef _INDICATOR_H_
#define _INDICATOR_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "project.h"
#include "board.h"

#define FUNC_SET_IND 			Write_Ind(0xF828); //Func_set
#define DISP_ON_IND  			Write_Ind(0xF80C); //Disp On

#define CLEAR_IND           	Write_Ind(0xF801);
#define HOME_IND            	Write_Ind(0xF802);
#define WRITE_IND(data)    		Write_Ind(0xFA00 + (Recode_Ind(data & 0xff)));
//#define WRITE_IND(data)    	Write_Ind(0xFA00+((data&0xff)));

void Write_Ind(unsigned val);

char Recode_Ind(char C);

void Write_String_Ind(char * str);


void update_display(void);

void update_disp_rows_dbg(int displayMode, int *lpStatusTmp);
void update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags);
void disp_update_leds(int displayMode, uint16_t devMode);

void disp_rows_clear(void);
void disp_init(void);
void disp_set_rows_from_tmp(void);

#endif // _INDICATOR_H_
