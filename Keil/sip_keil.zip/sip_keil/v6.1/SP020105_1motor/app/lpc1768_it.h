//=============================================================================
//
//=============================================================================

#ifndef _LPC1768_IT_H_
#define _LPC1768_IT_H_

void TIMER0_IRQHandler (void);

void SysTick_Handler(void);

void UART3_IRQHandler(void);

#endif // _LPC1768_IT_H_
