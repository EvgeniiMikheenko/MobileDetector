#include "main.h"

extern uint16_t but_test;

#ifdef _USE_SIP1_DEVICE_
extern SwPwmData_t m_hubPwrPwmData;
#endif // _USE_SIP1_DEVICE_

MD5_CTX MD5context;
unsigned char MD5digest[16];

volatile Flags_t m_flags;

//unsigned short pump_mode = INVERSION_PUMP_MODE;

int mb_read_flag = 0;

Peaks_Table_Struct PeaksFoundTable[MAX_PEAKS * 2];
Params_Struct Params __attribute__((at(PARAMS_RAM_ADDR)));
Params_Struct * Flash_Params = (Params_Struct *) FLASH_LOCATION;

unsigned short * FPGA_IN_BUF = (unsigned short *) & Params.FPGA_IN - 8;
unsigned short * FPGA_OUT_BUF = (unsigned short *) & Params.FPGA_OUT;
unsigned short * PARAMS_BUF = (unsigned short *) & Params;
unsigned short * FLASH_PARAMS_BUF = (unsigned short *) FLASH_LOCATION;

#define FPGA_IN_PACKET_SIZE ((sizeof(FPGA_In_Struct))/2)
#define FLASH_CONFIG_ADDR		(FLASH_PARAMS_BUF + (FLASH_SIZE / 2))

HV_Packet_Struct HV_IN_Packet, HV_OUT_Packet;
int hv_fail = 0, hv_on = 0;;
int FPGA_buf_pointer = 0;
int FPGA_buf_out_pointer = 0;
//int hv_impulse, hv_impulse_prev;

volatile bool m_isStarted = false;
OnOffFilterData_t m_hackAlarmFilterData;
//-----------------------------------------------------------------------------
// Private prototypes

bool IsManualMode(void) { return ((Params.FPGA_OUT.FPGA_Flags & FLAG_MANUAL_MODE) != 0); }

uint16_t GetBlowDownLockAlarmTimeout(void);
void update_pid_info(void);

void display_proc(void);
void read_adc(void);

void update_pump_time(void);

//-----------------------------------------------------------------------------
// ������� �������
//
// ������� ext_button_proc ������ ���� ���������� �������� ��� ������� ����������
extern int ext_button_proc(int display_mode);

//
extern int detect_alarm(int oldStatus);

//
extern void test_alarm(bool isFound);
//-----------------------------------------------------------------------------
#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_

#define FLOWTOTAL_FILTER_BUF_SIZE 256
uint32_t m_flowTotalBuf[FLOWTOTAL_FILTER_BUF_SIZE];

#define FLOWIN_FILTER_BUF_SIZE 128
uint32_t m_flowInBuf[FLOWIN_FILTER_BUF_SIZE];

UIntFilterData_t m_flowTotalDfData =  {
	m_flowTotalBuf, // uint32_t *lpBuf;
	FLOWTOTAL_FILTER_BUF_SIZE, //uint32_t bufSize;
	0, //uint32_t count;
	0, //uint32_t wrIndex;
	0, //uint32_t zIndex;
	
	0, //uint32_t value;
	
	false //bool isFull;
	
};

UIntFilterData_t m_flowInDfData =  {
	m_flowInBuf, // uint32_t *lpBuf;
	FLOWIN_FILTER_BUF_SIZE, //uint32_t bufSize;
	0, //uint32_t count;
	0, //uint32_t wrIndex;
	0, //uint32_t zIndex;
	
	0, //uint32_t value;
	
	false //bool isFull;
	
};

#endif // USE_AVERAGE_FILTER_FLOW_TOTAL_

TonTimerData_t m_okResetTmrData;
TonTimerData_t m_modeSetTmrData;
//-----------------------------------------------------------------------------
//

int main() {
	int i, status_tmp, debug_display = 0;
	volatile int diff1, diff2;
	volatile bool enable1, enable2;
	uint32_t dispFlags = 0;

	SystemInit();

	__disable_interrupt(); //__disable_irq();
	
	board_init();                                                               

	init_data();

	i = sizeof(FPGA_In_Struct);

	

	RE_ON;
	DE_OFF;
	
	NVIC_SetPriority(UART1_IRQn, UART1_PRIORITY);
	NVIC_EnableIRQ(UART1_IRQn);
	
	NVIC_SetPriority(UART3_IRQn, UART3_PRIORITY);
	NVIC_EnableIRQ(UART3_IRQn);

	Board_SetFpgaNConfig();
	LED_OK_ON;

	for (i = 0; i < 1000000; i++) {
		
	}
	
	DISP_ON_IND;
	Board_PowerLedOn();
	//FAILURE_C_ON;

	FUNC_SET_IND;
	//hv_impulse = HV_IMPULSE;

	ADC_CS_OFF;
	
	disp_init();
	init_adc_data();

	MD5Init(&MD5context);
	MD5Update(&MD5context, 0, 524288);
	MD5Final((unsigned char*)MD5digest, &MD5context);
	
	/* Enable and setup SysTick Timer at a periodic rate */
	SysTick_Config(SystemCoreClock / SYSTICK_TICKRATE_HZ);
	NVIC_SetPriority (SysTick_IRQn, SYS_TICK_PRIORITY);  /* set Priority for Systick Interrupt */

#ifdef _USE_WDT_

	// Initialize WDT, IRC OSC, interrupt mode, timeout = 5000000us = 5s
	WDT_Init(WDT_CLKSRC_IRC, WDT_MODE_RESET);
	// Start watchdog with timeout given
	WDT_Start(WDT_TIMEOUT);
#else
	#warning "WDT not used !!!"
#endif
	
	__enable_interrupt();
	
	while (1)
	{
#ifdef _USE_WDT_
		WDT_Feed();
#endif
		dispFlags = 0;
		read_adc();
		disp_rows_clear();
		
		status_tmp = 0;
		
		status_tmp = detect_alarm(status_tmp);
		blowDown_proc(status_tmp > 0);
		test_alarm(status_tmp > 0);

		if (!alarm_count) {
			if (status_tmp > 0) {
				status_tmp = MODE_ALARM;
				alarm_count = ALARM_COUNT;
			}
			else {
				status_tmp = MODE_DETECT;
			}
		}
		else {
			status_tmp = MODE_ALARM;
		}

		if (Params.CPU_OUT.Device_Mode == MODE_DETECT)	{ 
			SET_HV_ON; 
			fail_counter = 0;
		}
		
		if (Params.CPU_OUT.Device_Mode == MODE_ALARM)	{ 
			fail_counter = 0;
		}
		
//		if ((!HV_READY_FLAG) && (HV_ON_FLAG))	 
//			status_tmp = MODE_SET_HV;
		
		if(run_on_off_timer(TimerIndexSetHV, (!HV_READY_FLAG) && (HV_ON_FLAG), 1000, 1000)) {
			status_tmp = MODE_SET_HV;
		}
		
		status_tmp = test_flow(status_tmp);
		status_tmp = test_temp1(status_tmp);

		update_flags();

		if ((Params.CPU_OUT.Flags & FAILURE_MASK) && (!DIP_NO_FAILURE))
			status_tmp = MODE_FAILURE;

		if(but_test > 0) {
			if(DIP_TEST_LED_BUT)
				BUZZER_ON;
			
			LED_BUT_PRESS_ON;
			but_test--;
		}
		else {
			if(DIP_TEST_LED_BUT)
				BUZZER_OFF;
			LED_BUT_PRESS_OFF;
		}
		
		if(IsManualMode()) {
			dispFlags |= FLAG_MANUAL_MODE;
		}
		
		//debug_display = button_proc(debug_display);
		debug_display = ext_button_proc(debug_display);
		
		update_disp_rows(debug_display, Params.CPU_OUT.Device_Mode, dispFlags);
		disp_update_leds(debug_display, Params.CPU_OUT.Device_Mode);
		
		//prev_dev_mode = Params.CPU_OUT.Device_Mode;
		
		update_disp_rows_dbg(debug_display, &status_tmp);
		if(m_flags.IsDebugDisplayReset == 1) {
			m_flags.IsDebugDisplayReset = 0;
			m_flags.IsCurFound = 0;
			debug_display = 0;
		}
		disp_set_rows_from_tmp();
		display_proc();
		
		set_new_device_mode(status_tmp);
		
		if (hv_on) {
			HV_OUT_Packet.Flags |= 1;
			SET_HV_PIN_ON;
		}
		else {
			HV_OUT_Packet.Flags &= ~1;
			SET_HV_PIN_OFF;
		}
		
		if (DIP_FPGA_LOAD) {
			if (!FPGA_CONF_DONE) {
				uint16_t tmp = Params.FPGA_OUT.FPGA_Flags;
				FPGA_Load();
				Params.FPGA_OUT.FPGA_Flags = tmp;
			}
				
		}

#ifdef _MD5_CHECK_USE_
		check_md5();
#endif // _MD5_CHECK_USE_
		
		check_params();
		update_time();
		//T_reg = GetTreg();
		run_on_off_timer(TimerIndexAlarmEnable, alarm_count > 0, 50, 200);
		
		if(!m_isStarted) {
			if(GetSystemTime() > STARTUP_DELAY) {
				m_isStarted = true;
			}
		}
		
		Params.CPU_OUT.Heater_Power = heater1_get_power_value();
		
		#ifdef USE_FLOW_IN
			Params.CPU_OUT.Valve_Level = flow_in_get_power_value();
		#endif // USE_FLOW_IN
		
		#ifndef USE_FIXED_TOTAL_FLOW
			Params.CPU_OUT.Pump_Total_Flow = flow_total_get_power_value();
		#endif // 
#ifdef _USE_ANALIZE_ALL_ZONES_
		Params.CPU_OUT.Substance = 1;
#endif // _USE_ANALIZE_ALL_ZONES_
		
		update_pid_info();
		test_mode_ok();
		
		#ifndef _USE_SIP1_DEVICE_
			SetHubState(0);
			SetHubLocalCounter(0);
			SetHubPwr1Value(0);
			SetHubPwr2Value(0);
		#endif // _USE_SIP1_DEVICE_
		
		update_pump_time();
	}
}

//-----------------------------------------------------------------------------
//
//
int flash_restore(void) {
	int i;
	unsigned * BUF1 = (unsigned *) PARAMS_BUF;
	unsigned * BUF2 = (unsigned *) FLASH_PARAMS_BUF;
	
	if (CalcCrc16((unsigned char *) Flash_Params, FLASH_SIZE) != Flash_Params->CRC)
	{
		for (i = 0; i < FLASH_SIZE / 4; i++)
			PARAMS_BUF[i] = 0;
		return 0;
	}
	else
	{
		for (i = 0; i < FLASH_SIZE / 4; i++)
			BUF1[i] = BUF2[i];
		return 1;
	}
}

void init_data		   (void) {
	
	ssp_init_data();
	
	m_flags.Value = 0;
	
	heater1_init();
	
	// Init modbus
	host_init();
	
#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
	
	uint_filter_init(&m_flowTotalDfData);
	uint_filter_init(&m_flowInDfData);
	
#endif // #ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
	
	Params.CPU_IN.Substance = 1;
	
	flash_restore();
	
	Params.CPU_OUT.Substance = Params.CPU_IN.Substance;
	Params.FPGA_OUT.hv_impulse_length = 20000;
	Params.FPGA_OUT.hv_polarity_length = 2048;

	Params.FPGA_OUT.PointsScale = 0x8;
	Params.FPGA_OUT.FPGA_Flags = 0x0000;
	Params.FPGA_OUT.FPGA_Flags |= FLAG_HUB_OFF;
	
	Params.CPU_OUT.FirmWare_Version = FIRMWARE_VERSION;
	
	ton_timer_init(&m_okResetTmrData);
	ton_timer_init(&m_modeSetTmrData);
}

void update_flags	   (void) {
	//-------------------------------------------------------------------------
	// ���� ����� ������
	//  0 - ������������� ������ 1 	( b0000 0000 0000 0001 )
	//  1 - ������������� ������ 1 	( b0000 0000 0000 0010 )
	//  2 - ������ ������ 1			( b0000 0000 0000 0100 )
	//  3 - ������ ������ 2			( b0000 0000 0000 1000 )
	//  4 - ����������� �������		( b0000 0000 0001 0000 )
	//  5 - ������ FPGA				( b0000 0000 0010 0000 )
	//  6 - 						( b0000 0000 0100 0000 )
	//  7 - HV no voltage div		( b0000 0000 1000 0000 )
	//  8 - ���������� HV 			( b0000 0001 0000 0000 )
	//  9 - Overload HV				( b0000 0010 0000 0000 )
	//  10- HV on					( b0000 0100 0000 0000 )
	//  11- HV pol 					( b0000 1000 0000 0000 )
	//  12- HV error				( b0001 0000 0000 0000 )
	//  13- ������ ������ ������	( b0010 0000 0000 0000 )
	//  14- Hub OFF					( b0100 0000 0000 0000 )
	//  15- ������ ������ ������	( b1000 0000 0000 0000 )
	//  ����� ������ - FAILURE_MASK 0xB2FF
	
	int i;
	for (i = 0; i < 8; i++) {
		if (ADC_Data[i].Fail > ADC_FAIL_COUNT - 1) {
			Params.CPU_OUT.Flags |= ADC_Data[i].Fail_Param;
		}
		else
			Params.CPU_OUT.Flags &= ~ADC_Data[i].Fail_Param;
	}
	//
	if(HV_READY_FLAG)	
		Params.CPU_OUT.Flags |= 0x100; 
	else 
		Params.CPU_OUT.Flags &= ~0x100;	   //HV_READY
	//
	if(HV_IN_Packet.Flags & 0x40)	
		Params.CPU_OUT.Flags |= 0x200; 
	else 
		Params.CPU_OUT.Flags &= ~0x200;	   //HV_OVERLOAD
	//
	if(HV_ON_FLAG)	
		Params.CPU_OUT.Flags |= 0x400; 
	else 
		Params.CPU_OUT.Flags &= ~0x400; //HV_ON
	//
	if(HV_IN_Packet.Flags & 0x2)	
		Params.CPU_OUT.Flags |= 0x800; 
	else 
		Params.CPU_OUT.Flags &= ~0x800;	 //HV_POL
	//
	if(HV_IN_Packet.Flags & 0x80)	
		Params.CPU_OUT.Flags |= FAIL_FLAG_HV_NO_VOLTAGE_DIV; 
	else 
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_HV_NO_VOLTAGE_DIV;	 //
	//
	if((hv_fail >= HV_FAIL_COUNT))	
		Params.CPU_OUT.Flags |= FAIL_FLAG_HV; 
	else 
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_HV;	 //HV Fail
	
	if(fpga_fail == FPGA_FAIL_COUNT)	
		Params.CPU_OUT.Flags |= 0x20; 
	else 
		Params.CPU_OUT.Flags &= ~0x20;	 //FPGA Fail
	
	if(!IsManualMode()) {
		if((Params.CPU_OUT.Device_Mode == 0) || (m_flags.IsModeOk == 0) || (!m_isStarted)){
			Params.FPGA_OUT.FPGA_Flags |= FLAG_HUB_OFF;
		}
		else {
			Params.FPGA_OUT.FPGA_Flags &= ~(FLAG_HUB_OFF);
		}
	}
	
	if(get_flow_error_timer_status()) {
		Params.CPU_OUT.Flags |= FAIL_FLAG_FLOW_TOTAL; 
		Params.CPU_OUT.Flags |= FAIL_FLAG_FLOW_IN; 
	}
	else {
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_FLOW_TOTAL; 
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_FLOW_IN; 
	}
	//
	EnableAppFlagsSupport();
	SetAppFlags(m_flags.Value);
}

void check_md5		   (void) {
	static TonTimerData_t updTmrData;
	bool en = (Params.FPGA_OUT.FPGA_Flags & SAVE_TO_FLASH_FLAG || (Flash_Params->CPU_IN.Substance != Params.CPU_OUT.Substance));
	if(!ton_timer_run(&updTmrData, 500, en)) {
		return;
	}
	
	ton_timer_reset(&updTmrData);
	
	//if (en)
	//{
#ifdef _USE_SIP1_DEVICE_
		hub_heater_off();
#endif // _USE_SIP1_DEVICE_

		Params.CPU_IN.Substance = Params.CPU_OUT.Substance;
		Params.CRC = CalcCrc16((unsigned char *) & Params, FLASH_SIZE);

		if (Params.CRC != Flash_Params->CRC) {

			EnterCritSection();
			
			FlashStore(& Params);
			MD5Init(&MD5context);
			MD5Update(&MD5context, 0, 524288);
			MD5Final((unsigned char*)MD5digest,&MD5context);
			// Reset modbus
			host_reset();
			
			ExitCritSection();
		}
		
	//}
}

void check_params	   (void) {
	
	if(m_flags.IsConfigChange == 1) {
		FlashStore(& Params);
		m_flags.IsConfigChange = 0;
	}
	
	if ((Params.FPGA_OUT.FPGA_Flags & RESTORE_FROM_FLASH_FLAG)) {
		
		EnterCritSection();
		
#ifdef _USE_SIP1_DEVICE_
		hub_heater_off();
#endif // _USE_SIP1_DEVICE_
		
		flash_restore();
		// Reset modbus
		host_reset();
		
		ExitCritSection();
	}
}

void update_time       (void) {
	if (Params.FPGA_OUT.FPGA_Flags & FLAGS_IN_SET_TIME) { 
		LPC_RTC->SEC 	= Params.CPU_IN.RTC_Sec;
		LPC_RTC->MIN 	= Params.CPU_IN.RTC_Min;
		LPC_RTC->HOUR 	= Params.CPU_IN.RTC_Hour;
		LPC_RTC->DOM 	= Params.CPU_IN.RTC_Day;
		LPC_RTC->MONTH 	= Params.CPU_IN.RTC_Month;
		LPC_RTC->YEAR 	= Params.CPU_IN.RTC_Year;
		return;
	}

	Params.CPU_IN.RTC_Sec 	= LPC_RTC->SEC;
	Params.CPU_IN.RTC_Min 	= LPC_RTC->MIN;
	Params.CPU_IN.RTC_Hour 	= LPC_RTC->HOUR;
	Params.CPU_IN.RTC_Day 	= LPC_RTC->DOM;
	Params.CPU_IN.RTC_Month = LPC_RTC->MONTH;
	Params.CPU_IN.RTC_Year 	= LPC_RTC->YEAR;
}

void pump_in_control   (void) {
//	static int counter = 0;
	
	#ifdef _USE_HACK_BUTTON_
		if(m_flags.IsBlowDown) {
			//pump_off_flag = 1;
			return;
		}
	#endif
}


//int detect_alarm(int oldStatus) {
//	
//	if(m_flags.IsModeOk == 0)
//		return oldStatus;
//	//
//	#ifdef _USE_ANALIZE_ALL_ZONES_
//		if (((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM)) && 
//			(!fpga_fail) && 
//			(DIP_ALARM_ONLY_HACK_BTN))  {
//			
//				
//			for(int i = 1; i < (1 + ALL_ZONES_COUNT); i++) {
//				if(Params.FPGA_IN.PeaksFoundTable[i].Time == 0)
//					continue;
//				
//				oldStatus++;
//			}
//		}
//	#else
//		if (((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM)) && 
//			(!fpga_fail) && 
//			(Params.FPGA_IN.PeaksFoundTable[Params.CPU_OUT.Substance].Time) && (DIP_ALARM_ONLY_HACK_BTN)) {
//				
//			oldStatus++;
//		}
//	#endif	
//		
//	return oldStatus;
//}

//void test_alarm(bool isFound) {
//	
//#ifdef _USE_SIP1_DEVICE_
//	static bool oldCheckEn = false;
//#endif // _USE_SIP1_DEVICE_
//	
////	static TonTimerData_t lockErrorTmrData;

//	#ifdef _USE_HACK_BUTTON_
//	static OnOffFilterData_t hackBtnFilterData;
//#endif
//	
//#ifdef _USE_SIP100_DEVICE_
//	int tstResult = 0;
//#endif // #ifdef _USE_SIP100_DEVICE_
//	
//	m_flags.IsLockError = 0;
//	
//#ifdef _USE_HACK_BUTTON_
//	on_off_filter_run(&hackBtnFilterData, ((GetHackBtnState()) && m_isStarted), 150, 150);
//	
//	if(hackBtnFilterData.outValue) {
//		alarm_count = ALARM_COUNT;
//		m_flags.IsHackEn = 1;
//		return;
//	}
//	
//	if(m_flags.IsHackEn) {
//		m_flags.IsHackEn = 0;
//		m_flags.IsCurFound = 0;
//		m_flags.IsLastFound = 0;
//		m_flags.IsBlowDown = 0;
//		alarm_count = 0;
//		m_flags.IsLockError = 1;
//		m_flags.IsWaReset = 1;
//	}
//	
//	if(!DIP_ALARM_ONLY_HACK_BTN) {
//		m_flags.IsLastFound = 0;
//		m_flags.IsCurFound = 0;
//		m_flags.IsWaDataInvalid = 0;
//		SetWAEnableValue(0);
//		alarm_count = 0;
//		return;
//	}
//#else
//	
//#endif
//	
//#ifdef _USE_SIP1_DEVICE_
//	
//#ifndef _TEST_MIXED_DEVICE_MODE_
//	
//	if(m_flags.IsCheckResultEn == 1) {
//		// ��������� � ���������� T2, T3, T4, � ������� ����������� ���� � �������������,
//		// ������������ �� ��� �������, � ���, � � ���� ����������� �������� ������������
//		// �������.
//		
//		if(!oldCheckEn) {
//			// ����� � ������ ���
//			// ���������� ������� ���� � ����������
//			m_flags.IsLastFound = m_flags.IsCurFound;
//			// ���������� ������� ����
//			m_flags.IsCurFound = 0;
//		}
//		
//		oldCheckEn = true;
//		
//		if(m_flags.IsCurFound == 0) {
//			// ������� ��� �� ����������
//			if(isFound) {
//				// ������� ����������, �����������
//				m_flags.IsCurFound = 1;
//			}
//		}
//	}
//	else {
//		// ��������� � ��������� �1, ������� � ������������
//		alarm_count = 0;
//		// ���������� ���� ���������� ��������
//		if(oldCheckEn) {
//			// ����� � ������ ���
//			if((m_flags.IsLastFound == 1) && (m_flags.IsCurFound == 0)) {
//				// �� ����� ��������� �������� ������� �� ����������,
//				// ���������� ���� ������� ���������� ��������
//				m_flags.IsLastFound = 0;
//			}
//		}
//		oldCheckEn = false;
//		
//	}
//	
//#endif // _TEST_MIXED_DEVICE_MODE_
//	
//#else
//	
//#endif // _USE_SIP1_DEVICE_
//	
//	#ifdef _USE_SIP100_DEVICE_
//	
//		m_flags.IsCheckResultEn = 1;
//		
//		if((GetWaSubstance1En() && (Params.CPU_OUT.Substance == 1)) ||
//		   (GetWaSubstance2En() && (Params.CPU_OUT.Substance == 2)) || 
//		   (GetWaSubstance3En() && (Params.CPU_OUT.Substance == 3)))   {
//		
//			tstResult = test_wave();
//			if(tstResult > 0) {
//				// ��������� ������ �� �������
//				m_flags.IsCurFound = 1;
//			}
//			else {
//				m_flags.IsCurFound = 0;
//			}
//			
//			SetWAEnableValue(m_flags.IsWaDataInvalid == 0);
//		}
//		else {
//			m_flags.IsLastFound = 0;
//			m_flags.IsCurFound = 0;
//			m_flags.IsWaDataInvalid = 0;
//			SetWAEnableValue(0);
//		}
//	
//	#endif // _USE_SIP100_DEVICE_
//		
//	if(run_on_off_timer(TimerIndexLockAlarm, (m_flags.IsBlowDown == 1) && (m_isStarted), 500, GetBlowDownLockAlarmTimeout())) {
//		alarm_count = ALARM_COUNT;
//	}
//	
//	if((m_flags.IsLastFound == 1) || /* ��� ���������� �������� ���� ���������� ������� */
//	   (m_flags.IsCurFound == 1) ) {  /* ���� ������� ���������� ��� ��������� �������� */
//		   // �������
//		   alarm_count = ALARM_COUNT;
//	}
//}


#ifdef USE_FIXED_TOTAL_FLOW
static uint16_t flowPwmValue = 0x583;
#endif

int test_flow(int status) {
	
#ifndef USE_FIXED_TOTAL_FLOW
	
	volatile bool enable1;
	uint32_t flowOnTime;
	
	volatile int diff1 = Params.CPU_IN.Flow_Total_Setpoint - Params.CPU_OUT.Flow_Total;
	#ifdef USE_FLOW_IN
		volatile int diff2 = Params.CPU_IN.Flow_In_Setpoint - Params.CPU_OUT.Flow_In;
		volatile bool enable2;
	#endif // USE_FLOW_IN
		
	if (Params.CPU_OUT.Device_Mode == MODE_SET_TOTAL_FLOW) {
		SET_HV_ON;
		
		enable1 = ( (diff1 > MAX_F_ERROR_DIV2) || (diff1 < -(MAX_F_ERROR_DIV2)) ); 
		#ifdef USE_FLOW_IN
			enable2 = ( (diff2 > MAX_F_ERROR_DIV2) || (diff2 < -(MAX_F_ERROR_DIV2)) ); 
		#endif // #ifdef USE_FLOW_IN
	}
	else {
		
		enable1 = ( (diff1 > MAX_F_ERROR) || (diff1 < -(MAX_F_ERROR)) ); 
		#ifdef USE_FLOW_IN
			enable2 = ( (diff2 > MAX_F_ERROR) || (diff2 < -(MAX_F_ERROR)) ); 
		#endif // #ifdef USE_FLOW_IN
	}
	
	if(Params.CPU_OUT.Device_Mode == MODE_PREHEAT) {
		reset_on_off_timer(TimerIndexFlowStable);
	}
	
	if(run_on_off_timer(TimerIndexFlowStable, 
						(!enable1)
						#ifdef USE_FLOW_IN
							&& (!enable2)
						#endif // #ifdef USE_FLOW_IN
						, 
						FLOW_STABLE_TIME_MS, 
						FLOW_STABLE_RESET_OUT_OF_RANGE_TIME_MS)) {
		m_flags.IsFlowStable = 1;
	}
	else {
		m_flags.IsFlowStable = 0;
	}
#ifdef _USE_SIP1_DEVICE_
	flowOnTime = GetT2Time();
#else 
	flowOnTime = 3000;
#endif
	
#ifdef _USE_HACK_BUTTON_	
	if(run_on_off_timer(TimerIndexFlowOutOfRange, 
						(enable1
						#ifdef USE_FLOW_IN
							|| enable2
						#endif // #ifdef USE_FLOW_IN
						) && (m_flags.IsBlowDown == 0), flowOnTime * 2, 3000)) {
		status = MODE_SET_TOTAL_FLOW;
	}
#else
	if(run_on_off_timer(TimerIndexFlowOutOfRange, 
						(enable1 
						#ifdef USE_FLOW_IN
							|| enable2
						#endif // #ifdef USE_FLOW_IN
						), flowOnTime * 2, 3000)) {
		status = MODE_SET_TOTAL_FLOW;
	}
#endif
	
	#ifdef USE_FLOW_IN
		if((!m_isStarted) || (Params.CPU_OUT.Device_Mode == 0) || (Params.CPU_OUT.Device_Mode == MODE_PREHEAT) || 
			(m_flags.IsBlowDown == 1) || (blowing) ||
			((!CheckReperData()) && (!IsManualMode()))) 
		{
			flow_in_set_pid_enable(false);
		}
		else {
			flow_in_set_pid_enable(true);
		}
		
		flow_in_pid_poll();
	#endif // #ifdef USE_FLOW_IN
	
	// Flow total PID always enable
	flow_total_set__pid_enable(true);
	flow_total_pid_poll();
#else 
	Board_SetPumpTotalDuty(flowPwmValue);
	run_flow_error_timer(Params.CPU_OUT.Flow_In < 7000); // < 700 ��3
	m_flags.IsFlowStable = (get_flow_error_timer_status()) ? 0 : 1;
#endif
	
	return status;
}

int test_temp1(int status) {
	static uint16_t oldSubstance = 0;
	static float oldTsp = 0;
	float Tsp = GetTemp1Sp();
	float Tcur = GetTemp1Pv();
	bool preheatEnable = (fabs(Tsp - Tcur)) > TEMP_HYSTERESYS;
	
	if(oldTsp != Tsp) {
		reset_on_off_timer(TimerIndexTemp1Stable);
	}
	
	if(run_on_off_timer(TimerIndexTemp1Stable, !preheatEnable, TEMP_STABLE_TIME_MS, TEMP_STABLE_RESET_OUT_OF_RANGE_TIME_MS)) {
		m_flags.IsTemp1Stable = 1;
	}
	else {
		m_flags.IsTemp1Stable = 0;
	}
	
	if((m_flags.IsTemp1Stable == 0) && (m_isStarted)) {
		status = MODE_PREHEAT;
	
		if (Params.CPU_OUT.Device_Mode != MODE_PREHEAT) {
			SET_HV_OFF;
		}
	}
		
	if(((Tcur - Tsp) > 3) || (!m_isStarted) || (Params.CPU_OUT.Device_Mode == MODE_FAILURE) ||
		((!CheckReperData()) && (!IsManualMode()))) {
		heater1_set_enable(false);
	}
	else {
		heater1_set_enable(true);
	}
		
	heater1_pid_poll();
	
	if(oldSubstance != Params.CPU_OUT.Substance) {
		heater1_reset();
	}
	
	oldSubstance = Params.CPU_OUT.Substance;
	oldTsp = Tsp;
	
	return status;
}

void test_mode_ok(void) {
	static float oldTempSp = 0;
	static uint16_t oldFlowInSp = 0;
	static uint16_t oldFlowTotalSp = 0;
	static uint32_t tempCheckStartTime = 0;
	static bool tempOk = false;
	bool oldIsManualMode = false;
	float sp = GetTemp1Sp();
	volatile uint32_t temp;
	
	bool forseOff = (Params.CPU_OUT.Device_Mode == 0) || (Params.CPU_OUT.Device_Mode == MODE_FAILURE);
	
	if((oldTempSp != sp) || 
	   (oldFlowInSp != Params.CPU_IN.Flow_In_Setpoint) ||
	   (oldFlowTotalSp != Params.CPU_IN.Flow_Total_Setpoint) || 
	   (oldIsManualMode != IsManualMode()) ||
	    forseOff)
	{
		//if((m_flags.IsModeOk == 1) || (forseOff))
			//modeOkStartTime = GetSystemTime();
		//
		if((oldTempSp != sp) || (forseOff)) {
			tempOk = false;
			tempCheckStartTime = GetSystemTime();
		}
		//
		m_flags.IsModeOk = 0;
		ton_timer_reset(&m_okResetTmrData);
		ton_timer_reset(&m_modeSetTmrData);
	}

	if(IsManualMode()) {
		m_flags.IsModeOk = 1;
		ton_timer_reset(&m_okResetTmrData);
		ton_timer_reset(&m_modeSetTmrData);
	}
	else {
		ton_timer_run(&m_okResetTmrData, MODE_SET_DELAY_TIME_MS, (m_flags.IsModeOk == 0) || m_okResetTmrData.outValue);
		//
		bool modeOkEn = (m_okResetTmrData.outValue) /* ����������� ����� ������ */ && 
						((m_flags.IsTemp1Stable == 1) || (get_timer_is_enable(TimerIndexTemp1Stable))) /* ����������� � ���������� ���� */&& 
						((m_flags.IsFlowStable == 1) || ((get_timer_is_enable(TimerIndexFlowStable)))  /* ����� � ���������� ���� */ &&
						(!forseOff) /* �� ����� */);
		//
		if(ton_timer_run(&m_modeSetTmrData, MODE_SET_TIME_MS, modeOkEn)) {
			m_flags.IsModeOk = ((m_flags.IsTemp1Stable == 1) && (m_flags.IsFlowStable == 1)) ? 1 : 0;
		}
		else {
			m_flags.IsModeOk = 0;
		}
	}
	
	SetEnableModeTimer(m_modeSetTmrData.enable);
	
	if((m_flags.IsModeOk == 0) && (m_isStarted)) {
		temp = ton_timer_get_time_remaining(&m_modeSetTmrData, MODE_SET_TIME_MS) / 1000;//(GetSystemTime() - modeOkStartTime) / 1000;
		SetModeOkWorkTime(temp);
	}
	
	if(!m_isStarted) {
		tempOk = false;
		tempCheckStartTime = GetSystemTime();
	}
	else if((!tempOk) && (m_isStarted))  {
		if((fabs(GetTemp1Sp() - GetTemp1Pv())) < TEMP_HYSTERESYS) {
			tempOk = true;
		}
		//
		temp = (GetSystemTime() - tempCheckStartTime) / 1000;
		SetTempSetupTime(temp);
	}
	
	oldTempSp = sp;
	oldFlowInSp = Params.CPU_IN.Flow_In_Setpoint; 
	oldFlowTotalSp = Params.CPU_IN.Flow_Total_Setpoint;
	oldIsManualMode = IsManualMode();
}

void set_new_device_mode(int newMode) {
	
	//static TonTimerData_t tmrData;
	
	if(!m_isStarted) {
		Params.CPU_OUT.Device_Mode = 0;
		return;
	}
	
	if(!IsManualMode()) {
		
		if(!CheckReperData()) {
			Params.CPU_OUT.Device_Mode = 0;
			return;
		}
		if(run_on_off_timer(TimerIndexDeviceAlarmOff, newMode == MODE_ALARM, 5, 3000)) {
			Params.CPU_OUT.Device_Mode = MODE_ALARM;
		}
		else {
			Params.CPU_OUT.Device_Mode = newMode;
		}
		//if(ton_timer_run(&tmrData, Params.CPU_OUT.Device_Mode != newMode, 500)) {
//			if(!m_isStarted)
//				Params.CPU_OUT.Device_Mode = MODE_PREHEAT;
//			else
				//Params.CPU_OUT.Device_Mode = newMode;
		//	ton_timer_reset(&tmrData);
		//}
		return;
	}
	
	
	//MANUAL_MODE
			
	if (Params.FPGA_OUT.FPGA_Flags & (1 << 3)) 	 
		Params.CPU_OUT.Device_Mode  = MODE_DETECT;	
	else 
		Params.CPU_OUT.Device_Mode = MODE_PREHEAT;
	
	if (Params.FPGA_OUT.FPGA_Flags & 1)
		SET_HV_ON;
	else
		SET_HV_OFF;
	
	fail_counter=0;	
}

void update_pid_info(void) {
	
	static uint32_t time = 0;
	
	if((GetSystemTime() - time) < 1000)
		return;
	
	time = GetSystemTime();
	
	if(m_flags.IsPidFactorsChange == 1) {
		m_flags.IsPidFactorsChange = 0;
		heater1_set_pid_factors();
		//flow_in_set_pid_factors();
		//flow_total_set_pid_factors();
	}
	
	heater1_update_pid_data();
	//flow_in_update_pid_data();
	//flow_total_update_pid_data();
}

bool CheckReperData(void) {
	if((Params.FPGA_OUT.PeakParamTable[2] != 0))
		return true;
	
	if((Params.FPGA_OUT.PeakParamTable[1] != 0))
		return true;
	
	if((Params.FPGA_OUT.PeakParamTable[0] != 0))
		return true;
	
	return false;
}

void blowDown_proc(bool isAlarm) {
	bool en = false;
	
	if(GetDipDisableBlowdown()) {
		m_flags.IsBlowDown = 0;
		on_off_filter_reset(&m_hackAlarmFilterData);
		return;
	}
	
	#ifdef _USE_ANALIZE_ALL_ZONES_
//		if(((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM))) {
//			for(int i = 1; i < (1 + ALL_ZONES_COUNT); i++) {
//				if(Params.FPGA_IN.PeaksFoundTable[i].Time == 0)
//					continue;
//				
//				en = true;
//			}
//		}
		m_flags.IsBlowDown = 0;
	#else 
		en = (((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM)) && 
		  /* (!fpga_fail) && */
		  (Params.FPGA_IN.PeaksFoundTable[Params.CPU_OUT.Substance].Time != 0));
	#endif // _USE_ANALIZE_ALL_ZONES_
	
	if(on_off_filter_run(&m_hackAlarmFilterData, en, 3000, 3000)) {
		m_flags.IsBlowDown = 1;
	}
	else {
		m_flags.IsBlowDown = 0;
	}
}

uint16_t GetBlowDownLockAlarmTimeout(void) {
	
	if(Params.CPU_OUT.Substance == 0)
		return 0;
	
	int index = WAVE_BLOWDOWN_LOCK_ALARM1_INDEX + (Params.CPU_OUT.Substance - 1);
	return Params.CPU_IN.Dummy[index];
}

void read_adc(void) {
	if(m_flags.IsNeedReadAdc == 0)
		return;
	//
#ifdef USE_FLOW_IN_LGAR_SENSOR2	
	volatile float voltage, v2, v3;
#endif
	//
	Read_ADC();
	Read_ADC();
	Read_ADC();
	Read_ADC();

	Read_ADC();
	Read_ADC();
	Read_ADC();
	Read_ADC();
	//
	#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
		uint_filter_put(&m_flowTotalDfData, Flow1_ADC);
		Params.CPU_OUT.Flow_Total		= ADC_Flow(uint_filter_get(&m_flowTotalDfData));
		
		uint_filter_put(&m_flowInDfData, Flow2_ADC);
	
		#ifdef USER_FLOW_IN_LGAR_SENSORS
			uint_filter_get(&m_flowInDfData);
	
			#ifdef USE_FLOW_IN_LGAR_SENSOR1
				// ������ ������ ����������� 1
				// |   0   |  100  |  200  |  300  |  400  |  500  |  600  |  700  |  770  | ����� ��3
				// | 1.094 | 1.038 | 1.013 | 0.999 | 0.993 | 0.990 | 0.988 | 0.983 | 0.982 | ��������� V
				// | 1.335 | 1.271 | 1.249 | 1.236 | 1.228 | 1.224 | 1.221 | 1.215 | 1.214 | ��������� ������� �� 2�� ���� ������
				Params.CPU_OUT.Flow_In		= (uint16_t)((m_flowInDfData.value * 5.0 * 1000.0 * 10.0) / 0xFFFF);
			#else
				#ifdef USE_FLOW_IN_LGAR_SENSOR2
					// ������ ������ ����������� 1
					// |   0   |  100  |  200  |  300  |  400  |  500  |  600  |  700  |  800  | ����� ��3
					// | 2.910 | 3.321 | 3.555 | 3.773 | 3.896 | 3.968 | 4.028 | 4.121 | 4.182 | ��������� V (t=35)
					voltage		= ((m_flowInDfData.value * 5.0) / 0xFFFF);
					v2 = powf(voltage, 2.0);
					v3 = powf(voltage, 3.0);
					Params.CPU_OUT.Flow_In = (uint16_t)(((502.7067 * v3) - (4797.4712 * v2) + (15490.5359 * voltage) - 16839.6938) * 10.0);
				#endif // USE_FLOW_IN_LGAR_SENSOR2
			#endif // USE_FLOW_IN_LGAR_SENSOR1
		#else
			// DF6P0010A2
			Params.CPU_OUT.Flow_In		= ADC_Flow(uint_filter_get(&m_flowInDfData));
		#endif // USE_FIXED_TOTAL_FLOW
		
	#else
		Params.CPU_OUT.Flow_Total		= ADC_Flow(Flow1_ADC);
		Params.CPU_OUT.Flow_In 			= ADC_Flow(Flow2_ADC);
	#endif // USE_AVERAGE_FILTER_FLOW_TOTAL_

	//adc_temp						= ADC_Data[2].Data;
	Params.CPU_OUT.Athm_Pressure 	= ADC_Pressure(Athm_Int >> 16);
	Params.CPU_OUT.Temp1 			= ADC_Temp(Temp1_Camera_ADC);
	Params.CPU_OUT.Temp2 			= ADC_Temp(Temp2_Camera_ADC);
	Params.CPU_OUT.Temp_Case 		= ADC_Temp_Case(Temp_Case_ADC);
	Params.CPU_OUT.Humidity			= ADC_Humidity(Humidity_ADC);

	Athm = (AirPressure_ADC << 16) & 0xFFFFFFFF;
	Athm_Int += ((Athm - Athm_Int) >> 8);
	//
	m_flags.IsNeedReadAdc = 0;
}

void display_proc(void) {
	if(m_flags.IsNeedUpdateDisplay == 0)
		return;
	//
	update_display();
	//
	m_flags.IsNeedUpdateDisplay = 0;
}

void update_pump_time(void) {
	static uint32_t time = 0;
	
	if((GetSystemTime() - time) < 1000)
		return;
	
	time = GetSystemTime();
	
	if (DIP_CLEAR_PUMP_TIME)
		pump_time = 0;
	else {
		pump_time = LPC_RTC->GPREG1;
		pump_time = (pump_time << 32) + LPC_RTC->GPREG0;
		pump_time += Params.CPU_OUT.Pump_Total_Flow;
	}

	LPC_RTC->GPREG0 = pump_time & 0xFFFFFFFF;
	LPC_RTC->GPREG1 = pump_time >> 32;

	Params.CPU_OUT.Pump_Time_Low = LPC_RTC->GPREG1 & 0xFFFF;
	Params.CPU_OUT.Pump_Time_High = LPC_RTC->GPREG1 >> 16;
}
//-----------------------------------------------------------------------------
// Interrupts handlers
//
void TIMER1_IRQHandler (void) {
	int Sum;

	SSP_DMA_Start_TX();

	if ((mb_read_flag == 2)) {
		SSP_DMA_Start_RX();
		mb_read_flag = 3;
	}
	else
		SSP_DMA_Start_RX();
	
	Sum = Params.FPGA_IN.PeaksFoundTable[0].Value + 
	      Params.FPGA_IN.PeaksFoundTable[1].Value + 
	      Params.FPGA_IN.PeaksFoundTable[2].Value +
	      Params.FPGA_IN.PeaksFoundTable[0].Time + 
	      Params.FPGA_IN.PeaksFoundTable[1].Time + 
	      Params.FPGA_IN.PeaksFoundTable[2].Time;
	
	if (((Params.FPGA_IN.Flags_FPGA & 0xFF00) == ((Sum & 0xFF) << 8)))
		fpga_fail = 0;

	if ((!fpga_fail) && 
		((Params.CPU_OUT.Device_Mode == MODE_ALARM) || (Params.CPU_OUT.Device_Mode == MODE_DETECT)))
	{
		if (Params.FPGA_IN.PeaksFoundTable[0].Time != 0) {
			blowing = 0;
			main_peak_count = 0;
		}
		else {
			main_peak_count++;
			if(main_peak_count > MIN_PEAK_COUNT) 
				blowing = 1;
		}
	}

	if (mb_read_flag == 1)
		mb_read_flag = 2;

	LPC_TIM1->IR = 0x20;

	HV_OUT_Packet.HV_Value=(Params.CPU_IN.HV_Setpoint)/10;
	HV_THR = 0xCA;
	HV_THR = HV_OUT_Packet.Flags;
	HV_THR = HV_OUT_Packet.HV_Value;
	HV_THR = (HV_OUT_Packet.HV_Value >> 8);
	return;
}


void RIT_IRQHandler    (void) {
	LPC_RIT->RICTRL |= 1;
	
	if((m_flags.IsNeedReadAdc == 0)) {
		m_flags.IsNeedReadAdc = 1;
	}

	if (alarm_count > 0)	
		alarm_count--;

	if (fail_counter++ > FAIL_COUNT - 1) { 
		fail_counter = FAIL_COUNT; 
		Params.CPU_OUT.Flags |= FAIL_FLAG_UNABLE; 
	} // Unable to enter detect mode
	else
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_UNABLE;

	//��������� �������� �������
	buzzer_period++;
	if (get_alarm_status() && (buzzer_period & (1 << 8)))
		BUZZER_ON;
	else
		BUZZER_OFF;
	
	LPC_PWM1->LER = 0xff;

	if((m_flags.IsNeedUpdateDisplay == 0)) {
		m_flags.IsNeedUpdateDisplay = 1;
	}

	if (hv_fail < (HV_FAIL_COUNT + 1))	
		hv_fail++;
	
	if (++fpga_fail > FPGA_FAIL_COUNT) 
		fpga_fail = FPGA_FAIL_COUNT;


	button_poll();
}
//-----------------------------------------------------------------------------
