//=============================================================================
//
//=============================================================================

#include "ssp.h"
#include "hub.h"
#include "utils\utils.h"

extern int mb_read_flag;
extern int FPGA_buf_pointer;
extern int FPGA_buf_out_pointer;
extern unsigned short * FPGA_IN_BUF;
extern unsigned short * FPGA_OUT_BUF;

struct
{
	uint32_t source; // start of source area
	uint32_t destination; // start of destination area
	uint32_t next; // address of next strLLI in chain
	uint32_t control; // DMACCxControl register
} LLI0_SSP_TX, LLI0_SSP_RX1, LLI0_SSP_RX2, LLI0_SSP_RX3, LLI0_SSP_RX4;

int fpga_dr = 0;
int cpu_in_fail = 0;

FPGA_In_Peaks_Struct FPGA_Peaks_Buf;

void SSP_DMA_Start_TX(void) {
	LPC_GPDMACH0->DMACCConfig = 0;
	//LPC_GPDMACH0->DMACCSrcAddr  = 0;
	LPC_GPDMACH0->DMACCSrcAddr = (uint32_t) FPGA_OUT_BUF;
	LPC_GPDMACH0->DMACCDestAddr = (uint32_t) & (LPC_SSP0->DR);
	LPC_GPDMACH0->DMACCLLI = 0;
	LPC_GPDMACH0->DMACCControl = (32 % 4096) 	  // transfer size (0 - 11) = 32
								| ((0 % 8) << 12) // source burst size (12 - 14) = 1
								| ((0 % 8) << 15) // destination burst size (15 - 17) = 1
								| ((1 % 8) << 18) // source width (18 - 20) = 32 bit
								| ((1 % 8) << 21) // destination width (21 - 23) = 32 bit
								| ((0 % 2) << 24) // source AHB select (24) = AHB 0
								| ((0 % 2) << 25) // destination AHB select (25) = AHB 0
								| ((1 % 2) << 26) // source increment (26) = increment
								| ((0 % 2) << 27) // destination increment (27) = no increment
								| ((0 % 2) << 28) // mode select (28) = access in user mode
								| ((0 % 2) << 29) // (29) = access not bufferable
								| ((0 % 2) << 30) // (30) = access not cacheable
								| ((0 % 2) << 31); // terminal count interrupt disabled

	LPC_GPDMACH0->DMACCConfig = 1 // channel enabled (0)
								| (0 << 1) // source peripheral (1 - 5) = none
								| (0 << 6) // destination peripheral (6 - 10) = DAC
								| (1 << 11) // flow control (11 - 13) = mem to per
								| (0 << 14) // (14) = mask out error interrupt
								| (0 << 15) // (15) = mask out terminal count interrupt
								| (0 << 16) // (16) = no locked transfers
								| (0 << 18); // (27) = no HALT
}

void SSP_DMA_Start_RX(void) {
	//int i = 0;
	
	LPC_GPDMACH1->DMACCConfig = 0;

	LLI0_SSP_RX2.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX2.destination = (uint32_t) FPGA_IN_BUF + 8000;
	LLI0_SSP_RX2.next = (uint32_t) & LLI0_SSP_RX3;
	LLI0_SSP_RX2.control = 1 << 27 | 1 << 21 | 1 << 18 | (4000);

	LLI0_SSP_RX3.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX3.destination = (uint32_t) FPGA_IN_BUF + 16000;
	LLI0_SSP_RX3.next = 0;
	LLI0_SSP_RX3.control = 1 << 27 | 1 << 21 | 1 << 18 | 518;

	LPC_GPDMACH1->DMACCSrcAddr = (uint32_t) & (LPC_SSP0->DR);
	LPC_GPDMACH1->DMACCDestAddr = (uint32_t) FPGA_IN_BUF + 16;
	//i = LPC_GPDMACH1->DMACCDestAddr;
	LPC_GPDMACH1->DMACCLLI = (uint32_t) & LLI0_SSP_RX2;
	LPC_GPDMACH1->DMACCControl = (4000 % 4096) // transfer size (0 - 11) = 32
								| ((0 % 8) << 12) // source burst size (12 - 14) = 1
								| ((0 % 8) << 15) // destination burst size (15 - 17) = 1
								| ((1 % 8) << 18) // source width (18 - 20) = 32 bit
								| ((1 % 8) << 21) // destination width (21 - 23) = 32 bit
								| ((0 % 2) << 24) // source AHB select (24) = AHB 0
								| ((0 % 2) << 25) // destination AHB select (25) = AHB 0
								| ((0 % 2) << 26) // source increment (26) = increment
								| ((1 % 2) << 27) // destination increment (27) = no increment
								| ((0 % 2) << 28) // mode select (28) = access in user mode
								| ((0 % 2) << 29) // (29) = access not bufferable
								| ((0 % 2) << 30) // (30) = access not cacheable
								| ((0 % 2) << 31); // terminal count interrupt disabled

	LPC_GPDMACH1->DMACCConfig = 1 // channel enabled (0)
								| (1 << 1) // source peripheral (1 - 5) = none
								| (0 << 6) // destination peripheral (6 - 10) = DAC
								| (2 << 11) // flow control (11 - 13) = mem to per
								| (0 << 14) // (14) = mask out error interrupt
								| (0 << 15) // (15) = mask out terminal count interrupt
								| (0 << 16) // (16) = no locked transfers
								| (0 << 18); // (27) = no HALT
}

void SSP_DMA_Start_RX_Peaks(void) {
	int i;
	LPC_GPDMACH1->DMACCConfig = 0;

	LPC_GPDMACH1->DMACCSrcAddr = (uint32_t) & (LPC_SSP0->DR);
	LPC_GPDMACH1->DMACCDestAddr =64+(uint32_t) & FPGA_Peaks_Buf;
	i = (uint32_t) & FPGA_Peaks_Buf;
	LPC_GPDMACH1->DMACCLLI = 0;
	//LPC_GPDMACH1->DMACCLLI=(uint32_t) 0;
	i = (sizeof(FPGA_In_Peaks_Struct) % 4096);
	LPC_GPDMACH1->DMACCControl = (i/4) // transfer size (0 - 11) = 32
								| ((0 % 8) << 12) // source burst size (12 - 14) = 1
								| ((0 % 8) << 15) // destination burst size (15 - 17) = 1
								| ((1 % 8) << 18) // source width (18 - 20) = 32 bit
								| ((1 % 8) << 21) // destination width (21 - 23) = 32 bit
								| ((0 % 2) << 24) // source AHB select (24) = AHB 0
								| ((0 % 2) << 25) // destination AHB select (25) = AHB 0
								| ((0 % 2) << 26) // source increment (26) = increment
								| ((1 % 2) << 27) // destination increment (27) = no increment
								| ((0 % 2) << 28) // mode select (28) = access in user mode
								| ((0 % 2) << 29) // (29) = access not bufferable
								| ((0 % 2) << 30) // (30) = access not cacheable
								| ((0 % 2) << 31); // terminal count interrupt disabled

	LPC_GPDMACH1->DMACCConfig = 1 // channel enabled (0)
								| (1 << 1) // source peripheral (1 - 5) = none
								| (0 << 6) // destination peripheral (6 - 10) = DAC
								| (2 << 11) // flow control (11 - 13) = mem to per
								| (0 << 14) // (14) = mask out error interrupt
								| (0 << 15) // (15) = mask out terminal count interrupt
								| (0 << 16) // (16) = no locked transfers
								| (0 << 18); // (27) = no HALT

}

void ssp_init_data(void) {
	LLI0_SSP_TX.source = (uint32_t) FPGA_OUT_BUF;
	LLI0_SSP_TX.destination = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_TX.next = (uint32_t) 0;
	LLI0_SSP_TX.control = 1 << 26 | 1 << 21 | 1 << 18 | 32;

	LLI0_SSP_RX1.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX1.destination = (uint32_t) FPGA_IN_BUF;
	LLI0_SSP_RX1.next = (uint32_t) & LLI0_SSP_RX2;
	LLI0_SSP_RX1.control = 1 << 27 | 1 << 21 | 1 << 18 | 4000;

	LLI0_SSP_RX2.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX2.destination = (uint32_t) FPGA_IN_BUF + 8000;
	LLI0_SSP_RX2.next = (uint32_t) & LLI0_SSP_RX3;
	LLI0_SSP_RX2.control = 1 << 27 | 1 << 21 | 1 << 18 | (4000);

	LLI0_SSP_RX3.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX3.destination = (uint32_t) FPGA_IN_BUF + 16000;
	LLI0_SSP_RX3.next = 0;
	LLI0_SSP_RX3.control = 1 << 27 | 1 << 21 | 1 << 18 | 512;

	LLI0_SSP_RX1.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX1.destination = (uint32_t) FPGA_IN_BUF + 12000;
	LLI0_SSP_RX1.next = (uint32_t) & LLI0_SSP_RX4;
	LLI0_SSP_RX1.control = 1 << 27 | 1 << 21 | 1 << 18 | 4000;

	LLI0_SSP_RX4.source = (uint32_t) & (LPC_SSP0->DR);
	LLI0_SSP_RX4.destination = (uint32_t) FPGA_IN_BUF + 16000;
	LLI0_SSP_RX4.next = 0;
	LLI0_SSP_RX4.control = 1 << 27 | 1 << 21 | 1 << 18 | 4000;
}

void SSP0_IRQHandler(void) {
	int t;//, i = 0;//, j;

	EnterCritSection();
	
#ifdef _USE_SIP1_DEVICE_
	
	hub_heater_off();

#endif // _USE_SIP1_DEVICE_

	if (fpga_dr != FPGA_DR)
	{
		fpga_dr = FPGA_DR;

		if ((mb_read_flag == 2))
			mb_read_flag = 3;

		if (mb_read_flag == 1)
			mb_read_flag = 2;

		FPGA_buf_pointer = 0;
		FPGA_buf_out_pointer = 0;
		cpu_in_fail = 0;
	}
	//j = FPGA_buf_pointer + i;
	while ((LPC_SSP0->SR & 0x4))
	{
		t = LPC_SSP0->DR;
		
		if ((FPGA_buf_pointer >= MAX_PEAKS * 2 + 1) && (mb_read_flag == 3))
			mb_read_flag = 0;
		
		if (mb_read_flag != 0)
		{
			if ((FPGA_buf_pointer == 8) && ((t & 0xff00) != 0xD500))
				cpu_in_fail = 1;
			if (!cpu_in_fail)
				FPGA_IN_BUF[FPGA_buf_pointer] = t;
		}

		FPGA_buf_pointer++;
	}
	
	ExitCritSection();

}
