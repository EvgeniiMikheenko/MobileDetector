//=============================================================================
//
//=============================================================================

#ifndef _SSP_H_
#define _SSP_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "project.h"
#include "board.h"

void ssp_init_data(void);

void SSP_DMA_Start_TX(void);

void SSP_DMA_Start_RX(void);

void SSP_DMA_Start_RX_Peaks(void);

#endif // _SSP_H_
