//=============================================================================
//
//=============================================================================

#include "gs2r.h"

#ifdef _USE_GS2R_DEVICE_

#include <ton_timer.h>
#include <app_timers.h>

extern Params_Struct Params;
extern Flags_t m_flags;
extern int fpga_fail;
extern volatile bool m_isStarted;
extern int	alarm_count;

extern uint16_t GetBlowDownLockAlarmTimeout(void);

int detect_alarm(int oldStatus) {
	
	if(!DIP_ALARM_ONLY_HACK_BTN)
		return oldStatus;
	//
	if(m_flags.IsModeOk == 0)
		return oldStatus;
	//
	if(fpga_fail)
		return oldStatus;
	//
	if (!((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM))) 
		return oldStatus;
	//	
	for(int i = 1; i < (1 + ALL_ZONES_COUNT); i++) {
		if(Params.FPGA_IN.PeaksFoundTable[i].Time == 0)
			continue;
		
		oldStatus++;
	}
	//	
	return oldStatus;
}	

void test_alarm(bool isFound) {

#ifdef _USE_HACK_BUTTON_
	static OnOffFilterData_t hackBtnFilterData;
#endif
	
	m_flags.IsLockError = 0;
	
#ifdef _USE_HACK_BUTTON_
	on_off_filter_run(&hackBtnFilterData, ((GetHackBtnState()) && m_isStarted), 150, 150);
	
	if(hackBtnFilterData.outValue) {
		alarm_count = ALARM_COUNT;
		m_flags.IsHackEn = 1;
		return;
	}
	
	if(m_flags.IsHackEn) {
		m_flags.IsHackEn = 0;
		m_flags.IsCurFound = 0;
		m_flags.IsLastFound = 0;
		m_flags.IsBlowDown = 0;
		alarm_count = 0;
		m_flags.IsLockError = 1;
		m_flags.IsWaReset = 1;
	}
	
	if(!DIP_ALARM_ONLY_HACK_BTN) {
		m_flags.IsLastFound = 0;
		m_flags.IsCurFound = 0;
		m_flags.IsWaDataInvalid = 0;
		SetWAEnableValue(0);
		alarm_count = 0;
		return;
	}
#endif
		
	if(run_on_off_timer(TimerIndexLockAlarm, (m_flags.IsBlowDown == 1) && (m_isStarted), 500, GetBlowDownLockAlarmTimeout())) {
		alarm_count = ALARM_COUNT;
	}
	
	if((m_flags.IsLastFound == 1) || /* ��� ���������� �������� ���� ���������� ������� */
	   (m_flags.IsCurFound == 1) ) {  /* ���� ������� ���������� ��� ��������� �������� */
		   // �������
		   alarm_count = ALARM_COUNT;
	}
}

#endif // _USE_GS2R_DEVICE_
