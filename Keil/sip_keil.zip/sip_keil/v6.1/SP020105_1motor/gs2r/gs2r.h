//=============================================================================
//
//=============================================================================

#ifndef _GS2R_H_
#define _GS2R_H_

	#include <board.h>
	#include <project.h>

	#ifdef _USE_GS2R_DEVICE_

		int detect_alarm(int oldStatus);

	#endif // _USE_GS2R_DEVICE_

#endif // _GS2R_H_
