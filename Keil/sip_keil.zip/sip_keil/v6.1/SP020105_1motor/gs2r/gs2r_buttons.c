//=============================================================================
//								gs2r_buttons.c
//=============================================================================

#include "gs2r_buttons.h"

#ifdef _USE_GS2R_DEVICE_

extern Params_Struct Params;

extern int buttons;
extern int buttons_prev;
extern int buttons_time;
extern int button_pressed;
extern uint16_t but_test;

//int gs2r_button_proc(int display_mode) {
int ext_button_proc(int display_mode) {
	
	if (!button_pressed) {
		LED_BUT_PRESS_OFF;
		if(DIP_TEST_LED_BUT) {
			//BUZZER_OFF;
		}
		return display_mode;
	}
	
	//button_pressed = 0;
	//buttons_time = 0;
	but_test = 1500;
	
	switch(buttons) {
		case BUTTON1_MASK:
			
			if(buttons_time < GS2R_BUTTONS_FAILURE_COUNTER_MAX)
				display_mode = DEBUG_GS2R_DANGER_C;
			else
				display_mode = DEBUG_GS2R_FAILURE_C;
			
			break;
		case BUTTON2_MASK:
			
			if(buttons_time < GS2R_BUTTONS_FAILURE_COUNTER_MAX)
				display_mode = DEBUG_GS2R_DANGER_X;
			else
				display_mode = DEBUG_GS2R_FAILURE_X;
			
			break;
		default:
			
			break;
	}
	
	return display_mode;
}

#endif //  #ifdef _USE_GS2R_DEVICE_
