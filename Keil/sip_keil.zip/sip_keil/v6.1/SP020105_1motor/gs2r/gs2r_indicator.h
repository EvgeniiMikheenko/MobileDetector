//=============================================================================
//								gs2r_indicator.h
//=============================================================================

#ifndef _GS2r_INDICATOR_H_
#define _GS2r_INDICATOR_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include <board.h>
#include <project.h>

void gs2r_update_leds(int displayMode, uint16_t devMode);

void gs2r_update_disp_rows_dbg(int displayMode, int *lpStatusTmp);

#endif // _GS2r_INDICATOR_H_
