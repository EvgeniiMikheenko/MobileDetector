//=============================================================================
//
//=============================================================================

#ifndef _PID_H_
#define _PID_H_

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

#ifdef __cplusplus
	extern "C" {
#endif // __cplusplus

typedef float (*GetFloat)(void);
typedef void (*SetFloat)(float value);

typedef struct {
	float kP;
	float kI;
	float kD;
	
	float pvMax;
	float pvMin;
	
	float outMax;
	float outMin;
	
	float outValue;
	
	uint32_t lastTime;
	float lastPv;
	float errSum;
	
	bool enable;
	bool isInit;
	bool isStarted;
	bool isIntegralCorrectorEn;
	
	float pValue;
	float iValue;
	float dValue;
	
	GetFloat lpGetPv;
	GetFloat lpGetSp;
	
	SetFloat lpSetOutput;
} PidData_t, *lpPidData_t;


bool pid_init_data(lpPidData_t lpData);

float pid_poll(lpPidData_t lpData);

void pid_enable(lpPidData_t lpData);

void pid_disable(lpPidData_t lpData);

void pid_reset(lpPidData_t lpData);


#ifdef __cplusplus
	}
#endif // __cplusplus

#endif // _PID_H_
