//=============================================================================
//
//=============================================================================

#ifndef _SIP1_H_
#define _SIP1_H_

	#include <board.h>
	#include <project.h>

	#ifdef _USE_SIP1_DEVICE_

		int detect_alarm(int oldStatus);
		
		void test_alarm(bool isFound);

	#endif // _USE_SIP1_DEVICE_

#endif // _SIP1_H_
