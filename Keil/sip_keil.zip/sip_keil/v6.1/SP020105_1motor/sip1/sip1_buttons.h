//=============================================================================
//
//=============================================================================

#ifndef _SIP1_BUTTONS_H_
#define _SIP1_BUTTONS_H_

	#include <board.h>
	#include <project.h>

	#ifdef _USE_SIP1_DEVICE_

		int ext_button_proc(int display_mode);

	#endif // _USE_SIP1_DEVICE_

#endif // _SIP1_BUTTONS_H_
