//=============================================================================
//
//=============================================================================

#include "sip100.h"

#ifdef _USE_SIP100_DEVICE_

extern Params_Struct Params;
extern Flags_t m_flags;
extern int fpga_fail;

int detect_alarm(int oldStatus) {
	if(!DIP_ALARM_ONLY_HACK_BTN)
		return oldStatus;
	//
	if(m_flags.IsModeOk == 0)
		return oldStatus;
	//
	if(fpga_fail)
		return oldStatus;
	//
	if (!((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM))) 
		return oldStatus;
	//
	if (Params.FPGA_IN.PeaksFoundTable[Params.CPU_OUT.Substance].Time) {
		oldStatus++;
	}
	//	
	return oldStatus;
}		

#endif // _USE_SIP100_DEVICE_
