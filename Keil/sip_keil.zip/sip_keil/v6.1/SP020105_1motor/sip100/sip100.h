//=============================================================================
//
//=============================================================================

#ifndef _SIP100_H_
#define _SIP100_H_

	#include <board.h>
	#include <project.h>

	#ifdef _USE_SIP100_DEVICE_

		int detect_alarm(int oldStatus);

	#endif // _USE_SIP100_DEVICE_

#endif // _SIP100_H_
