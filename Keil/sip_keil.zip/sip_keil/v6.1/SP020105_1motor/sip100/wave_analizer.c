//=============================================================================
//								wave_analizer.c
//=============================================================================

#include "wave_analizer.h"
#include "../utils/average_filter.h"
#include "../utils/ton_timer.h"

#ifdef _USE_SIP100_DEVICE_

extern Params_Struct Params;
extern Flags_t m_flags;

float 	convert_raw(uint16_t raw, float min, float max);
uint16_t float_to_raw(float value, float min, float max);

static float dY;
static float dYmin;
static uint16_t yMax;
static uint16_t oldYmax = 0;
static uint16_t downLimit;
static int WAresult = 0;
static int start, end;

static const int FDBufSize = 8;
static uint16_t fdBuf[FDBufSize];
static UshortFilterData_t fdFilter = {
	fdBuf,
	FDBufSize,
	0,
	0,
	0,
	
	0,
		
	false,
	false,
};


static TonTimerData_t upTmrData;
static TonTimerData_t downTmrData;
static OnOffFilterData_t dyUpFData;
static OnOffFilterData_t dyDownFData; 

static bool isDownFound = false;
static bool isUpFound = false;

int test_wave(void) 				{
	static const int xMin = 0;
	static const int xMax = 20;	
	static bool isFirst = true;
	static TonTimerData_t tstTmrData;
	static uint16_t substance = 0;
	
	uint32_t updateTime = 200;
	
	int maxIndex = -1;
	volatile float x1, x2, offset;
	uint16_t rawX1, rawX2;
	int index;
	
	if(isFirst)
		updateTime = 10000;
	
	if(!ton_timer_run(&tstTmrData, updateTime, m_flags.IsModeOk == 1))
		return WAresult;
	
	ton_timer_reset(&tstTmrData);
	isFirst = false;
	
	if(substance != Params.CPU_OUT.Substance) {
		WAresult = 0;
		oldYmax = 0;
	}
	substance = Params.CPU_OUT.Substance;
	
	index = Params.CPU_OUT.Substance * 3;
	
	rawX1 = Params.FPGA_OUT.PeakParamTable[index++];
	rawX2 = Params.FPGA_OUT.PeakParamTable[index];
	
	x1 = convert_raw(rawX1, xMin, xMax);
	x2 = convert_raw(rawX2, xMin, xMax);
	
	downLimit = Params.FPGA_OUT.PeakParamTable[2];
	
	offset = ((float)(xMax - xMin)) / ((float)MAX_POINTS / Params.FPGA_OUT.PointsScale);
	
	start = (int)(x1 / offset);
	if((x1 - (start * offset))  > 0.5)
		start++;
	
	end = (int)(x2 / offset);
	if((end - start) <= 0) {
		WAresult = 0;
		m_flags.IsWaDataInvalid = 1;
		return WAresult;
	}
	else {
		m_flags.IsWaDataInvalid = 0;
	}
	
	if((x2 - (end * offset))  > 0.5)
		end++;
	
	yMax = 0;
	
	for(int i = start; i < end; i++) {		
		if(Params.FPGA_IN.Points[i] < yMax)
			continue;
		
		yMax = Params.FPGA_IN.Points[i];
		maxIndex = i;
	}
	
	isDownFound = false;
	isUpFound = false;
	if(maxIndex > 0) {
		for(int i = start; i < maxIndex; i++) {	
			x1 = convert_raw(yMax, 0.0, 2500.0) - convert_raw(Params.FPGA_IN.Points[i], 0.0, 2500.0);
			if(x1 <= -3)			
				continue;
			
			isUpFound = true;
		}
		
		for(int i = maxIndex; i < end; i++) {	
			x1 = convert_raw(yMax, 0.0, 2500.0) - convert_raw(Params.FPGA_IN.Points[i], 0.0, 2500.0);
			if(x1 <= 3)			
				continue;
			
			isDownFound = true;
		}
	}
	
	if(!(isDownFound && isUpFound)) {
		ton_timer_reset(&upTmrData);
		ton_timer_reset(&downTmrData);
		on_off_filter_reset(&dyUpFData);
		on_off_filter_reset(&dyDownFData);	
		WAresult = 0;
	}
	
	ushort_filter_put(&fdFilter, yMax);
	yMax = ushort_filter_get(&fdFilter);
	dY = convert_raw(yMax, 0.0, 2500.0) - convert_raw(oldYmax, 0.0, 2500.0);
	oldYmax = yMax;
	
	if(!upTmrData.outValue) {
		// ���������� ������
		dYmin = GetMinDyForUp();
		rawX1 = GetOnTimeForUp();
		rawX2 = GetOffTimeForUp();
		
		on_off_filter_run(&dyUpFData, (dY > dYmin) && (yMax >= downLimit), rawX1 /* 200 */, rawX2 /* 500 */);
		
		if(ton_timer_run(&upTmrData, 200, (dyUpFData.outValue) || (upTmrData.outValue))) {
			WAresult = 1;
			ton_timer_reset(&downTmrData);
			on_off_filter_reset(&dyDownFData);
		}
	}
	else {
		// ���������� ����
		dYmin = GetMinDyForDown();		
		dYmin *= (-1);
		
		rawX1 = GetOnTimeForDown();
		rawX2 = GetOffTimeForDown();
		
		on_off_filter_run(&dyDownFData, (dY < dYmin) && (yMax >= downLimit), rawX1 /* 800 */, rawX2 /* 450 */);
		
		if(ton_timer_run(&downTmrData, 1000, (dyDownFData.outValue))) {
			WAresult = -1;
			ton_timer_reset(&upTmrData);
			ton_timer_reset(&downTmrData);
			on_off_filter_reset(&dyUpFData);
		}
	}
	
	if((yMax < downLimit) || (m_flags.IsWaReset == 1)){
		ton_timer_reset(&upTmrData);
		ton_timer_reset(&downTmrData);
		on_off_filter_reset(&dyUpFData);
		on_off_filter_reset(&dyDownFData);	
		WAresult = 0;
		if(m_flags.IsWaReset == 1) {
			m_flags.IsWaReset = 0;
		}
	}
	
	return WAresult;
}

static float deltaY = 5.0;

int test_wave2(void) 				{
	static const int xMin = 0;
	static const int xMax = 20;
	static bool isFirst = true;
	
	static TonTimerData_t tstTmrData;
	static uint16_t substance = 0;
	
	uint32_t updateTime = 200;
	volatile float x1, x2, offset;
	uint16_t rawX1, rawX2;
	int index;
	
	if(isFirst)
		updateTime = 10000;
	
	if(!ton_timer_run(&tstTmrData, updateTime, m_flags.IsModeOk == 1))
		return WAresult;
	
	ton_timer_reset(&tstTmrData);
	
	if(substance != Params.CPU_OUT.Substance) {
		WAresult = 0;
		oldYmax = 0;
	}
	substance = Params.CPU_OUT.Substance;
	
	index = Params.CPU_OUT.Substance * 3;
	
	rawX1 = Params.FPGA_OUT.PeakParamTable[index++];
	rawX2 = Params.FPGA_OUT.PeakParamTable[index];
	
	x1 = convert_raw(rawX1, xMin, xMax);
	x2 = convert_raw(rawX2, xMin, xMax);
	
	downLimit = Params.FPGA_OUT.PeakParamTable[2];
	
	offset = ((float)(xMax - xMin)) / ((float)MAX_POINTS / Params.FPGA_OUT.PointsScale);
	
	start = (int)(x1 / offset);
	if((x1 - (start * offset))  > 0.5)
		start++;
	
	end = (int)(x2 / offset);
	if((end - start) <= 0) {
		WAresult = 0;
		m_flags.IsWaDataInvalid = 1;
		return WAresult;
	}
	else {
		m_flags.IsWaDataInvalid = 0;
	}
	
	if((x2 - (end * offset))  > 0.5)
		end++;
	
	yMax = 0;
	
	for(int i = start; i < end; i++) {		
		if(Params.FPGA_IN.Points[i] < yMax)
			continue;
		
		yMax = Params.FPGA_IN.Points[i];
	}
	
	ushort_filter_put(&fdFilter, yMax);
	yMax = ushort_filter_get(&fdFilter);
	dY = convert_raw(yMax, 0.0, 2500.0) - convert_raw(oldYmax, 0.0, 2500.0);
	
	if(isFirst) {
		oldYmax = yMax;
		isFirst = false;
		return WAresult;
	}
	
	if(fabs(dY) >= deltaY) {
		oldYmax = yMax;
		if(dY > 0)
			WAresult = 1;
		else
			WAresult = -1;
	}
	
	if((yMax < downLimit) || (m_flags.IsWaReset == 1)){
		ton_timer_reset(&upTmrData);
		ton_timer_reset(&downTmrData);
		on_off_filter_reset(&dyUpFData);
		on_off_filter_reset(&dyDownFData);	
		WAresult = 0;
		if(m_flags.IsWaReset == 1) {
			m_flags.IsWaReset = 0;
		}
	}
	
	return WAresult;
}

float convert_raw(uint16_t raw, float min, float max) {
	float result = min + (((max - min) * (float)raw) / 65535.0);
	return result;
}

uint16_t float_to_raw(float value, float min, float max) {
	uint16_t result = (uint16_t)(((max - min) * 65535.0) / max);
	return result;
}

#endif // _USE_SIP100_DEVICE_
