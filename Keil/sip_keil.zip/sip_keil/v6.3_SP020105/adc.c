//=============================================================================
//							adc.h
//=============================================================================

#include "adc.h"

//-----------------------------------------------------------------------------
//
int FilterBuf(unsigned short int *buf, unsigned short int* sortbuf, 
			  short int buf_pointer, unsigned short int newvalue);

int adc_channel = 0;
ADC_Data_Struct ADC_Data[8];

unsigned short int ADC_Buf[ADC_CHANNEL_COUNT][ADC_BUF_SIZE];
unsigned short int ADC_BufSort[ADC_CHANNEL_COUNT][ADC_BUF_SIZE];

unsigned int ADC_Buf_Pointer = 0;
int ADC_Buf_Full = 0;

unsigned int Read_ADC(void) {
	unsigned int temp;
	uint32_t time;
	static const uint32_t timeout = 1000;
	bool isTimeout;

	LPC_SSP1->CPSR = 0x10;
	LPC_SSP1->CR0 = 7; //8bit mode;
	ADC_CS_ON;
	LPC_SSP1->DR = 0x87 + (adc_channel << 4);

	time = GetSystemTime();
	isTimeout = false;
	while ((LPC_SSP1->SR & 0x10)) {
		if((GetSystemTime() - time) >= timeout) {
			isTimeout = true;
			break;
		}
	}
	
	if(isTimeout) {
		ADC_CS_OFF;
		return 0;
	}
		
	int x = LPC_SSP1->DR;

	LPC_SSP1->CR0 = 0x87; //8bit mode; //CPHA=1;
	//LPC_SSP1->CR0 = 0xF; //16bit mode;
	
	time = GetSystemTime();
	isTimeout = false;
	
	LPC_SSP1->DR = 0x00;
	while ((LPC_SSP1->SR & 0x10)) {
		if((GetSystemTime() - time) >= timeout) {
			isTimeout = true;
			break;
		}
	}
	
	if(isTimeout) {
		ADC_CS_OFF;
		return 0;
	}
	
	time = GetSystemTime();
	isTimeout = false;
	
	temp = (LPC_SSP1->DR);
	LPC_SSP1->DR = 0x0;
	while ((LPC_SSP1->SR & 0x10)) {
		if((GetSystemTime() - time) >= timeout) {
			isTimeout = true;
			break;
		}
	}
	
	if(isTimeout) {
		ADC_CS_OFF;
		return 0;
	}
	
	time = GetSystemTime();
	isTimeout = false;	
	
	temp = ((temp << 8) + ((LPC_SSP1->DR) & 0xFF)) & 0xFFFF;
	LPC_SSP1->DR = 0x0;
	while ((LPC_SSP1->SR & 0x10)) {
		if((GetSystemTime() - time) >= timeout) {
			isTimeout = true;
			break;
		}
	}
	
	if(isTimeout) {
		ADC_CS_OFF;
		return 0;
	}
		
	ADC_CS_OFF;
	temp = 32768 + ((temp << 1) + ((LPC_SSP1->DR >> 7) & 0x1)) & 0xFFFF;
	if ((temp > ADC_Data[adc_channel].Error_Low) && (temp < ADC_Data[adc_channel].Error_High)) {
		ADC_Data[adc_channel].Data = FilterBuf(ADC_Buf[adc_channel], ADC_BufSort[adc_channel], ADC_Buf_Pointer, temp);
		ADC_Data[adc_channel].Fail = 0;
	}
	else if (ADC_Data[adc_channel].Fail++ > ADC_FAIL_COUNT)
		ADC_Data[adc_channel].Fail = ADC_FAIL_COUNT;

	int count = ADC_CHANNELS_COUNT_MAX;
	do {
		adc_channel = adc_channel + 1;
		ADC_Buf_Pointer += (adc_channel >> 3);
		ADC_Buf_Pointer &= 0x1F;
		adc_channel &= 7;
		if((count--) < 0)
			break;
		//
	} while (!ADC_Data[adc_channel].Enable);

	return ADC_Data[adc_channel].Data;
}

float ADC_Temp(unsigned ADC) {
	float f;
	f = ADC;
	
	if (f != 16384)
		f = (f - 16384) / 2.5869473684210526315789473684211;
	else
		f = 0;
	
	return f;
}

float ADC_Temp_Case(unsigned ADC) {
	float f;
	f = ADC;
	f = 9 + (f - 7209) / 2.5690112;
	return f;
}

float ADC_Pressure(unsigned ADC) {
	float f;
	f = ADC * 1000;
	f = 10 * (((f / 65536) + 95) / 0.009) / 101325 * 760;
	return f;
}

float ADC_Humidity(unsigned ADC) {
	float f;
	//unsigned short adc;
	//adc = ADC;
	f = 10 * (ADC - 0.16 * 65536) / 0.0062 / 65536;
	return f;
}


float ADC_Flow(unsigned ADC) {
	float result;
	float x = ADC;
	x -= 65536 * 0.5 / 5;
	result = 10 * (-0.03660440140586697 + x * 
							(0.02166941708084123 + x * 
								(- 6.068288333624556E-06 + x * 
									(2.624003433615297E-09 + x * 
										(- 5.675467037042716E-13 + x * 
											(6.905830872487771E-17 + x * 
												(- 4.904722312866028E-21 + x * 
													(2.004346783270443E-25 + x * 
														(- 4.337710596174231E-30 + x * 3.837724022122646E-35)
													)
												)
											)
										)
									)
								)
							)
						);
	return result;
}

int FilterBuf(unsigned short int *buf, unsigned short int *sortbuf, 
			  short int buf_pointer, unsigned short int newvalue) {
				  
	int                i = 0, n;
	char               f;
	long               s;
	unsigned short int ret_val, t;

	buf[buf_pointer] = newvalue;
	for (i = 0; i < ADC_BUF_SIZE; i++) {
		sortbuf[i] = buf[i];
	}
	
	n = ADC_BUF_SIZE;
	f = 1;
	while (f) {
		n--;
		f = 0;
		
		for (i = 0; i < n; i++) {
			if (sortbuf[i] < sortbuf[i + 1]) {
				t = sortbuf[i];
				sortbuf[i] = sortbuf[i + 1];
				sortbuf[i + 1] = t;
				f = 1;
			}
		}
	}

	for (i = ADC_BUF_LOW, s = 0; i < ADC_BUF_HIGH; i++) {
		s += sortbuf[i];
	}
	
	ret_val = s / (ADC_BUF_HIGH - ADC_BUF_LOW);
	return ret_val;
}

void init_adc_data(void) {
	ADC_Data[0].Error_Low = 3000;
	ADC_Data[0].Error_High = 40000;
	ADC_Data[0].Fail_Param =FAIL_FLAG_FLOW1;
	ADC_Data[0].Enable = (ADC_CHANNELS_MASK & ADC_CH0) ? true : false;

	ADC_Data[1].Error_Low = 40000;
	ADC_Data[1].Error_High = 60000;
	ADC_Data[1].Fail_Param =FAIL_FLAG_AIRP;
	ADC_Data[1].Enable = (ADC_CHANNELS_MASK & ADC_CH1) ? true : false;

	ADC_Data[2].Error_Low = 9830;
	ADC_Data[2].Error_High = 52428;  //Humidity
	ADC_Data[2].Fail_Param =0;
	ADC_Data[2].Enable = (ADC_CHANNELS_MASK & ADC_CH2) ? true : false;

	ADC_Data[3].Error_Low = 12000;
	ADC_Data[3].Error_High = 20000;
	ADC_Data[3].Fail_Param =FAIL_FLAG_TEMP1;
	ADC_Data[3].Enable = (ADC_CHANNELS_MASK & ADC_CH3) ? true : false;

	ADC_Data[4].Error_Low = 1000;
#ifdef USE_FLOW_IN_LGAR_SENSOR2
	ADC_Data[4].Error_High = 60000;
#else
	ADC_Data[4].Error_High = 40000;
#endif // USE_FLOW_IN_LGAR_SENSOR2
	ADC_Data[4].Fail_Param =FAIL_FLAG_FLOW2;
	ADC_Data[4].Enable = (ADC_CHANNELS_MASK & ADC_CH4) ? true : false;

	ADC_Data[5].Error_Low = 0;
	ADC_Data[5].Error_High = 65535;
	ADC_Data[5].Fail_Param =0;
	ADC_Data[5].Enable = (ADC_CHANNELS_MASK & ADC_CH5) ? true : false;
	
	ADC_Data[6].Error_Low = 12000;
	ADC_Data[6].Error_High = 20000;
	ADC_Data[6].Fail_Param =FAIL_FLAG_TEMP2;
	ADC_Data[6].Enable = (ADC_CHANNELS_MASK & ADC_CH6) ? true : false;

	ADC_Data[7].Error_Low = 6000;
	ADC_Data[7].Error_High = 9000;
	ADC_Data[7].Fail_Param =0;
	ADC_Data[7].Enable = (ADC_CHANNELS_MASK & ADC_CH7) ? true : false;
}
