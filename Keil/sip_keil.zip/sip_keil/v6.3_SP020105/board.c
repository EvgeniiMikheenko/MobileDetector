//=============================================================================
//							        board.c
//=============================================================================

#include "board.h"
#include "project.h"

#include <stdlib.h>
#include <stdint.h>


#define _TEST_PINS_

volatile uint32_t m_systemTime = 0;


//-----------------------------------------------------------------------------
//
void Timer0_init(void);
void Timer1_init(void);
//void Timer2_init(void);

void RIT_init(void);
void pins_init(void);

uint32_t GetSystemTime(void) { return m_systemTime; }

void Board_Tick(void) { m_systemTime++; }
//-----------------------------------------------------------------------------


void board_init(void) {
	
	pins_init();
	
	Timer0_init();
	Timer1_init();
	//Timer2_init();
	RIT_init();
	
	LPC_RTC->CCR = 1;
	
	LPC_GPDMA->DMACConfig = 1;
	LPC_GPDMA->DMACSync = 0x0;
	
	LPC_SSP1->CR0 = 0xF;
	LPC_SSP1->CR1 = 0x2;
	LPC_SSP1->CPSR = 0x80;
	LPC_SSP1->IMSC = 0x0;
	
	LPC_SSP0->CR0 = 0xF;
	LPC_SSP0->CR1 = 0x6;
	LPC_SSP0->CPSR = 0x2;
	LPC_SSP0->IMSC = 0x0;
	LPC_SSP0->DMACR = 0x3;

//	RS485_LCR = 0x83;
//	RS485_DLL = UART_DIVISOR & 0xFF;
//	RS485_DLM = (UART_DIVISOR >> 8) & 0xFF;
//	RS485_LCR = 0x3;

//	RS485_IER = 0x7;
//	RS485_FCR = 0x81;

	HV_LCR = 0x83;
	HV_DLL = UART_DIVISOR & 0xFF;
	HV_DLM = (UART_DIVISOR >> 8) & 0xFF;
	HV_LCR = 0x3;

	HV_IER = 0x7;
	HV_FCR = 0x41; //FIFO level=4

	// LPC_PWM1 clock = 100 MHz
	LPC_PWM1->MR0 = PWM1_CYCLES_COUNT; // 100 MHz / PWM1_CYCLES_COUNT(2048) = 48.828 kHz
	LPC_PWM1->LER = 0xff;
//	LPC_PWM1->MR3 = 0; // PWM1.3 duty = 0
//	LPC_PWM1->MR4 = 0; // PWM1.4 duty = 0
	LPC_PWM1->TCR = 0x2;
	LPC_PWM1->MCR = 0x2;
	LPC_PWM1->TCR = 0x9;
	LPC_PWM1->PCR = 0x7E00;
}

void Timer0_init(void) {
	
	TIM_TIMERCFG_Type TMR0_Cfg;
	TIM_MATCHCFG_Type TMR0_Match;
		
	/* On reset, Timer0/1 are enabled (PCTIM0/1 = 1), and Timer2/3 are disabled (PCTIM2/3 = 0).*/
	/* Initialize timer 0, prescale count time of 100uS */
	TMR0_Cfg.PrescaleOption = TIM_PRESCALE_USVAL;
	TMR0_Cfg.PrescaleValue = 10;
	/* Use channel 0, MR0 */
	TMR0_Match.MatchChannel = 0;
	/* Enable interrupt when MR0 matches the value in TC register */
	TMR0_Match.IntOnMatch = ENABLE;		
	/* Enable reset on MR0: TIMER will reset if MR0 matches it */
	TMR0_Match.ResetOnMatch = TRUE;		
	/* Don't stop on MR0 if MR0 matches it*/
	TMR0_Match.StopOnMatch = FALSE;
	/* Do nothing for external output pin if match (see cmsis help, there are another options) */
	TMR0_Match.ExtMatchOutputType = TIM_EXTMATCH_NOTHING;
	/* Set Match value, count value of 100 (100 * 10uS = 1000us = 0.001s --> 1000 Hz) */
	TMR0_Match.MatchValue = 100;		
	/* Set configuration for Tim_config and Tim_MatchConfig */
	TIM_Init(LPC_TIM0, TIM_TIMER_MODE, &TMR0_Cfg);
	TIM_ConfigMatch(LPC_TIM0, &TMR0_Match);
	
	/* Set priority */
	NVIC_SetPriority(TIMER0_IRQn, TIMER0_PRIORITY);
	/* Enable interrupt for timer 0 */
	NVIC_EnableIRQ(TIMER0_IRQn);	
	/* Start timer 0 */
	TIM_Cmd(LPC_TIM0, ENABLE);
}

//void Timer2_init(void) {
//	
//	TIM_TIMERCFG_Type TMR2_Cfg;
//	TIM_MATCHCFG_Type TMR2_Match;
//		
//	/* On reset, Timer0/1 are enabled (PCTIM0/1 = 1), and Timer2/3 are disabled (PCTIM2/3 = 0).*/
//	/* Initialize timer 0, prescale count time of 100uS */
//	TMR2_Cfg.PrescaleOption = TIM_PRESCALE_USVAL;
//	TMR2_Cfg.PrescaleValue = 10;
//	/* Use channel 0, MR0 */
//	TMR2_Match.MatchChannel = 0;
//	/* Enable interrupt when MR0 matches the value in TC register */
//	TMR2_Match.IntOnMatch = ENABLE;		
//	/* Enable reset on MR0: TIMER will reset if MR0 matches it */
//	TMR2_Match.ResetOnMatch = TRUE;		
//	/* Don't stop on MR0 if MR0 matches it*/
//	TMR2_Match.StopOnMatch = FALSE;
//	/* Do nothing for external output pin if match (see cmsis help, there are another options) */
//	TMR2_Match.ExtMatchOutputType = TIM_EXTMATCH_NOTHING;
//	/* Set Match value, count value of 100 (100 * 10uS = 1000us = 0.001s --> 1000 Hz) */
//	TMR2_Match.MatchValue = 100;		
//	/* Set configuration for Tim_config and Tim_MatchConfig */
//	TIM_Init(LPC_TIM2, TIM_TIMER_MODE, &TMR2_Cfg);
//	TIM_ConfigMatch(LPC_TIM2, &TMR2_Match);
//	
//	/* Set priority */
//	NVIC_SetPriority(TIMER2_IRQn, TIMER2_PRIORITY);
//	/* Enable interrupt for timer 0 */
//	NVIC_EnableIRQ(TIMER2_IRQn);	
//	/* Start timer 0 */
//	TIM_Cmd(LPC_TIM2, ENABLE);
//}

void Timer1_init       (void) {
	TIM_TIMERCFG_Type TMR1_Cfg;
	TIM_CAPTURECFG_Type TMR1_Capture;
		
//	/* On reset, Timer0/1 are enabled (PCTIM0/1 = 1), and Timer2/3 are disabled (PCTIM2/3 = 0).*/
//	/* Initialize timer 0, prescale count time of 100uS */
	TMR1_Cfg.PrescaleOption = TIM_PRESCALE_USVAL;
	TMR1_Cfg.PrescaleValue = 1;
	//
	/* Capture channel 1 */
	TMR1_Capture.CaptureChannel = 1;
	/* Capture on rising edge enable */
	TMR1_Capture.RisingEdge = ENABLE;
	/* Capture on falling edge enable */
	TMR1_Capture.FallingEdge = ENABLE;
	/* Capture interrupt enable */
	TMR1_Capture.IntOnCaption = ENABLE;
	//
	TIM_Init(LPC_TIM1, TIM_TIMER_MODE, &TMR1_Cfg);
	TIM_ConfigCapture(LPC_TIM1, &TMR1_Capture);
	
	/* Set priority */
	NVIC_SetPriority(TIMER1_IRQn, TIMER1_PRIORITY);
	/* Enable interrupt for timer 1 */
	NVIC_EnableIRQ(TIMER1_IRQn);	
	/* Start timer 1 */
	TIM_Cmd(LPC_TIM1, ENABLE);
}



void pins_init(void) {
	PINSEL_CFG_Type pinCfg;
	//
	LPC_PINCON->PINSEL0 = 0x400A800A;

	LPC_PINCON->PINMODE0 = 0x802FC0AA;

	LPC_PINCON->PINSEL1 = 0x14000001;
	LPC_PINCON->PINMODE1 = 0x282A802A;

	LPC_PINCON->PINSEL2 = 0x00000000;
	LPC_PINCON->PINMODE2 = 0x0002020A;

	LPC_PINCON->PINSEL3 = 0x2003CFC0;
	LPC_PINCON->PINMODE3 = 0x2A8A8A2E;

	LPC_PINCON->PINSEL4 = 0x00080540;
	LPC_PINCON->PINMODE4 = 0x0A8A8200;

	LPC_GPIO0->FIODIR = 0x0786848D;

	LPC_GPIO1->FIODIR = 0x0A870113;

	LPC_GPIO2->FIODIR = 0x00001138;

	LPC_GPIO4->FIODIR = 0x30000000;
	LPC_GPIO2->FIODIR	&= ~((1 << 1) | (1 << 0) | (1 << 2));
	LPC_PINCON->PINSEL4 |= 1;
	LPC_PINCON->PINMODE4 |= 1 << 1;
	LPC_GPIO3->FIODIR |= 1 << 26;
	
#ifdef _USE_SIP1_DEVICE_

	// HUB_PUMP2
	pinCfg.Portnum = HUB_PUMP2_PORT;
	pinCfg.Pinnum = HUB_PUMP2_PIN_NUM;
	pinCfg.Pinmode = PINSEL_PINMODE_PULLDOWN;
	pinCfg.Funcnum = PINSEL_FUNC_0;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(HUB_PUMP2_PORT, HUB_PUMP2_PIN, 1);
	GPIO_ClearValue(HUB_PUMP2_PORT, HUB_PUMP2_PIN);
	
	// HUB_PUMP1
	pinCfg.Portnum = HUB_PUMP1_PORT;
	pinCfg.Pinnum = HUB_PUMP1_PIN_NUM;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(HUB_PUMP1_PORT, HUB_PUMP1_PIN, 1);
	GPIO_ClearValue(HUB_PUMP1_PORT, HUB_PUMP1_PIN);
	
	// HUB_VALVE
	pinCfg.Portnum = HUB_VALVE_PORT;
	pinCfg.Pinnum = HUB_VALVE_PIN_NUM;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(HUB_VALVE_PORT, HUB_VALVE_PIN, 1);
	GPIO_ClearValue(HUB_VALVE_PORT, HUB_VALVE_PIN);
	
#endif // _USE_SIP1_DEVICE_
	
	// HACK BUTTON
//	pinCfg.Portnum = HACK_BTN_PORT;
//	pinCfg.Pinnum = HACK_BTN_PIN_NUM;
//	pinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
//	PINSEL_ConfigPin(&pinCfg);
//	GPIO_SetDir(HACK_BTN_PORT, HACK_BTN_PIN, 0);

	// DIP1
	pinCfg.Portnum = DIP1_PORT;
	pinCfg.Pinnum = DIP1_PIN_NUM;
	pinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
	pinCfg.Funcnum = PINSEL_FUNC_0;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(DIP1_PORT, DIP1_PIN, 0);
	
	// DIP2
	pinCfg.Portnum = DIP2_PORT;
	pinCfg.Pinnum = DIP2_PIN_NUM;
	pinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	pinCfg.Funcnum = PINSEL_FUNC_0;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(DIP2_PORT, DIP2_PIN, 0);
	
	// DIP3
	pinCfg.Portnum = DIP3_PORT;
	pinCfg.Pinnum = DIP3_PIN_NUM;
	pinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	pinCfg.Funcnum = PINSEL_FUNC_0;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(DIP3_PORT, DIP3_PIN, 0);
	
	// DIP4
	pinCfg.Portnum = DIP4_PORT;
	pinCfg.Pinnum = DIP4_PIN_NUM;
	pinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	pinCfg.Funcnum = PINSEL_FUNC_0;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(DIP4_PORT, DIP4_PIN, 0);
	
	// DIP5
	pinCfg.Portnum = DIP5_PORT;
	pinCfg.Pinnum = DIP5_PIN_NUM;
	pinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	pinCfg.Funcnum = PINSEL_FUNC_0;
	PINSEL_ConfigPin(&pinCfg);
	GPIO_SetDir(DIP5_PORT, DIP5_PIN, 0);
	
	// M2 PWM1.3
	pinCfg.Portnum = 3;
	pinCfg.Pinnum = 26;
	pinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
	pinCfg.Funcnum = PINSEL_FUNC_3;
	PINSEL_ConfigPin(&pinCfg);
}

void RIT_init(void) {
//	LPC_RIT->RICOMPVAL = 25000000 / T_QUANT; //PCLK/4/1000;
//	LPC_RIT->RICTRL = 0xA;
//	LPC_RIT->RICOUNTER = 0;
	//
	RIT_Init(LPC_RIT);
	RIT_TimerConfig(LPC_RIT, RIT_TIME_INTERVAL_MS);
	
	NVIC_SetPriority(RIT_IRQn, RIT_PRIORITY);
	NVIC_EnableIRQ(RIT_IRQn);
	RIT_Cmd(LPC_RIT, ENABLE);
}

//void TIMER2_IRQHandler(void) {
//	TIM_ClearIntPending(LPC_TIM2, TIM_MR2_INT);
//	m_systemTime++;
//}
