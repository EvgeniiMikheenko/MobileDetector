//=============================================================================
//									flow_in.h
//=============================================================================

#ifndef _FLOW_IN_H_
#define _FLOW_IN_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "../board.h"
#include "../project.h"

void flow_in_set_pid_enable(bool en);
void flow_in_pid_poll(void);
void flow_in_set_pid_factors(void);
void flow_in_update_pid_data(void);
uint16_t flow_in_get_power_value(void);

#endif // _FLOW_IN_H_
