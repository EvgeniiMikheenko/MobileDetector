//=============================================================================
//									heater1.h
//=============================================================================

#ifndef _HEATER1_H_
#define _HEATER1_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "board.h"
#include "project.h"

int 	GetTreg(void);
float 	GetTemp1Sp(void);
float 	GetTemp1Pv(void);

void heater1_init(void);
void heater1_set_enable(bool en);
void heater1_reset(void);
void heater1_pid_poll(void);
void heater1_set_pid_factors(void);
void heater1_update_pid_data(void);
void heater1_soft_pwm_poll(void);

uint16_t heater1_get_power_value(void);

#endif // _HEATER1_H_
