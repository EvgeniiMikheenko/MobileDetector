//=============================================================================
//								hub.h
//=============================================================================

#ifndef _HUB_H_
#define _HUB_H_

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "LPC17xx.h"

#include "board.h"
#include "project.h"

extern Params_Struct Params;

#define HUB_TEMP_P1 				Params.CPU_IN.Dummy[0]
#define HUB_TEMP_P2 				Params.CPU_IN.Dummy[1]

#define MS_PER_SEC					1000

#define SEK 						1000
#define HUB_T1 						(Params.CPU_IN.HubT1 * SEK)
#define HUB_T2 						(HUB_T1 + Params.CPU_IN.HubT2 * SEK)
#define HUB_T3 						(HUB_T2 + Params.CPU_IN.HubT3 * SEK)
#define HUB_T4 						(HUB_T3 + Params.CPU_IN.HubT4 * SEK)

#define HUB_PWR_MAX					15

#define HUB_START_DELAY				5000
#define HUB_OFF_DELAY				60000

typedef enum {
	StOff,
	StT1,
	StT2,
	StT3,
	StT4
} HubSTate_t;

//void Hub(void);
void hub_poll(void);

void hub_heater_off(void);

void hub_set_pwm_value(bool value);

void hub_set_t3(void);
void hub_set_t4(void);

static __inline uint32_t GetT1Time() { return Params.CPU_IN.Dummy[HUB_T1_PARAM_INDEX] * MS_PER_SEC; }
static __inline uint32_t GetT2Time() { return Params.CPU_IN.Dummy[HUB_T2_PARAM_INDEX] * MS_PER_SEC; }
static __inline uint32_t GetT3Time() { return Params.CPU_IN.Dummy[HUB_T3_PARAM_INDEX] * MS_PER_SEC; }
static __inline uint32_t GetT4Time() { return Params.CPU_IN.Dummy[HUB_T4_PARAM_INDEX] * MS_PER_SEC; }

int get_hub_state(void);

uint32_t get_hub_time_left(void);

#endif // _HUB_H_
