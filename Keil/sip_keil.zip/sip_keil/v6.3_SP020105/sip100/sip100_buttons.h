//=============================================================================
//								sip100_buttons.h
//=============================================================================

#ifndef _SIP100_BUTTONS_H_
#define _SIP100_BUTTONS_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include <board.h>
#include <project.h>

#ifdef _USE_SIP100_DEVICE_

	int button_proc(int display_mode);

#endif // _USE_SIP100_DEVICE_

#endif // _SIP100_BUTTONS_H_
