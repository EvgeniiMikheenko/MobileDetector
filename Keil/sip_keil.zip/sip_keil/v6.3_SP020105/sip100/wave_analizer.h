//=============================================================================
//								wave_analizer.h
//=============================================================================

#ifndef _WAVE_ANALIZER_H_
#define _WAVE_ANALIZER_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "../board.h"
#include "../project.h"

int 	test_wave(void);
int 	test_wave2(void);

#endif // _WAVE_ANALIZER_H_
