//=============================================================================
//								sip_ship_buttons.h
//=============================================================================

#ifndef _SIP_SHIP_BUTTONS_H_
#define _SIP_SHIP_BUTTONS_H_

	#include <stdlib.h>
	#include <stdint.h>
	#include "LPC17xx.h"

	#include <board.h>
	#include <project.h>

	#ifdef _USE_SIP_SHIP_DEVICE_

		int button_proc(int display_mode);

	#endif // _USE_SIP_SHIP_DEVICE_

#endif // _SIP_SHIP_BUTTONS_H_
