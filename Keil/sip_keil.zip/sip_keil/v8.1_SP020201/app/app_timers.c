//=============================================================================
//								app_timers.c
//=============================================================================

#include "app_timers.h"

OnOffFilterData_t m_onOfTimersData[OnOffTimersCount];

bool run_on_off_timer(uint8_t num, bool en, uint32_t onTime, uint32_t offTime) {
	if(num >= OnOffTimersCount)
		return false;
	
	return on_off_filter_run(&m_onOfTimersData[num], en, onTime, offTime);
}

void reset_on_off_timer(uint8_t num) {
	if(num >= OnOffTimersCount)
		return;
	
	on_off_filter_reset(&m_onOfTimersData[num]);
}

bool get_timer_value(uint8_t num) {
	if(num >= OnOffTimersCount)
		return false;
	
	return m_onOfTimersData[num].outValue;
}
