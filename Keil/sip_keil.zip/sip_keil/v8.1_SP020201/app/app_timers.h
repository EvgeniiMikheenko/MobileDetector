//=============================================================================
//								app_timers.h
//=============================================================================

#ifndef _APP_TIMERS_H_
#define _APP_TIMERS_H_

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "project.h"

#include <ton_timer.h>

static const int OnOffTimersCount = 11;

//static const int TimerIndexTemp1OutOfRange = 0;
//static const int TimerIndexFlowOutOfRange = 1;
//static const int TimerIndexAlarmEnable = 2;
//static const int TimerIndexSetHV = 3;
//static const int TimerIndexFlowStable = 4;
//static const int TimerIndexTemp1Stable = 5;

typedef enum {
	//TimerIndexTemp1OutOfRange = 0,
	TimerIndexFlowOutOfRange,
	TimerIndexAlarmEnable,
	TimerIndexSetHV,
	TimerIndexFlowStable,
	TimerIndexTemp1Stable,
	TimerIndexLockAlarm,
	TimerIndexDeviceAlarmOff,
	TimerIndexZone1Found,
	TimerIndexZone2Found,
	TimerIndexZone3Found,
	TimerIndexZone4Found
} AppTimerIndexes;

bool run_on_off_timer(uint8_t num, bool en, uint32_t onTime, uint32_t offTime);

bool get_timer_value(uint8_t num);

void reset_on_off_timer(uint8_t num);

static bool get_alarm_status(void) { return get_timer_value(TimerIndexAlarmEnable);}

#endif // _APP_TIMERS_H_
