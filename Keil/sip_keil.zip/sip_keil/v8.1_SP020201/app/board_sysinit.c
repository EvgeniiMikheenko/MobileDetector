//=============================================================================
//
//=============================================================================

#include "board_sysinit.h"
#include "project.h"

/* Pin muxing configuration */
STATIC const PinMux_t pinmuxing[] = {
	{0x0, 0,  PINSEL_FUNC_2 , PINSEL_PINMODE_TRISTATE},		/* P0.0	: TXD3 (HV_TX)				(Pin 46) */
	{0x0, 1,  PINSEL_FUNC_2 , PINSEL_PINMODE_TRISTATE},		/* P0.1	: RXD3 (HV_RX)				(Pin 47) */
	{0x0, 2,  PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.2	: ADC_CNV_START				(Pin 98) */
	{0x0, 3,  PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.3	: IND_CS 					(Pin 99) */
	{0x0, 4,  PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.4	: DIP12 					(Pin 81) */
	{0x0, 5,  PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.5	: DIP11 					(Pin 80) */
	{0x0, 6,  PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.6	: DIP10 					(Pin 79) */
	{0x0, 7,  PINSEL_FUNC_2 , PINSEL_PINMODE_PULLDOWN},		/* P0.7	: SCK1 						(Pin 78) */
	{0x0, 8,  PINSEL_FUNC_2 , PINSEL_PINMODE_PULLDOWN},		/* P0.8	: MISO1 					(Pin 77) */
	{0x0, 9,  PINSEL_FUNC_2 , PINSEL_PINMODE_PULLDOWN},		/* P0.9	: MOSI1 					(Pin 76) */
	{0x0, 10, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.10: DCLK 						(Pin 48) */
	{0x0, 11, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.11: CONF_DONE 				(Pin 49) */
	{0x0, 15, PINSEL_FUNC_1 , PINSEL_PINMODE_TRISTATE},		/* P0.15: TXD1 (RS485) 				(Pin 62) */
	{0x0, 16, PINSEL_FUNC_1 , PINSEL_PINMODE_TRISTATE},		/* P0.16: RXD1 (RS485)				(Pin 63) */
	{0x0, 17, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.17: RS485_DE 					(Pin 61) */
	{0x0, 18, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.18: RS485_RE 					(Pin 60) */
	{0x0, 19, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.19: DIP1 						(Pin 59) */
	{0x0, 20, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.20: DIP2 						(Pin 58) */
	{0x0, 21, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.21: DIP3 						(Pin 57) */
	{0x0, 22, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P0.22: DIP4 						(Pin 56) */
	{0x0, 23, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.23: LED2 						(Pin 9) */
	{0x0, 24, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.24: LED3 						(Pin 8) */
	{0x0, 25, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.25: LED_PG 					(Pin 7) */
	{0x0, 26, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P0.26: LED1 						(Pin 6) */
	//{0x0, 27, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},	/* P0.27: */
	//{0x0, 28, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},	/* P0.28: */
	{0x0, 29, PINSEL_FUNC_1 , PINSEL_PINMODE_TRISTATE},		/* P0.29: USB_D+ 					(Pin 29) */
	{0x0, 30, PINSEL_FUNC_1 , PINSEL_PINMODE_TRISTATE},		/* P0.30: USB_D- 					(Pin 30) */
	
	/* GPIO 1*/
	{0x1, 0, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.0	: DIP9	 					(Pin 95) */
	{0x1, 1, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.1	: DIP7 						(Pin 94) */
	{0x1, 4, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.4	: DANGER_C 					(Pin 93) */
	{0x1, 8, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.8	: FAILURE_C 				(Pin 92) */
	{0x1, 9, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.9	: BUTTON_SIP2 				(Pin 91) */
	{0x1, 10, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.10: BUTTON_SIP1 				(Pin 90) */
	{0x1, 14, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.14: BUTTON_P 					(Pin 89) */
	{0x1, 15, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.15: BUTTON_SIP3 				(Pin 88) */
	{0x1, 16, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.16: FAILURE_X 				(Pin 87) */
	{0x1, 17, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.17: DANGER_X 					(Pin 86) */
	{0x1, 18, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.18: nCONFIG 					(Pin 32) */ 
	{0x1, 19, PINSEL_FUNC_3 , PINSEL_PINMODE_PULLUP},		/* P1.19: CAP1.1 (FPGA_DR) 			(Pin 33) */
	{0x1, 20, PINSEL_FUNC_3 , PINSEL_PINMODE_TRISTATE},		/* P1.20: SCK0 						(Pin 34) */
	{0x1, 21, PINSEL_FUNC_3 , PINSEL_PINMODE_TRISTATE},		/* P1.21: CS_FPGA 					(Pin 35) */ 
	{0x1, 22, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P1.22: nSTATUS 					(Pin 36) */ 
	{0x1, 23, PINSEL_FUNC_3 , PINSEL_PINMODE_TRISTATE},		/* P1.23: MISO0 					(Pin 37) */
	{0x1, 24, PINSEL_FUNC_3 , PINSEL_PINMODE_TRISTATE},		/* P1.24: MOSI0 					(Pin 38) */
	{0x1, 25, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.25: DATA0 					(Pin 39) */ 
	{0x1, 26, PINSEL_FUNC_2 , PINSEL_PINMODE_TRISTATE},		/* P1.26: PWM1.6 (M4)				(Pin 40) */
	{0x1, 27, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.27: HV_ON 					(Pin 43) */ 
	{0x1, 28, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.28: HV_POL 					(Pin 44) */ 
	{0x1, 29, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P1.29: HV_IMPULSE 				(Pin 45) */
	{0x1, 30, PINSEL_FUNC_2 , PINSEL_PINMODE_PULLUP},		/* P1.30: VBUS 						(Pin 21) */
	/* GPIO 2*/
#ifdef _USE_SOFT_HUB_HEATER_PWM_
	{0x2, 0, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLDOWN},		/* P2.0	: P2.0						(Pin 75) */
#else
	{0x2, 0, PINSEL_FUNC_1 , PINSEL_PINMODE_PULLDOWN},		/* P2.0	: PWM1.1 (HEATER2)			(Pin 75) */
#endif
	{0x2, 1, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.1	: DIP8 						(Pin 74) */
	{0x2, 2, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLDOWN},		/* P2.2	: HEATER1					(Pin 73) */
	{0x2, 3, PINSEL_FUNC_1 , PINSEL_PINMODE_PULLUP},		/* P2.3	: PWM1.4 (VALVE1) 			(Pin 70) */
	{0x2, 4, PINSEL_FUNC_1 , PINSEL_PINMODE_PULLUP},		/* P2.4	: PWM1.4 (BUZZER)			(Pin 69) */
	{0x2, 5, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.5	: M1 						(Pin 68) */
	{0x2, 6, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.6	: DIP6 						(Pin 67) */
	{0x2, 7, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.7	: DIP5 						(Pin 66) */
	{0x2, 8, PINSEL_FUNC_0 , PINSEL_PINMODE_TRISTATE},		/* P2.8	: BT_TX						(Pin 65) */
	//{0x2, 9, PINSEL_FUNC_2 , PINSEL_PINMODE_PULLUP},		/* P2.9 : BT_RX 					(Pin 64) */
	{0x2, 10, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.10: P2.10 					(Pin 53) */
	//{0x2, 11, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.11:  							(Pin 52) */ 
	//{0x2, 12, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.12:  							(Pin 51) */ 
	{0x2, 13, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLUP},		/* P2.13: HV_READY 					(Pin 50) */
	/* GPIO 3*/
	{0x3, 25, PINSEL_FUNC_3 , PINSEL_PINMODE_PULLUP},		/* P3.25: PWM1.2 (M3)				(Pin 27) */
	{0x3, 26, PINSEL_FUNC_3 , PINSEL_PINMODE_PULLUP},		/* P3.26: PWM1.3 (M2)				(Pin 26) */
	/* GPIO 4*/
	{0x4, 28, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLDOWN},		/* P4.28: READY						(Pin 82) */
	{0x4, 29, PINSEL_FUNC_0 , PINSEL_PINMODE_PULLDOWN},		/* P4.29: POWER_ON					(Pin 85) */

};

//----------------------------------------------------------------------------
// Pin dir config
STATIC const PinDir_t pinDirs[] = {
	// GPIO 0
	{ 0, 	0, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	1, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	2, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	3, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	4, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	5, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	6, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	7, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	8, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	9, 	PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 0, 	10, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	11, PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	15, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	16, PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	17, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	18, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	19, PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	20, PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	21, PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	22, PINDIR_INPUT, 	PINVAL_LOW },
	{ 0, 	23, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	24, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	25, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	26, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 0, 	27, PINDIR_INPUT,	PINVAL_LOW },
	{ 0, 	28, PINDIR_INPUT,	PINVAL_LOW },
	{ 0, 	29, PINDIR_INPUT,	PINVAL_LOW },
	{ 0, 	30, PINDIR_INPUT,	PINVAL_LOW },
	// GPIO 1
	{ 1, 	0, 	PINDIR_INPUT,	PINVAL_LOW },
	{ 1, 	1, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	4, 	PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 1, 	8, 	PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 1, 	9, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	10, PINDIR_INPUT,	PINVAL_LOW },
	{ 1, 	14, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	15, PINDIR_INPUT,	PINVAL_LOW },
	{ 1, 	16, PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 1, 	17, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 1, 	18, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 1, 	19, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	20, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	21, PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 1, 	22, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	23, PINDIR_INPUT,	PINVAL_LOW },
	{ 1, 	24, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 1, 	25, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 1, 	26, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 1, 	27, PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 1, 	28, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	29, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	30, PINDIR_INPUT, 	PINVAL_LOW },
	{ 1, 	31, PINDIR_INPUT, 	PINVAL_LOW },
	// GPIO 2
	{ 2, 	0, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 2, 	1, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 2, 	2, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 2, 	3, 	PINDIR_OUTPUT,	PINVAL_LOW },
	{ 2, 	4, 	PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 2, 	5, 	PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 2, 	6, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 2, 	7, 	PINDIR_INPUT,	PINVAL_LOW },
	{ 2, 	8, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 2, 	9, 	PINDIR_INPUT, 	PINVAL_LOW },
	{ 2, 	10, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 2, 	11, PINDIR_INPUT, 	PINVAL_LOW },
	{ 2, 	12, PINDIR_INPUT, 	PINVAL_LOW },
	{ 2, 	13, PINDIR_INPUT, 	PINVAL_LOW },
	// GPIO 3
	{ 3, 	25, PINDIR_OUTPUT,	PINVAL_LOW },
	{ 3, 	26, PINDIR_OUTPUT,	PINVAL_LOW },
	// GPIO 4
	{ 4, 	28, PINDIR_OUTPUT, 	PINVAL_LOW },
	{ 4, 	29, PINDIR_OUTPUT, 	PINVAL_LOW },
};

void Chip_GPIO_SetGroupPinDir(const PinDir_t* lpBuf, uint32_t length) {
	if((lpBuf == NULL) || (length == 0))
		return;
	
	for(uint32_t i = 0; i < length; i++) {
		GPIO_SetDir(lpBuf[i].port, (1 << lpBuf[i].pin), lpBuf[i].output);
//		if(lpBuf[i].output == PINDIR_INPUT)
//			continue;
//		
//		if(lpBuf[i].defaultVal == 1)
//			GPIO_SetValue(lpBuf[i].port, (1 << lpBuf[i].pin));
//		else
//			GPIO_ClearValue(lpBuf[i].port, (1 << lpBuf[i].pin));
	}
}

void Chip_GPIO_SetGroupPinMux(const PinMux_t* lpBuf, uint32_t length) {
	if((lpBuf == NULL) || (length == 0))
		return;
	
	PINSEL_CFG_Type pinCfg;
	
	for(uint32_t i = 0; i < length; i++) {
		pinCfg.Portnum = lpBuf[i].pingrp;
		pinCfg.Pinnum = lpBuf[i].pinnum;
		pinCfg.Pinmode = lpBuf[i].pinmode;
		pinCfg.Funcnum = lpBuf[i].modefunc;
		PINSEL_ConfigPin(&pinCfg);
	}
}

void Board_SysInit(void) {
	CLKPWR_ConfigPPWR(CLKPWR_PCONP_PCGPIO, ENABLE);
	
	volatile uint32_t count = sizeof(pinmuxing) / sizeof(PinMux_t);
	Chip_GPIO_SetGroupPinMux(pinmuxing, count);
	
	count = sizeof(pinDirs) / sizeof(PinDir_t);
	Chip_GPIO_SetGroupPinDir(pinDirs, count);
}
