//=============================================================================
//
//=============================================================================

#ifndef _BOARD_SYSINIT_H_
#define _BOARD_SYSINIT_H_

#include "stdint.h"
#include "stdbool.h"

#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_clkpwr.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	typedef struct {
		uint32_t pingrp			: 3;	/* Pin group */
		uint32_t pinnum			: 5;	/* Pin number */
		uint32_t modefunc		: 16;	/* Function and mode. */
		uint32_t pinmode		: 8;
	} PinMux_t;
	
	//-----------------------------------------------------------------------------
	// ��������� ��������� ����������� ������, �������� ��� �� ��� � � 
	// void Chip_IOCON_SetPinMuxing(LPC_IOCON_T *pIOCON, const PINMUX_GRP_T* pinArray, uint32_t arrayLength);
	//

	typedef struct {
		unsigned 	port 		: 3;
		unsigned 	pin 		: 5;
		unsigned	output 		: 1;
		unsigned	defaultVal 	: 1;
		unsigned 	reserved 	: 22;
	} PinDir_t;


	#define PINDIR_INPUT		0
	#define PINDIR_OUTPUT		1
	#define PINVAL_LOW			0
	#define PINVAL_HIGH			1
	
	void Board_SysInit(void);
	
	
#ifdef __cplusplus
}
#endif

#endif // _BOARD_SYSINIT_H_
