//=============================================================================
//								flow_total.h
//=============================================================================

#ifndef _FLOW_TOTAL_H_
#define _FLOW_TOTAL_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "board.h"
#include "project.h"

void flow_total_set__pid_enable(bool en);
void flow_total_pid_poll(void);
void flow_total_set_pid_factors(void);
void flow_total_update_pid_data(void);
uint16_t flow_total_get_power_value(void);

#endif // _FLOW_TOTAL_H_
