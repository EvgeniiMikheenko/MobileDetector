//=============================================================================
//
//=============================================================================

#include "fpga.h"
#include "board.h"

extern const char image[];

int FPGA_Load(void)
{
	int i = 0, j = 0;
	Board_ClrFPGA_nConfig();
	while (Board_GetFPGA_Nstatus() != 0) {
		if (i++ == 1000000)
			return 0;
	}

	Board_SetFPGA_nConfig();
	i = 0;
	while (Board_GetFPGA_Nstatus() == 0) {
		if (i++ == 1000000)
			return 0;
	}
	
	for (i = 0; i < 200000; i++) {
		for (j = 0; j < 8; j++) {
			//
			if ((image[i] >> j) & 1)
				Board_SetFPGA_Data0();
			else
				Board_ClrFPGA_Data0();
			//
			Board_SetFPGA_Dclk();
			Board_SetFPGA_Dclk();
			Board_ClrFPGA_Dclk();
			Board_ClrFPGA_Dclk();
		}
		
		if (Board_GetFPGA_ConfDone())
			return 1;
	}
	return 0;
}
