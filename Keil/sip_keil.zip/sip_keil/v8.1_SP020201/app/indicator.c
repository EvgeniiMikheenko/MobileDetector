//=============================================================================
//							indicator.c
//=============================================================================

#include "indicator.h"
#include <stdio.h>
#include "app_timers.h"

#ifdef _USE_GS2R_DEVICE_
	#include <gs2r_indicator.h>
#endif // #ifdef _USE_GS2R_DEVICE_

#ifdef _USE_SIP_SHIP_DEVICE_
	#include <sip_ship_indicator.h>
#endif // #ifdef _USE_SIP_SHIP_DEVICE_

#include "heater1.h"

#define _HUMIDITY_DANGER_ENABLE_

extern Params_Struct Params;
extern HV_Packet_Struct HV_IN_Packet;
extern HV_Packet_Struct HV_OUT_Packet;
extern unsigned char MD5digest[];
extern long long pump_time;
//extern int T_reg;
extern int	alarm_count;

void sip_update_leds(int displayMode, uint16_t devMode);
void sip_update_disp_rows_dbg(int displayMode, int *lpStatusTmp);
void sip_update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags);

#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_
extern int kostyl;
#endif

#ifdef _HUMIDITY_DANGER_ENABLE_
	extern void huminidity_danger(void);
#endif

const char recode_ind_table[] = {
	0x41, 0x80, 0x42, 0x92, 0x81, 0x45, 0x82, 0x83, 0x84, 0x85, \
	0x4B, 0x86, 0x4D, 0x48, 0x4F, 0x87, 0x50, 0x43, 0x54, 0x88, 0xD8, \
	0x58, 0x89, 0x8A, 0x8B, 0x8C, 0x62, 0x8E, 0x8D, 0x8F, 0xAC, 0xAD, \
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
	0x45, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
};

#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_

	const char strings[][RowLength] = {
		{ "   ����� �� �����    " },
		{ "   ����� ������      " },
		{ "	 ����������� �����  " },
		{ "	 ����������� ������ " },
		{ "      ���������      " },
		{ "  ���������  �����   " },
		{ "  ���������  ������  " },
		{ "  �������������      " },
		{ "     ��� %d          " },
		{ "�������� ������      " },
		{ "� ��������           " },
		{ "   ����� ���������   " }, 
		{ "      ��������       " },
		{ "      ������         " },
		{ "      ����������     " },
		{ "                     " },
		{ "   ���������� � ��   " },
		{ "      ��������       " },
	};

	enum StringIndexes {
		IndexModePrepare,
		IndexAnalize,
		IndexTestIprit,
		IndexTestLuizit,
		IndexDangers,
		IndexIpritFound,
		IndexLuizitFound,
		IndexFailure,
		IndexFailureCode,
		IndexTestButtons,
		IndexTestLights,
		IndexWorkTime,
		IndexControl,
		IndexDanger,
		IndexFail,
		IndexEmptyRow,
		IndexManualMode,
		IndexBlowDown
	};

#else 
	#ifdef _USE_DISPLAY_STRINGS_ZARIN_ZOMAN_VX_
		const char strings[][RowLength] = {
			{ "   ����� �� �����    " },
			{ "   ����� ������      " },
			{ "	 ����������� �����  " },
			{ "	 ����������� �����  " },
			{ "	 ����������� VX     " },
			{ "      ���������      " },
			{ "  ���������  �����   " },
			{ "  ���������  �����   " },
			{ "  ���������  VX      " },
			{ "  �������������      " },
			{ "     ��� 0x%04X      " },
			{ "�������� ������      " },
			{ "� ��������           " },
			{ "   ����� ���������   " }, 
			{ "      ��������       " },
			{ "      ������         " },
			{ "      ����������     " },
			{ "                     " },
			{ "   ���������� � ��   " },
			{ "      ��������       " },
		};

		enum StringIndexes {
			IndexModePrepare,
			IndexAnalize,
			IndexTestZarin,
			IndexTestZoman,
			IndexTestVX,
			IndexDangers,
			IndexZarinFound,
			IndexZomanFound,
			IndexVXFound,
			IndexFailure,
			IndexFailureCode,
			IndexTestButtons,
			IndexTestLights,
			IndexWorkTime,
			IndexControl,
			IndexDanger,
			IndexFail,
			IndexEmptyRow,
			IndexManualMode,
			IndexBlowDown
		};

	#endif

#endif


char* str  = "�����Ũ�������������";
char* str2 = "������������        ";

char str_buf1[TmpBufSize];
char str_buf2[TmpBufSize];

char* ind_str1_pointer = 0;
char* ind_str2_pointer = 0;
char* ind_str1_pointer_tmp = 0;
char* ind_str2_pointer_tmp = 0;
int ind_cur_pos = 0;

void Write_Ind(unsigned val) {
	Board_IndicatorSelect();
	LPC_SSP1->CR0 = 0xF; //16bit mode;
	LPC_SSP1->CPSR = 0x10;
	LPC_SSP1->DR = val;
	while ((LPC_SSP1->SR & 0x10))
		;
	val = LPC_SSP1->DR;
	Board_IndicatorUnSelect();
}

char Recode_Ind(char C) {
	if (C > '�' - 1)
		return recode_ind_table[C - '�'];
	else
		return C;
}

void Write_String_Ind(char * str) {
	do {
		WRITE_IND(* str);
	}
	while (* ++str != 0);
}

void update_disp_rows_dbg(int displayMode, int *lpStatusTmp) {
	#ifdef _USE_GS2R_DEVICE_
		gs2r_update_disp_rows_dbg(displayMode, lpStatusTmp);
	#else
		#ifdef _USE_SIP_SHIP_DEVICE_
			sip_ship_update_disp_rows_dbg(displayMode, lpStatusTmp);
		#else
			sip_update_disp_rows_dbg(displayMode, lpStatusTmp);
		#endif
	#endif
}

#ifndef _USE_SIP_SHIP_DEVICE_

void sip_update_disp_rows_dbg(int displayMode, int *lpStatusTmp) {
	uint32_t pmpTime;
	switch (displayMode) {
		case DEBUG_MODE1:
			sprintf(str_buf1, "T%3dC%dA%dR%d          ", 	GetTreg(),  
															Params.CPU_OUT.Temp_Case, 
															Params.CPU_OUT.Athm_Pressure, 
															Params.FPGA_IN.PeaksFoundTable[0].Time * 100 * 20 / 65536);
			ind_str1_pointer_tmp = str_buf1;
			sprintf(str_buf2, "F%d/%dV%dP%d           ",	Params.CPU_OUT.Flow_Total, 
															Params.CPU_OUT.Flow_In, 
															(Params.CPU_OUT.Valve_Level * 1000) / 65536, 
															(Params.CPU_OUT.Pump_Total_Flow * 1000) / 65536);
			ind_str2_pointer_tmp = str_buf2;
			break;
		case DEBUG_MODE2:
			pmpTime = (uint32_t)(pump_time >> 16) / 1000 / 3600;
			sprintf(str_buf1, "ID OV %d%d%ld           ", 	Params.CPU_OUT.Heater_Power, 
															HV_IN_Packet.HV_Value / 13, 
															pmpTime);
		
			sprintf(str_buf2, "VER%d.%d              ", 	FIRMWARE_VERSION >> 8,
															FIRMWARE_VERSION & 0xFF);
			ind_str1_pointer_tmp = str_buf1;
			ind_str2_pointer_tmp = str_buf2;
			break;
		case DEBUG_MODE3:
			sprintf(str_buf1, "MD5:%2X%2X%2X%2X%2X%2X%2X%2X", 	MD5digest[0]  + 0x100, 
																MD5digest[1]  + 0x100,
																MD5digest[2]  + 0x100, 
																MD5digest[3]  + 0x100, 
																MD5digest[4]  + 0x100, 
																MD5digest[5]  + 0x100, 
																MD5digest[6]  + 0x100, 
																MD5digest[7]  + 0x100);
		
			sprintf(str_buf2, "    %2X%2X%2X%2X%2X%2X%2X%2X",	MD5digest[8]  + 0x100,
																MD5digest[9]  + 0x100,
																MD5digest[10] + 0x100,
																MD5digest[11] + 0x100,
																MD5digest[12] + 0x100,
																MD5digest[13] + 0x100,
																MD5digest[14] + 0x100,
																MD5digest[15] + 0x100);
			ind_str1_pointer_tmp = str_buf1;
			ind_str2_pointer_tmp = str_buf2;
			break;
		case DEBUG_CONTROL_DANGER:
			*lpStatusTmp = MODE_ALARM;
			alarm_count = ALARM_COUNT;
			Board_ReadyLedOff();
			IND_FAILURE_OFF;
			IND_DANGER_ON;
			ind_str1_pointer_tmp = (char*)strings[IndexControl]; //"      ��������       ";
			ind_str2_pointer_tmp = (char*)strings[IndexDanger]; //"      ������         ";
			break;
		case DEBUG_CONTROL_FAILURE:
			*lpStatusTmp = MODE_FAILURE;
			Board_ReadyLedOff();
			IND_FAILURE_ON;
			IND_DANGER_OFF;
			ind_str1_pointer_tmp = (char*)strings[IndexControl]; //"      ��������       ";
			ind_str2_pointer_tmp =(char*)strings[IndexFail]; // "      ����������     ";
			break;
	}
}

#endif // #ifndef _USE_SIP_SHIP_DEVICE_

void update_display(void) {
	if (ind_cur_pos < 0x50) {
		if (ind_cur_pos > 0x13) {
			if (ind_cur_pos > 0x27) {
				WRITE_IND(ind_str2_pointer[ind_cur_pos - 0x28]);
			}
			else
				WRITE_IND('�');
		}
		else
			WRITE_IND(ind_str1_pointer[ind_cur_pos]);

		ind_cur_pos++;

	}
	else {
		ind_cur_pos = 0;
		//CLEAR_IND;
		HOME_IND;
	}
}

void disp_rows_clear(void) {
	ind_str1_pointer_tmp = "                        ";
	ind_str2_pointer_tmp = "                        ";
}

void disp_init(void) {
	ind_str1_pointer = str;
	ind_str2_pointer = str2;
}

void disp_set_rows_from_tmp(void) {
	ind_str1_pointer = ind_str1_pointer_tmp;
	ind_str2_pointer = ind_str2_pointer_tmp;
}


void disp_update_leds(int displayMode, uint16_t devMode) {
	#ifdef _USE_GS2R_DEVICE_
		gs2r_update_leds(displayMode, devMode);
	#else // _USE_GS2R_DEVICE_
		sip_update_leds(displayMode, devMode);
	#endif
}

void sip_update_leds(int displayMode, uint16_t devMode) {

	if(DIP_TEST_LED_BUT) {
		Board_ReadyLedOn();
		IND_FAILURE_ON;
		IND_DANGER_ON;
		Board_PowerLedOn();
		return;
	}
	
	if(!displayMode) {
		switch (devMode) {
			case MODE_SET_HV:
				Board_ReadyLedOff();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				break;
			case MODE_PREHEAT:
				Board_ReadyLedOff();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				VALVE2_OFF;
				break;
			case MODE_DETECT:
				Board_ReadyLedOn();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				break;
			case MODE_ALARM:
				if(!get_alarm_status())
					break;
				
				Board_ReadyLedOn();
				IND_FAILURE_OFF;
				IND_DANGER_ON;
				break;
			case MODE_SET_TOTAL_FLOW:
				Board_ReadyLedOff();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				break;
			case MODE_FAILURE:
				Board_ReadyLedOff();
				IND_FAILURE_ON;
				IND_DANGER_OFF;
				break;
		}
	}
}

void update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags) {
	#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_
		sip_update_disp_rows(displayMode, devMode, flags);
	#else
		#ifdef _USE_DISPLAY_STRINGS_ZARIN_ZOMAN_VX_
				sip_update_disp_rows(displayMode, devMode, flags);
		#else
			#ifdef _USE_SIP_SHIP_DEVICE_
				sip_ship_update_disp_rows(displayMode, devMode, flags);
			#endif
		#endif
	#endif
}
//-----------------------------------------------------------------------------
#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_

	void sip_update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags) {
		if(DIP_TEST_LED_BUT) {
			ind_str1_pointer_tmp = (char*)strings[IndexTestButtons]; //"�������� ������          ";
			ind_str2_pointer_tmp = (char*)strings[IndexTestLights]; //"� ��������               ";
		}
		else {
			
	#ifdef _HUMIDITY_DANGER_ENABLE_
			if (DIP_HUM_DANGER)
				huminidity_danger();
	#endif
			if((flags & FLAG_MANUAL_MODE) != 0) {
				ind_str1_pointer_tmp = (char*)strings[IndexManualMode];
				return;
			}
			
			if((flags & FLAG_BLOWDOWN) != 0) {
				ind_str1_pointer_tmp = (char*)strings[IndexBlowDown]; 
				return;
			}
			
			if(!displayMode) {
				switch (devMode) {
					case MODE_SET_HV:
						ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
						break;
					case MODE_PREHEAT:
						ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
						break;
					case MODE_DETECT:					
						if(kostyl == 1) {
							sprintf(str_buf2, "    %d (���.)", ((LPC_RTC->GPREG1 * 128) / 60));									
							ind_str1_pointer_tmp = (char*)strings[IndexWorkTime];
							ind_str2_pointer_tmp = str_buf2;
							break;
						}
						
						ind_str1_pointer_tmp = (char*)strings[IndexAnalize];
							
						switch(Params.CPU_OUT.Substance) {
							case 1:		
								ind_str2_pointer_tmp = (char*)strings[IndexTestIprit];
								break;
							case 2:		
								ind_str2_pointer_tmp = (char*)strings[IndexTestLuizit];
								break;
						} 
							
						break;
					case MODE_ALARM:
						ind_str1_pointer_tmp = (char*)strings[IndexDangers];
					
						switch(Params.CPU_OUT.Substance) {
							case 1:
								ind_str2_pointer_tmp = (char*)strings[IndexIpritFound];
								break;
							case 2:
								ind_str2_pointer_tmp = (char*)strings[IndexLuizitFound];
								break;
						}
							
						break;
					case MODE_SET_TOTAL_FLOW:
						ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
						break;
					case MODE_FAILURE:
						ind_str1_pointer_tmp = (char*)strings[IndexFailure];//TODO: ������� ����������� ����� �������������
						sprintf(str_buf2, (char*)strings[IndexFailureCode], Params.CPU_OUT.Flags & FAILURE_MASK);
						ind_str2_pointer_tmp = str_buf2;
						break;
				}
			}
		}
	}

#else
	#ifdef _USE_DISPLAY_STRINGS_ZARIN_ZOMAN_VX_
			// SIP LI
		void sip_update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags) {
			if(DIP_TEST_LED_BUT) {
				ind_str1_pointer_tmp = (char*)strings[IndexTestButtons];
				ind_str2_pointer_tmp = (char*)strings[IndexTestLights];
			}
			else {
				
		#ifdef _HUMIDITY_DANGER_ENABLE_
				if (DIP_HUM_DANGER)
					huminidity_danger();
		#endif
				if((flags & FLAG_MANUAL_MODE) != 0) {
					ind_str1_pointer_tmp = (char*)strings[IndexManualMode];
					return;
				}
				
				if((flags & FLAG_BLOWDOWN) != 0) {
					ind_str1_pointer_tmp = (char*)strings[IndexBlowDown]; 
					return;
				}
				
				if(!displayMode) {
					switch (devMode) {
						case MODE_SET_HV:
							ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
							break;
						case MODE_PREHEAT:
							ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
							break;
						case MODE_DETECT:					
//							if(kostyl == 1) {
//								sprintf(str_buf2, "    %d (���.)", ((LPC_RTC->GPREG1 * 128) / 60));									
//								ind_str1_pointer_tmp = (char*)strings[IndexWorkTime]; //"  ����� ���������   ";
//								ind_str2_pointer_tmp = str_buf2;
//								break;
//							}
							
							ind_str1_pointer_tmp = (char*)strings[IndexAnalize];
								
							switch(Params.CPU_OUT.Substance) {
								case 1:		
									ind_str2_pointer_tmp = (char*)strings[IndexTestZarin];
									break;
								case 2:		
									ind_str2_pointer_tmp = (char*)strings[IndexTestZoman];
									break;
								case 3:
									ind_str2_pointer_tmp = (char*)strings[IndexTestVX];
									break;
							} 
								
							break;
						case MODE_ALARM:
							ind_str1_pointer_tmp = (char*)strings[IndexDangers];
						
							switch(Params.CPU_OUT.Substance) {
								case 1:
									ind_str2_pointer_tmp = (char*)strings[IndexZarinFound];
									break;
								case 2:
									ind_str2_pointer_tmp = (char*)strings[IndexZomanFound];
									break;
								case 3:
									ind_str2_pointer_tmp = (char*)strings[IndexVXFound];
									break;
							}
								
							break;
						case MODE_SET_TOTAL_FLOW:
							ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
							break;
						case MODE_FAILURE:
							ind_str1_pointer_tmp = (char*)strings[IndexFailure]; //TODO: ������� ����������� ����� �������������
							sprintf(str_buf2, (char*)strings[IndexFailureCode] ,Params.CPU_OUT.Flags & FAILURE_MASK);
							ind_str2_pointer_tmp = str_buf2;
							break;
					}
				}
			}
		}
	#else
		#ifndef _USE_SIP_SHIP_DEVICE_
			#error "������� ����������� ����� ������� �� ���������� !!!"
		#endif
	#endif // _USE_SIP100_DEVICE_
#endif // _USE_SIP1_DEVICE_
//-----------------------------------------------------------------------------
