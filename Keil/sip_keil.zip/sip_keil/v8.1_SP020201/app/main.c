#include "main.h"

extern uint16_t but_test;

#ifdef _USE_SIP1_DEVICE_
extern SwPwmData_t m_hubPwrPwmData;
#endif // _USE_SIP1_DEVICE_

MD5_CTX MD5context;
unsigned char MD5digest[16];

volatile Flags_t m_flags;

//unsigned short pump_mode = INVERSION_PUMP_MODE;

int mb_read_flag = 0;

Peaks_Table_Struct PeaksFoundTable[MAX_PEAKS * 2];
Params_Struct Params __attribute__((at(PARAMS_RAM_ADDR)));
Params_Struct * Flash_Params = (Params_Struct *) FLASH_LOCATION;

unsigned short * FPGA_IN_BUF = (unsigned short *) & Params.FPGA_IN - 8;
unsigned short * FPGA_OUT_BUF = (unsigned short *) & Params.FPGA_OUT;
unsigned short * PARAMS_BUF = (unsigned short *) & Params;
unsigned short * FLASH_PARAMS_BUF = (unsigned short *) FLASH_LOCATION;

#define FPGA_IN_PACKET_SIZE ((sizeof(FPGA_In_Struct))/2)
#define FLASH_CONFIG_ADDR		(FLASH_PARAMS_BUF + (FLASH_SIZE / 2))

HV_Packet_Struct HV_IN_Packet, HV_OUT_Packet;
int hv_fail = 0, hv_on = 0;;
int FPGA_buf_pointer = 0;
int FPGA_buf_out_pointer = 0;
//int hv_impulse, hv_impulse_prev;

volatile bool m_isStarted = false;
OnOffFilterData_t m_hackAlarmFilterData;

//-----------------------------------------------------------------------------
// Private prototypes

bool IsManualMode(void) { return ((Params.FPGA_OUT.FPGA_Flags & FLAG_MANUAL_MODE) != 0); }

uint16_t GetBlowDownLockAlarmTimeout(void);
void update_pid_info(void);

void display_proc(void);
void read_adc(void);
//-----------------------------------------------------------------------------
#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_

#define FLOWTOTAL_FILTER_BUF_SIZE 256
uint32_t m_flowTotalBuf[FLOWTOTAL_FILTER_BUF_SIZE];

#define FLOWIN_FILTER_BUF_SIZE 128
uint32_t m_flowInBuf[FLOWIN_FILTER_BUF_SIZE];

UIntFilterData_t m_flowTotalDfData =  {
	m_flowTotalBuf, // uint32_t *lpBuf;
	FLOWTOTAL_FILTER_BUF_SIZE, //uint32_t bufSize;
	0, //uint32_t count;
	0, //uint32_t wrIndex;
	0, //uint32_t zIndex;
	
	0, //uint32_t value;
	
	false //bool isFull;
	
};

UIntFilterData_t m_flowInDfData =  {
	m_flowInBuf, // uint32_t *lpBuf;
	FLOWIN_FILTER_BUF_SIZE, //uint32_t bufSize;
	0, //uint32_t count;
	0, //uint32_t wrIndex;
	0, //uint32_t zIndex;
	
	0, //uint32_t value;
	
	false //bool isFull;
	
};

#endif // USE_AVERAGE_FILTER_FLOW_TOTAL_

//-----------------------------------------------------------------------------
//
//#define TEST_PWM

int main() {
	int i, status_tmp, debug_display = 0;
	volatile int diff1, diff2;
	volatile bool enable1, enable2;
	uint32_t dispFlags = 0;

	SystemInit();

	__disable_interrupt(); //__disable_irq();
	
	board_init();                                                               

	init_data();

	i = sizeof(FPGA_In_Struct);

	

	Board_SetRS485_TxEn(false);
	
	NVIC_SetPriority(UART1_IRQn, UART1_PRIORITY);
	NVIC_EnableIRQ(UART1_IRQn);
	
	NVIC_SetPriority(UART3_IRQn, UART3_PRIORITY);
	NVIC_EnableIRQ(UART3_IRQn);

	Board_SetFPGA_nConfig();
	Board_SetLedOk(true);

	for (i = 0; i < 1000000; i++) {
		
	}
	
	DISP_ON_IND;
	Board_PowerLedOn();
	//FAILURE_C_ON;

	FUNC_SET_IND;
	//hv_impulse = HV_IMPULSE;

	Board_ExtAdcUnSelect();
	
	disp_init();
	init_adc_data();

	MD5Init(&MD5context);
	MD5Update(&MD5context, 0, 524288);
	MD5Final((unsigned char*)MD5digest, &MD5context);
	
	/* Enable and setup SysTick Timer at a periodic rate */
	SysTick_Config(SystemCoreClock / SYSTICK_TICKRATE_HZ);
	NVIC_SetPriority (SysTick_IRQn, SYS_TICK_PRIORITY);  /* set Priority for Systick Interrupt */

#ifdef _USE_WDT_

	// Initialize WDT, IRC OSC, interrupt mode, timeout = 5000000us = 5s
	WDT_Init(WDT_CLKSRC_IRC, WDT_MODE_RESET);
	// Start watchdog with timeout given
	WDT_Start(WDT_TIMEOUT);
#else
	#warning "WDT not used !!!"
#endif
	
	__enable_interrupt();
	
	while (1)
	{
		
#ifdef TEST_PWM
		for(int iii = 1; iii <= 6; iii++ ) {
			Board_PWM_SetDutyPercentage(iii, Params.CPU_IN.Flow_In_Setpoint / 100);
		}
#endif // TEST_PWM
		
#ifdef _USE_WDT_
		WDT_Feed();
#endif
		dispFlags = 0;
		read_adc();
		disp_rows_clear();
		
		status_tmp = 0;
		
		status_tmp = detect_alarm(status_tmp);
		blowDown_proc(status_tmp > 0);
		test_alarm(status_tmp > 0);

		if (!alarm_count) {
			if (status_tmp > 0) {
				status_tmp = MODE_ALARM;
				alarm_count = ALARM_COUNT;
			}
			else {
				status_tmp = MODE_DETECT;
			}
		}
		else {
			status_tmp = MODE_ALARM;
		}

		if (Params.CPU_OUT.Device_Mode == MODE_DETECT)	{ 
			SET_HV_ON; 
			fail_counter = 0;
		}
		
		if (Params.CPU_OUT.Device_Mode == MODE_ALARM)	{ 
			fail_counter = 0;
		}
		
//		if ((!HV_READY_FLAG) && (HV_ON_FLAG))	 
//			status_tmp = MODE_SET_HV;
		
		if(run_on_off_timer(TimerIndexSetHV, (!HV_READY_FLAG) && (HV_ON_FLAG), 1000, 1000)) {
			status_tmp = MODE_SET_HV;
		}
		
		status_tmp = test_flow(status_tmp);
		status_tmp = test_temp1(status_tmp);

		update_flags();

		if ((Params.CPU_OUT.Flags & FAILURE_MASK) && (!DIP_NO_FAILURE))
			status_tmp = MODE_FAILURE;

		if(but_test > 0) {
			if(DIP_TEST_LED_BUT)
				Board_SetBuzzer(true);
			
			Board_SetLedButton(true);
			but_test--;
		}
		else {
			if(DIP_TEST_LED_BUT)
				Board_SetBuzzer(false);
			Board_SetLedButton(false);
		}
		
		if(IsManualMode()) {
			dispFlags |= FLAG_MANUAL_MODE;
		}
		
		debug_display = button_proc(debug_display);
		
		update_disp_rows(debug_display, Params.CPU_OUT.Device_Mode, dispFlags);
		disp_update_leds(debug_display, Params.CPU_OUT.Device_Mode);
		
		//prev_dev_mode = Params.CPU_OUT.Device_Mode;
		
		update_disp_rows_dbg(debug_display, &status_tmp);
		if(m_flags.IsDebugDisplayReset == 1) {
			m_flags.IsDebugDisplayReset = 0;
			m_flags.IsCurFound = 0;
			debug_display = 0;
		}
		disp_set_rows_from_tmp();
		display_proc();
		
		set_new_device_mode(status_tmp);
		
		if (hv_on) {
			HV_OUT_Packet.Flags |= 1;
			SET_HV_PIN_ON;
		}
		else {
			HV_OUT_Packet.Flags &= ~1;
			SET_HV_PIN_OFF;
		}
		
		if (DIP_FPGA_LOAD) {
			if (!Board_GetFPGA_ConfDone()) {
				EnterCritSection();
				uint16_t tmp = Params.FPGA_OUT.FPGA_Flags;
				FPGA_Load();
				Params.FPGA_OUT.FPGA_Flags = tmp;
				ExitCritSection();
			}
				
		}

#ifdef _MD5_CHECK_USE_
		check_md5();
#endif // _MD5_CHECK_USE_
		
		check_params();
		update_time();
		//T_reg = GetTreg();
		run_on_off_timer(TimerIndexAlarmEnable, alarm_count > 0, 50, 200);
		
		if(!m_isStarted) {
			if(GetSystemTime() > STARTUP_DELAY) {
				m_isStarted = true;
			}
		}
		
		Params.CPU_OUT.Heater_Power = heater1_get_power_value();
		Params.CPU_OUT.Valve_Level = flow_in_get_power_value();
		Params.CPU_OUT.Pump_Total_Flow = flow_total_get_power_value();
#ifdef _USE_ANALIZE_ALL_ZONES_
		Params.CPU_OUT.Substance = 1;
#endif // _USE_ANALIZE_ALL_ZONES_
		
		update_pid_info();
		test_mode_ok();
	}
}

//-----------------------------------------------------------------------------
//
//
int flash_restore(void) {
	int i;
	unsigned * BUF1 = (unsigned *) PARAMS_BUF;
	unsigned * BUF2 = (unsigned *) FLASH_PARAMS_BUF;
	
	//DeviceConfig_t dcfg;
//	uint16_t crc, crcInFlash;
//	int size;
//	uint8_t *ptr;
//	uint8_t *ptrDst;

	if (CalcCrc16((unsigned char *) Flash_Params, FLASH_SIZE) != Flash_Params->CRC)
	{
		for (i = 0; i < FLASH_SIZE / 4; i++)
			PARAMS_BUF[i] = 0;
		return 0;
	}
	else
	{
		for (i = 0; i < FLASH_SIZE / 4; i++)
			BUF1[i] = BUF2[i];
		return 1;
	}
	
//	size = sizeof(DeviceConfig_t);
//	crc = CalcCrc16((uint8_t*)FLASH_CONFIG_ADDR, size);
//	crcInFlash = *((uint16_t*)FLASH_CONFIG_ADDR + (size / 2));
//	ptrDst = (uint8_t*)&Params.Config;
//	ptr = (uint8_t*)FLASH_CONFIG_ADDR;
//	
//	if(crc == crcInFlash) {
//		for(i = 0; i < size; i++) {
//			*(ptrDst++) = *(ptr++);
//		}
//	}
//	else {
//		// ���������� �������� �� ���������
//		Params.Config.MbAddress = 1;
//		Params.Config.UsartBaudrate = mb_baudrate_to_reg_value(115200);
//		Params.Config.UsartStopBits = 1;
//		
//		Params.Config.WAYlimit = float_to_raw(200.0, 0, 2500);
//		Params.Config.WAYlimitInReperY = 1;
//		
//		Params.Config.WAMinDYForUp = ((uint16_t)(0.1 * 1000));
//		Params.Config.WAOnTimeForUp = 200;
//		Params.Config.WAOffTimeForUp = 500;
//		
//		Params.Config.WAMinDYForDown = ((uint16_t)(0.1 * 1000));
//		Params.Config.WAOnTimeForDown = 800;
//		Params.Config.WAOffTimeForDown = 450;
		
//		ptr = (uint8_t*)&Params.Config;
//		ptrDst = (uint8_t*)FLASH_CONFIG_ADDR;
//		Params.ConfigCRC = CalcCrc16((uint8_t*)ptr, size);
//		FlashStore(&Params);
	//}
}

void init_data		   (void) {
	
	ssp_init_data();
	
	m_flags.Value = 0;
	
	heater1_init();
	
	// Init modbus
	host_init();
	
#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
	
	uint_filter_init(&m_flowTotalDfData);
	uint_filter_init(&m_flowInDfData);
	
#endif // #ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
	
	Params.CPU_IN.Substance = 1;
	
	flash_restore();
	
	Params.CPU_OUT.Substance = Params.CPU_IN.Substance;
	Params.FPGA_OUT.hv_impulse_length = 20000;
	Params.FPGA_OUT.hv_polarity_length = 2048;

	Params.FPGA_OUT.PointsScale = 0x8;
	Params.FPGA_OUT.FPGA_Flags = 0x0000;
	Params.FPGA_OUT.FPGA_Flags |= FLAG_HUB_OFF;
	
	Params.CPU_OUT.FirmWare_Version = FIRMWARE_VERSION;
}

void update_flags	   (void) {
	//-------------------------------------------------------------------------
	// ���� ����� ������
	//  0 - ������������� ������ 1 	( b0000 0000 0000 0001 )
	//  1 - ������������� ������ 2 	( b0000 0000 0000 0010 )
	//  2 - ������ ������ 1			( b0000 0000 0000 0100 )
	//  3 - ������ ������ 2			( b0000 0000 0000 1000 )
	//  4 - ����������� �������		( b0000 0000 0001 0000 )
	//  5 - ������ FPGA				( b0000 0000 0010 0000 )
	//  6 - 						( b0000 0000 0100 0000 )
	//  7 - 						( b0000 0000 1000 0000 )
	//  8 - ���������� HV 			( b0000 0001 0000 0000 )
	//  9 - Overload HV				( b0000 0010 0000 0000 )
	//  10- HV on					( b0000 0100 0000 0000 )
	//  11- HV pol 					( b0000 1000 0000 0000 )
	//  12- HV error				( b0001 0000 0000 0000 )
	//  13- ( b0010 0000 0000 0000 )
	//  14- Hub OFF					( b0100 0000 0000 0000 )
	//  15- ( b1000 0000 0000 0000 )
	//  ����� ������ - FAILURE_MASK 0x12FF
	
	int i;
	for (i = 0; i < 8; i++) {
		if (ADC_Data[i].Fail > ADC_FAIL_COUNT - 1) {
			Params.CPU_OUT.Flags |= ADC_Data[i].Fail_Param;
		}
		else
			Params.CPU_OUT.Flags &= ~ADC_Data[i].Fail_Param;
	}
	//
	if(HV_READY_FLAG)	
		Params.CPU_OUT.Flags |= 0x100; 
	else 
		Params.CPU_OUT.Flags &= ~0x100;	   //HV_READY
	//
	if(HV_IN_Packet.Flags & 0x40)	
		Params.CPU_OUT.Flags |= 0x200; 
	else 
		Params.CPU_OUT.Flags &= ~0x200;	   //HV_OVERLOAD
	//
	if(HV_ON_FLAG)	
		Params.CPU_OUT.Flags |= 0x400; 
	else 
		Params.CPU_OUT.Flags &= ~0x400; //HV_ON
	//
	if(HV_IN_Packet.Flags & 0x2)	
		Params.CPU_OUT.Flags |= 0x800; 
	else 
		Params.CPU_OUT.Flags &= ~0x800;	 //HV_POL
	//
	if(HV_IN_Packet.Flags & 0x80)	
		Params.CPU_OUT.Flags |= FAIL_FLAG_HV_NO_VOLTAGE_DIV; 
	else 
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_HV_NO_VOLTAGE_DIV;	 //
	//
	if((hv_fail >= HV_FAIL_COUNT))	
		Params.CPU_OUT.Flags |= FAIL_FLAG_HV; 
	else 
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_HV;	 //HV Fail
	
	if(fpga_fail == FPGA_FAIL_COUNT)	
		Params.CPU_OUT.Flags |= 0x20; 
	else 
		Params.CPU_OUT.Flags &= ~0x20;	 //FPGA Fail
	
	if(!IsManualMode()) {
		if((Params.CPU_OUT.Device_Mode == 0) || (m_flags.IsModeOk == 0) || (!m_isStarted)){
			Params.FPGA_OUT.FPGA_Flags |= FLAG_HUB_OFF;
		}
		else {
			Params.FPGA_OUT.FPGA_Flags &= ~(FLAG_HUB_OFF);
		}
	}
}

void check_md5		   (void) {
	static TonTimerData_t updTmrData;
	bool en = (Params.FPGA_OUT.FPGA_Flags & SAVE_TO_FLASH_FLAG || (Flash_Params->CPU_IN.Substance != Params.CPU_OUT.Substance));
	if(!ton_timer_run(&updTmrData, 500, en)) {
		return;
	}
	
	ton_timer_reset(&updTmrData);
	
	//if (en)
	//{
#ifdef _USE_SIP1_DEVICE_
		hub_heater_off();
#endif // _USE_SIP1_DEVICE_

		Params.CPU_IN.Substance = Params.CPU_OUT.Substance;
		Params.CRC = CalcCrc16((unsigned char *) & Params, FLASH_SIZE);

		if (Params.CRC != Flash_Params->CRC) {

			EnterCritSection();
			
			FlashStore(& Params);
			MD5Init(&MD5context);
			MD5Update(&MD5context, 0, 524288);
			MD5Final((unsigned char*)MD5digest,&MD5context);
			// Reset modbus
			host_reset();
			
			ExitCritSection();
		}
		
	//}
}

void check_params	   (void) {
	
	if(m_flags.IsConfigChange == 1) {
		FlashStore(& Params);
		m_flags.IsConfigChange = 0;
	}
	
	if ((Params.FPGA_OUT.FPGA_Flags & RESTORE_FROM_FLASH_FLAG)) {
		
		EnterCritSection();
		
#ifdef _USE_SIP1_DEVICE_
		hub_heater_off();
#endif // _USE_SIP1_DEVICE_
		
		flash_restore();
		// Reset modbus
		host_reset();
		
		ExitCritSection();
	}
}

void update_time       (void) {
	if (Params.FPGA_OUT.FPGA_Flags & FLAGS_IN_SET_TIME) { 
		LPC_RTC->SEC 	= Params.CPU_IN.RTC_Sec;
		LPC_RTC->MIN 	= Params.CPU_IN.RTC_Min;
		LPC_RTC->HOUR 	= Params.CPU_IN.RTC_Hour;
		LPC_RTC->DOM 	= Params.CPU_IN.RTC_Day;
		LPC_RTC->MONTH 	= Params.CPU_IN.RTC_Month;
		LPC_RTC->YEAR 	= Params.CPU_IN.RTC_Year;
		return;
	}

	Params.CPU_IN.RTC_Sec 	= LPC_RTC->SEC;
	Params.CPU_IN.RTC_Min 	= LPC_RTC->MIN;
	Params.CPU_IN.RTC_Hour 	= LPC_RTC->HOUR;
	Params.CPU_IN.RTC_Day 	= LPC_RTC->DOM;
	Params.CPU_IN.RTC_Month = LPC_RTC->MONTH;
	Params.CPU_IN.RTC_Year 	= LPC_RTC->YEAR;
}

void pump_in_control   (void) {
//	static int counter = 0;
	
	#ifdef _USE_HACK_BUTTON_
		if(m_flags.IsBlowDown) {
			//pump_off_flag = 1;
			return;
		}
	#endif
}


int detect_alarm(int oldStatus) {
	#ifdef _USE_ANALIZE_ALL_ZONES_
		if (((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM)) && 
			(!fpga_fail) && 
			(DIP_ALARM_ONLY_HACK_BTN))  {
			
				
			for(int i = 1; i < (1 + ALL_ZONES_COUNT); i++) {
				if(Params.FPGA_IN.PeaksFoundTable[i].Time == 0)
					continue;
				
				oldStatus++;
			}
		}
	#else
		if (((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM)) && 
			(!fpga_fail) && 
			(Params.FPGA_IN.PeaksFoundTable[Params.CPU_OUT.Substance].Time) && (DIP_ALARM_ONLY_HACK_BTN)) {
				
			oldStatus++;
		}
	#endif	
		
	return oldStatus;
}

void test_alarm(bool isFound) {
	
#ifdef _USE_SIP1_DEVICE_
	static bool oldCheckEn = false;
#endif // _USE_SIP1_DEVICE_
	
//	static TonTimerData_t lockErrorTmrData;

	#ifdef _USE_HACK_BUTTON_
	static OnOffFilterData_t hackBtnFilterData;
#endif
	
#ifdef _USE_SIP100_DEVICE_
	int tstResult = 0;
#endif // #ifdef _USE_SIP100_DEVICE_
	
	m_flags.IsLockError = 0;
	
#ifdef _USE_HACK_BUTTON_
	on_off_filter_run(&hackBtnFilterData, ((GetHackBtnState()) && m_isStarted), 150, 150);
	
	if(hackBtnFilterData.outValue) {
		alarm_count = ALARM_COUNT;
		m_flags.IsHackEn = 1;
		return;
	}
	
	if(m_flags.IsHackEn) {
		m_flags.IsHackEn = 0;
		m_flags.IsCurFound = 0;
		m_flags.IsLastFound = 0;
		m_flags.IsBlowDown = 0;
		alarm_count = 0;
		m_flags.IsLockError = 1;
		m_flags.IsWaReset = 1;
	}
	
	if(!DIP_ALARM_ONLY_HACK_BTN) {
		m_flags.IsLastFound = 0;
		m_flags.IsCurFound = 0;
		m_flags.IsWaDataInvalid = 0;
		SetWAEnableValue(0);
		alarm_count = 0;
		return;
	}
#else
	
#endif
	
#ifdef _USE_SIP1_DEVICE_
	
#ifndef _TEST_MIXED_DEVICE_MODE_
	
	if(m_flags.IsCheckResultEn == 1) {
		// ��������� � ���������� T2, T3, T4, � ������� ����������� ���� � �������������,
		// ������������ �� ��� �������, � ���, � � ���� ����������� �������� ������������
		// �������.
		
		if(!oldCheckEn) {
			// ����� � ������ ���
			// ���������� ������� ���� � ����������
			m_flags.IsLastFound = m_flags.IsCurFound;
			// ���������� ������� ����
			m_flags.IsCurFound = 0;
		}
		
		oldCheckEn = true;
		
		if(m_flags.IsCurFound == 0) {
			// ������� ��� �� ����������
			if(isFound) {
				// ������� ����������, �����������
				m_flags.IsCurFound = 1;
			}
		}
	}
	else {
		// ��������� � ��������� �1, ������� � ������������
		alarm_count = 0;
		// ���������� ���� ���������� ��������
		if(oldCheckEn) {
			// ����� � ������ ���
			if((m_flags.IsLastFound == 1) && (m_flags.IsCurFound == 0)) {
				// �� ����� ��������� �������� ������� �� ����������,
				// ���������� ���� ������� ���������� ��������
				m_flags.IsLastFound = 0;
			}
		}
		oldCheckEn = false;
		
	}
	
#endif // _TEST_MIXED_DEVICE_MODE_
	
#else
	
#endif // _USE_SIP1_DEVICE_
	
	#ifdef _USE_SIP100_DEVICE_
	
		m_flags.IsCheckResultEn = 1;
		
		if((GetWaSubstance1En() && (Params.CPU_OUT.Substance == 1)) ||
		   (GetWaSubstance2En() && (Params.CPU_OUT.Substance == 2)) || 
		   (GetWaSubstance3En() && (Params.CPU_OUT.Substance == 3)))   {
		
			tstResult = test_wave();
			if(tstResult > 0) {
				// ��������� ������ �� �������
				m_flags.IsCurFound = 1;
			}
			else {
				m_flags.IsCurFound = 0;
			}
			
			SetWAEnableValue(m_flags.IsWaDataInvalid == 0);
		}
		else {
			m_flags.IsLastFound = 0;
			m_flags.IsCurFound = 0;
			m_flags.IsWaDataInvalid = 0;
			SetWAEnableValue(0);
		}
	
	#endif // _USE_SIP100_DEVICE_
		
	if(run_on_off_timer(TimerIndexLockAlarm, (m_flags.IsBlowDown == 1) && (m_isStarted), 500, GetBlowDownLockAlarmTimeout())) {
		alarm_count = ALARM_COUNT;
	}
	
	if((m_flags.IsLastFound == 1) || /* ��� ���������� �������� ���� ���������� ������� */
	   (m_flags.IsCurFound == 1) ) {  /* ���� ������� ���������� ��� ��������� �������� */
		   // �������
		   alarm_count = ALARM_COUNT;
	}
}

int test_flow(int status) {
	volatile bool enable1, enable2;
	uint32_t flowOnTime;
	
	volatile int diff1 = Params.CPU_IN.Flow_Total_Setpoint - Params.CPU_OUT.Flow_Total;
	volatile int diff2 = Params.CPU_IN.Flow_In_Setpoint - Params.CPU_OUT.Flow_In;
		
	if (Params.CPU_OUT.Device_Mode == MODE_SET_TOTAL_FLOW) {
		SET_HV_ON;
		
		enable1 = ( (diff1 > MAX_F_ERROR_DIV2) || (diff1 < -(MAX_F_ERROR_DIV2)) ); 
		enable2 = ( (diff2 > MAX_F_ERROR_DIV2) || (diff2 < -(MAX_F_ERROR_DIV2)) ); 
	}
	else {
		
		enable1 = ( (diff1 > MAX_F_ERROR) || (diff1 < -(MAX_F_ERROR)) ); 
		enable2 = ( (diff2 > MAX_F_ERROR) || (diff2 < -(MAX_F_ERROR)) ); 
	}
	
	if(Params.CPU_OUT.Device_Mode == MODE_PREHEAT) {
		reset_on_off_timer(TimerIndexFlowStable);
	}
	
	if(run_on_off_timer(TimerIndexFlowStable, (!enable1) && (!enable2), 10000, 5000)) {
		m_flags.IsFlowStable = 1;
	}
	else {
		m_flags.IsFlowStable = 0;
	}
#ifdef _USE_SIP1_DEVICE_
	flowOnTime = GetT2Time();
#else 
	flowOnTime = 3000;
#endif
	
#ifdef _USE_HACK_BUTTON_	
	if(run_on_off_timer(TimerIndexFlowOutOfRange, (enable1 || enable2) && (m_flags.IsBlowDown == 0), flowOnTime * 2, 3000)) {
		status = MODE_SET_TOTAL_FLOW;
	}
#else
	if(run_on_off_timer(TimerIndexFlowOutOfRange, (enable1 || enable2), flowOnTime * 2, 3000)) {
		status = MODE_SET_TOTAL_FLOW;
	}
#endif
	
	if((!m_isStarted) || (Params.CPU_OUT.Device_Mode == 0) || (Params.CPU_OUT.Device_Mode == MODE_PREHEAT) || 
		(m_flags.IsBlowDown == 1) || (blowing) ||
		((!CheckReperData()) && (!IsManualMode()))) 
	{
		flow_in_set_pid_enable(false);
	}
	else {
		flow_in_set_pid_enable(true);
	}
	
	flow_in_pid_poll();
	
	// Flow total PID always enable
	flow_total_set__pid_enable(true);
	flow_total_pid_poll();
	
	return status;
}

int test_temp1(int status) {
	static uint16_t oldSubstance = 0;
	bool preheatEnable = (abs(GetTemp1Pv() - GetTemp1Sp())) > 5;
	
	if(run_on_off_timer(TimerIndexTemp1Stable, !preheatEnable, 10000, 5000)) {
		m_flags.IsTemp1Stable = 1;
	}
	else {
		m_flags.IsTemp1Stable = 0;
	}
	
	if((m_flags.IsTemp1Stable == 0) && (m_isStarted)) {
		status = MODE_PREHEAT;
	
		if (Params.CPU_OUT.Device_Mode != MODE_PREHEAT) {
			SET_HV_OFF;
		}
	}
		
	if(((GetTemp1Pv() - GetTemp1Sp()) > 5) || (!m_isStarted) || (Params.CPU_OUT.Device_Mode == MODE_FAILURE) ||
		((!CheckReperData()) && (!IsManualMode()))) {
		heater1_set_enable(false);
	}
	else {
		heater1_set_enable(true);
	}
		
	heater1_pid_poll();
	
	if(oldSubstance != Params.CPU_OUT.Substance) {
		heater1_reset();
	}
	
	oldSubstance = Params.CPU_OUT.Substance;
	
	return status;
}

void test_mode_ok(void) {
	static float oldTempSp = 0;
	static uint16_t oldFlowInSp = 0;
	static uint16_t oldFlowTotalSp = 0;
	bool oldIsManualMode = false;
	float sp = GetTemp1Sp();
	
	bool forseOff = (Params.CPU_OUT.Device_Mode == 0) || (Params.CPU_OUT.Device_Mode == MODE_FAILURE);
	
	if((oldTempSp != sp) || 
	   (oldFlowInSp != Params.CPU_IN.Flow_In_Setpoint) ||
	   (oldFlowTotalSp != Params.CPU_IN.Flow_Total_Setpoint) || 
	   (oldIsManualMode != IsManualMode()) ||
	   forseOff)
	{
		m_flags.IsModeOk = 0;
	}
	
	if(m_flags.IsModeOk == 0) {
		m_flags.IsModeOk = ((m_flags.IsTemp1Stable == 1) && (m_flags.IsFlowStable == 1) && (!forseOff)) ? 1 : 0;
	}
	
	oldTempSp = sp;
	oldFlowInSp = Params.CPU_IN.Flow_In_Setpoint; 
	oldFlowTotalSp = Params.CPU_IN.Flow_Total_Setpoint;
	oldIsManualMode = IsManualMode();
}

void set_new_device_mode(int newMode) {
	
	//static TonTimerData_t tmrData;
	
	if(!m_isStarted) {
		Params.CPU_OUT.Device_Mode = 0;
		return;
	}
	
	if(!IsManualMode()) {
		
		if(!CheckReperData()) {
			Params.CPU_OUT.Device_Mode = 0;
			return;
		}
		if(run_on_off_timer(TimerIndexDeviceAlarmOff, newMode == MODE_ALARM, 5, 3000)) {
			Params.CPU_OUT.Device_Mode = MODE_ALARM;
		}
		else {
			Params.CPU_OUT.Device_Mode = newMode;
		}
		//if(ton_timer_run(&tmrData, Params.CPU_OUT.Device_Mode != newMode, 500)) {
//			if(!m_isStarted)
//				Params.CPU_OUT.Device_Mode = MODE_PREHEAT;
//			else
				//Params.CPU_OUT.Device_Mode = newMode;
		//	ton_timer_reset(&tmrData);
		//}
		return;
	}
	
	
	//MANUAL_MODE
			
	if (Params.FPGA_OUT.FPGA_Flags & (1 << 3)) 	 
		Params.CPU_OUT.Device_Mode  = MODE_DETECT;	
	else 
		Params.CPU_OUT.Device_Mode = MODE_PREHEAT;
	
	if (Params.FPGA_OUT.FPGA_Flags & 1)
		SET_HV_ON;
	else
		SET_HV_OFF;
	
	fail_counter=0;	
}

void update_pid_info(void) {
	
	static uint32_t time = 0;
	
	if((GetSystemTime() - time) < 100000)
		return;
	
	time = GetSystemTime();
	
	if(m_flags.IsPidFactorsChange == 1) {
		m_flags.IsPidFactorsChange = 0;
		heater1_set_pid_factors();
		flow_in_set_pid_factors();
		flow_total_set_pid_factors();
	}
	
	heater1_update_pid_data();
	flow_in_update_pid_data();
	flow_total_update_pid_data();
}

bool CheckReperData(void) {
	if((Params.FPGA_OUT.PeakParamTable[2] != 0))
		return true;
	
	if((Params.FPGA_OUT.PeakParamTable[1] != 0))
		return true;
	
	if((Params.FPGA_OUT.PeakParamTable[0] != 0))
		return true;
	
	return false;
}

void blowDown_proc(bool isAlarm) {
	bool en = false;
	
	#ifdef _USE_ANALIZE_ALL_ZONES_
//		if(((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM))) {
//			for(int i = 1; i < (1 + ALL_ZONES_COUNT); i++) {
//				if(Params.FPGA_IN.PeaksFoundTable[i].Time == 0)
//					continue;
//				
//				en = true;
//			}
//		}
		m_flags.IsBlowDown = 0;
	#else 
		en = (((Params.CPU_OUT.Device_Mode == MODE_DETECT) || (Params.CPU_OUT.Device_Mode == MODE_ALARM)) && 
		  /* (!fpga_fail) && */
		  (Params.FPGA_IN.PeaksFoundTable[Params.CPU_OUT.Substance].Time != 0));
	#endif // _USE_ANALIZE_ALL_ZONES_
	
	if(on_off_filter_run(&m_hackAlarmFilterData, en, 3000, 3000)) {
		m_flags.IsBlowDown = 1;
	}
	else {
		m_flags.IsBlowDown = 0;
	}
}

uint16_t GetBlowDownLockAlarmTimeout(void) {
	
	if(Params.CPU_OUT.Substance == 0)
		return 0;
	
	int index = WAVE_BLOWDOWN_LOCK_ALARM1_INDEX + (Params.CPU_OUT.Substance - 1);
	return Params.CPU_IN.Dummy[index];
}


void read_adc(void) {
	if(m_flags.IsNeedReadAdc == 0)
		return;
	//
	Read_ADC();
	Read_ADC();
	Read_ADC();
	Read_ADC();

	Read_ADC();
	Read_ADC();
	Read_ADC();
	Read_ADC();
	//
	#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
		uint_filter_put(&m_flowTotalDfData, Flow1_ADC);
		Params.CPU_OUT.Flow_Total		= ADC_Flow(uint_filter_get(&m_flowTotalDfData));
		
		uint_filter_put(&m_flowInDfData, Flow2_ADC);
		Params.CPU_OUT.Flow_In		= ADC_Flow(uint_filter_get(&m_flowInDfData));		
	#else
		Params.CPU_OUT.Flow_Total		= ADC_Flow(Flow1_ADC);
		Params.CPU_OUT.Flow_In 			= ADC_Flow(Flow2_ADC);
	#endif // USE_AVERAGE_FILTER_FLOW_TOTAL_

	//adc_temp						= ADC_Data[2].Data;
	Params.CPU_OUT.Athm_Pressure 	= ADC_Pressure(Athm_Int >> 16);
	Params.CPU_OUT.Temp1 			= ADC_Temp(Temp1_Camera_ADC);
	Params.CPU_OUT.Temp2 			= ADC_Temp(Temp2_Camera_ADC);
	Params.CPU_OUT.Temp_Case 		= ADC_Temp_Case(Temp_Case_ADC);
	//Params.CPU_OUT.Flow_In 			= ADC_Flow(Flow2_ADC);
	//Params.CPU_OUT.Flow_Total		= ADC_Flow(Flow1_ADC);
	Params.CPU_OUT.Humidity			= ADC_Humidity(Humidity_ADC);

	//T1 = (Temp1_Camera_ADC << 16) & 0xFFFFFFFF;
	//t1 = (t1 - Temp1) / 1000;
	//Temp1 += ((T1 - Temp1) >> 16);
	//Params.CPU_OUT.Temp1 = ADC_Temp(Temp1>>16);

	Athm = (AirPressure_ADC << 16) & 0xFFFFFFFF;
	Athm_Int += ((Athm - Athm_Int) >> 8);
	
//	if (((Params.CPU_OUT.Device_Mode == MODE_ALARM) || (Params.CPU_OUT.Device_Mode == MODE_DETECT)) && 
//		(!(Params.FPGA_OUT.FPGA_Flags & FLAG_MANUAL_MODE))) {
//			
//		if (blowing) {
//			Params.CPU_OUT.Valve_Level = 0;
//			Params.CPU_OUT.Pump_Total_Flow = PWM_PUMP_MAX;
//		}
//	}

//	switch (Params.CPU_OUT.Device_Mode) {
//		case MODE_PREHEAT:
//			Params.CPU_OUT.Valve_Level = 0;
//			Params.CPU_OUT.Pump_Total_Flow = PWM_PUMP_MAX;
//			break;
//		case MODE_FAILURE:
//		
//			Params.CPU_OUT.Valve_Level = 0;
//			Params.CPU_OUT.Pump_Total_Flow = 0;
//			break;
//		 
//	}

	//
	m_flags.IsNeedReadAdc = 0;
}

void display_proc(void) {
	if(m_flags.IsNeedUpdateDisplay == 0)
		return;
	//
	update_display();
	//
	m_flags.IsNeedUpdateDisplay = 0;
}
//-----------------------------------------------------------------------------
// Interrupts handlers
//
void TIMER0_IRQHandler (void) {
	/*  Clear Interrupt */
	TIM_ClearIntPending(LPC_TIM0, TIM_MR0_INT);
	/* Code...*/
	
	heater1_soft_pwm_poll();
	
#ifdef _USE_SIP1_DEVICE_

	#ifdef _USE_SOFT_HUB_HEATER_PWM_	
		SoftPwmPoll(&m_hubPwrPwmData);
	#endif // _USE_SOFT_HUB_HEATER_PWM_
	hub_poll();
	
#endif // _USE_SIP1_DEVICE_
}

void TIMER1_IRQHandler (void) {
	int Sum;

	SSP_DMA_Start_TX();

	if ((mb_read_flag == 2)) {
		SSP_DMA_Start_RX();
		mb_read_flag = 3;
	}
	else
		SSP_DMA_Start_RX();
	
	Sum = Params.FPGA_IN.PeaksFoundTable[0].Value + 
	      Params.FPGA_IN.PeaksFoundTable[1].Value + 
	      Params.FPGA_IN.PeaksFoundTable[2].Value +
	      Params.FPGA_IN.PeaksFoundTable[0].Time + 
	      Params.FPGA_IN.PeaksFoundTable[1].Time + 
	      Params.FPGA_IN.PeaksFoundTable[2].Time;
	
	if (((Params.FPGA_IN.Flags_FPGA & 0xFF00) == ((Sum & 0xFF) << 8)))
		fpga_fail = 0;

	if ((!fpga_fail) && 
		((Params.CPU_OUT.Device_Mode == MODE_ALARM) || (Params.CPU_OUT.Device_Mode == MODE_DETECT)))
	{
		if (Params.FPGA_IN.PeaksFoundTable[0].Time != 0) {
			blowing = 0;
			main_peak_count = 0;
		}
		else {
			main_peak_count++;
			if(main_peak_count > MIN_PEAK_COUNT) 
				blowing = 1;
		}
	}
//	else {
//		#warning "����� ��������� "
//		blowing = 0;
//		main_peak_count = 0;
//	}

	if (mb_read_flag == 1)
		mb_read_flag = 2;

	LPC_TIM1->IR = 0x20;

	HV_OUT_Packet.HV_Value=(Params.CPU_IN.HV_Setpoint)/10;
	HV_THR = 0xCA;
	HV_THR = HV_OUT_Packet.Flags;
	HV_THR = HV_OUT_Packet.HV_Value;
	HV_THR = (HV_OUT_Packet.HV_Value >> 8);
	return;
}

void UART3_IRQHandler  (void) {
	int stat_HV = HV_IIR & 0xF, in_byte;
	if (stat_HV == 4)
	{
		in_byte = HV_RBR;
		if (in_byte == 0xAC)
		{
			hv_fail=0;
			HV_IN_Packet.Flags = HV_RBR;
			HV_IN_Packet.HV_Value = HV_RBR;
			HV_IN_Packet.HV_Value += (HV_RBR << 8);
			Params.CPU_OUT.HV_Value = HV_IN_Packet.HV_Value;
		}
	}
	if (stat_HV == 0xC)
	{
		in_byte = HV_RBR;
	}

	stat_HV = HV_LSR & 0x20;

	return;
}

void SysTick_Handler   (void) {
	//Board_ToggleTestPin();
	//Board_SetTestPin(true);
	Board_Tick();
	//Board_SetTestPin(false);
}

void RIT_IRQHandler    (void) {
	Board_SetTestPin(true);
	
	LPC_RIT->RICTRL |= 1;

	if((m_flags.IsNeedReadAdc == 0)) {
		m_flags.IsNeedReadAdc = 1;
	}

#if 0		
//	#ifdef USE_AVERAGE_FILTER_FLOW_TOTAL_
//		uint_filter_put(&m_flowTotalDfData, Flow1_ADC);
//		Params.CPU_OUT.Flow_Total		= ADC_Flow(uint_filter_get(&m_flowTotalDfData));
//		
//		uint_filter_put(&m_flowInDfData, Flow2_ADC);
//		Params.CPU_OUT.Flow_In		= ADC_Flow(uint_filter_get(&m_flowInDfData));		
//	#else
//		Params.CPU_OUT.Flow_Total		= ADC_Flow(Flow1_ADC);
//		Params.CPU_OUT.Flow_In 			= ADC_Flow(Flow2_ADC);
//	#endif // USE_AVERAGE_FILTER_FLOW_TOTAL_

//	//adc_temp						= ADC_Data[2].Data;
//	Params.CPU_OUT.Athm_Pressure 	= ADC_Pressure(Athm_Int >> 16);
//	Params.CPU_OUT.Temp1 			= ADC_Temp(Temp1_Camera_ADC);
//	Params.CPU_OUT.Temp2 			= ADC_Temp(Temp2_Camera_ADC);
//	Params.CPU_OUT.Temp_Case 		= ADC_Temp_Case(Temp_Case_ADC);
//	//Params.CPU_OUT.Flow_In 			= ADC_Flow(Flow2_ADC);
//	//Params.CPU_OUT.Flow_Total		= ADC_Flow(Flow1_ADC);
//	Params.CPU_OUT.Humidity			= ADC_Humidity(Humidity_ADC);

//	//T1 = (Temp1_Camera_ADC << 16) & 0xFFFFFFFF;
//	//t1 = (t1 - Temp1) / 1000;
//	//Temp1 += ((T1 - Temp1) >> 16);
//	//Params.CPU_OUT.Temp1 = ADC_Temp(Temp1>>16);

//	Athm = (AirPressure_ADC << 16) & 0xFFFFFFFF;
//	Athm_Int += ((Athm - Athm_Int) >> 8);
//	
////	if (((Params.CPU_OUT.Device_Mode == MODE_ALARM) || (Params.CPU_OUT.Device_Mode == MODE_DETECT)) && 
////		(!(Params.FPGA_OUT.FPGA_Flags & FLAG_MANUAL_MODE))) {
////			
////		if (blowing) {
////			Params.CPU_OUT.Valve_Level = 0;
////			Params.CPU_OUT.Pump_Total_Flow = PWM_PUMP_MAX;
////		}
////	}

////	switch (Params.CPU_OUT.Device_Mode) {
////		case MODE_PREHEAT:
////			Params.CPU_OUT.Valve_Level = 0;
////			Params.CPU_OUT.Pump_Total_Flow = PWM_PUMP_MAX;
////			break;
////		case MODE_FAILURE:
////		
////			Params.CPU_OUT.Valve_Level = 0;
////			Params.CPU_OUT.Pump_Total_Flow = 0;
////			break;
////		 
////	}

	if (alarm_count > 0)	
		alarm_count--;

	if (fail_counter++ > FAIL_COUNT - 1) { 
		fail_counter = FAIL_COUNT; 
		Params.CPU_OUT.Flags |= FAIL_FLAG_UNABLE; 
	} // Unable to enter detect mode
	else
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_UNABLE;

	if ((Params.CPU_OUT.Valve_Level) && ((Params.CPU_OUT.Device_Mode != 0))) {
		VALVE2_ON;
	}
	else {
		VALVE2_OFF;
	}

	if (DIP_CLEAR_PUMP_TIME)
		pump_time = 0;
	else {
		pump_time = LPC_RTC->GPREG1;
		pump_time = (pump_time << 32) + LPC_RTC->GPREG0;
		pump_time += Params.CPU_OUT.Pump_Total_Flow;
	}

	LPC_RTC->GPREG0 = pump_time & 0xFFFFFFFF;
	LPC_RTC->GPREG1 = pump_time >> 32;

	Params.CPU_OUT.Pump_Time_Low = LPC_RTC->GPREG1 & 0xFFFF;
	Params.CPU_OUT.Pump_Time_High = LPC_RTC->GPREG1 >> 16;

#endif
	if (alarm_count > 0)	
		alarm_count--;

	if (fail_counter++ > FAIL_COUNT - 1) { 
		fail_counter = FAIL_COUNT; 
		Params.CPU_OUT.Flags |= FAIL_FLAG_UNABLE; 
	} // Unable to enter detect mode
	else
		Params.CPU_OUT.Flags &= ~FAIL_FLAG_UNABLE;
	
	//��������� �������� �������
	buzzer_period++;
	if (get_alarm_status() && (buzzer_period & (1 << 8)))
		Board_SetBuzzer(true);
	else
		Board_SetBuzzer(false);
	
	if((m_flags.IsNeedUpdateDisplay == 0)) {
		m_flags.IsNeedUpdateDisplay = 1;
	}

	if (hv_fail < (HV_FAIL_COUNT + 1))	
		hv_fail++;
	
	if (++fpga_fail > FPGA_FAIL_COUNT) 
		fpga_fail = FPGA_FAIL_COUNT;


	button_poll();
	
	Board_SetTestPin(false);
}
//-----------------------------------------------------------------------------
