//=============================================================================
//
//=============================================================================

#ifndef _SP020201_PINS_H_
#define _SP020201_PINS_H_

	enum GPIO0_PINS {
		HV_TX_PIN_NUM 				= 0,
		HV_RX_PIN_NUM 				= 1,
		ADC_CNV_START_PIN_NUM 		= 2,
		INDICATOR_CS_PIN_NUM 		= 3,
		DIP12_PIN_NUM 				= 4,
		DIP11_PIN_NUM 				= 5,
		DIP10_PIN_NUM 				= 6,
		SCK1_PIN_NUM 				= 7,
		MISO1_PIN_NUM 				= 8,
		MOSI1_PIN_NUM	 			= 9,
		FPGA_DCLK_PIN_NUM 			= 10,
		FPGA_CONF_DONE_PIN_NUM 		= 11,
		//GPIO0_UNDEF12_PIN_NUM 		= 12,
		//GPIO0_UNDEF13_PIN_NUM 		= 13,
		//GPIO0_UNDEF14_PIN_NUM 		= 14,
		RS485_TX_PIN_NUM 			= 15,
		RS485_RX_PIN_NUM 			= 16,
		RS485_DE_PIN_NUM 			= 17,
		RS485_RE_PIN_NUM 			= 18,
		DIP1_PIN_NUM 				= 19,
		DIP2_PIN_NUM 				= 20,
		DIP3_PIN_NUM 				= 21,
		DIP4_PIN_NUM 				= 22,
		LED2_PIN_NUM 				= 23,
		LED3_PIN_NUM 				= 24,
		LED_PG_PIN_NUM 				= 25,
		LED1_PIN_NUM 				= 26,
		//GPIO0_NC27_PIN_NUM 			= 27,
		//GPIO0_NC28_PIN_NUM 			= 28,
		USB_DP_PIN_NUM 				= 29,
		USB_DN_PIN_NUM 				= 30
	};
	
	enum GPIO1_PINS {
		DIP9_PIN_NUM 				= 0,
		DIP7_PIN_NUM 				= 1,
		DANGER_C_PIN_NUM 			= 4,
		FAILURE_C_PIN_NUM 			= 8,
		BUTTON2_PIN_NUM 			= 9,
		BUTTON1_PIN_NUM 			= 10,
		BUTTON_P_PIN_NUM 			= 14,
		BUTTON3_PIN_NUM 			= 15,
		FAILURE_X_PIN_NUM 			= 16,
		DANGER_X_PIN_NUM 			= 17,
		FPGA_nCONFIG_PIN_NUM 		= 18,
		FPGA_DR_PIN_NUM 			= 19,
		FPGA_CSK_PIN_NUM 			= 20,
		FPGA_CS_PIN_NUM 			= 21,
		FPGA_NSTATUS_PIN_NUM 		= 22,
		FPGA_MISO_PIN_NUM 			= 23,
		FPGA_MOSI_PIN_NUM 			= 24,
		FPGA_DATA0_PIN_NUM 			= 25,
		M4_PIN_NUM 					= 26,
		HV_ON_PIN_NUM 				= 27,
		HV_POL_PIN_NUM 				= 28,
		HV_IMPULSE_PIN_NUM 			= 29,
		VBUS_PIN_NUM 				= 30
	};
	
	enum GPIO2_PINS {
		HEATER2_PIN_NUM 			= 0,
		DIP8_PIN_NUM 				= 1,
		HEATER1_PIN_NUM 			= 2,
		VALVE1_PIN_NUM 				= 3,
		BUZZER_PIN_NUM 				= 4,
		M1_PIN_NUM 					= 5,
		DIP6_PIN_NUM 				= 6,
		DIP5_PIN_NUM 				= 7,
		BT_TX_PIN_NUM 				= 8,
		TEST_PIN_NUM				= 10,
		HV_READY_PIN_NUM 			= 13
	};
	
	enum GPIO3_PINS {
		M3_PIN_NUM 					= 25,
		M2_PIN_NUM 					= 26,
	};
	
	enum GPIO4_PINS {
		READY_PIN_NUM 				= 28,
		POWER_ON_PIN_NUM 			= 29,
	};

	#define FPGA_nCONFIG_PORT			1
	#define FPGA_nCONFIG_PIN			(1 << FPGA_nCONFIG_PIN_NUM)
		
	#define FPGA_NSTATUS_PORT			1
	#define FPGA_NSTATUS_PIN			(1 << FPGA_NSTATUS_PIN_NUM)
		
	#define FPGA_CONF_DONE_PORT			0
	#define FPGA_CONF_DONE_PIN			(1 << FPGA_CONF_DONE_PIN_NUM)
		
	#define FPGA_DATA0_PORT				1
	#define FPGA_DATA0_PIN				(1 << FPGA_DATA0_PIN_NUM)
		
	#define FPGA_DCLK_PORT				0
	#define FPGA_DCLK_PIN				(1 << FPGA_DCLK_PIN_NUM)

	#define FPGA_DR_PORT				1
	#define FPGA_DR_PIN					(1 << FPGA_DR_PIN_NUM)

	#define RS485_RE_PORT				0
	#define RS485_RE_PIN				(1 << RS485_RE_PIN_NUM)

	#define RS485_DE_PORT				0
	#define RS485_DE_PIN				(1 << RS485_DE_PIN_NUM)

	#define LED_RS485_PORT				0
	#define LED_RS485_PIN_NUM			LED2_PIN_NUM
	#define LED_RS485_PIN				(1 << LED_RS485_PIN_NUM)

	#define LED_HEATER_PORT				0
	#define LED_HEATER_PIN_NUM			LED3_PIN_NUM
	#define LED_HEATER_PIN				(1 << LED_HEATER_PIN_NUM)

	#define LED_BUTTON_PORT				0
	#define LED_BUTTON_PIN_NUM			LED1_PIN_NUM
	#define LED_BUTTON_PIN				(1 << LED_BUTTON_PIN_NUM)

	#define LED_OK_PORT					0
	#define LED_OK_PIN_NUM				LED_PG_PIN_NUM
	#define LED_OK_PIN					(1 << LED_OK_PIN_NUM)

	#define LED_RS485_MASK				LED_RS485_PIN
	#define LED_HEATER_MASK				LED_HEATER_PIN
	#define LED_BUTTON_MASK				LED_BUTTON_PIN
	#define LED_OK_MASK					LED_OK_PIN
	#define LED_ALL_MASK				(LED_RS485_MASK | LED_HEATER_MASK | LED_BUTTON_MASK | LED_OK_MASK)
	
	#define ADC_CS_PORT					0
	#define ADC_CS_PIN_NUM				ADC_CNV_START_PIN_NUM
	#define ADC_CS_PIN					(1 << ADC_CS_PIN_NUM)
	
	#define DIP1_PORT					0
	#define DIP1_PIN					(1 << DIP1_PIN_NUM)

	#define DIP2_PORT					0
	#define DIP2_PIN					(1 << DIP2_PIN_NUM)

	#define DIP3_PORT					0
	#define DIP3_PIN					(1 << DIP3_PIN_NUM)

	#define DIP4_PORT					0
	#define DIP4_PIN					(1 << DIP4_PIN_NUM)

	#define DIP5_PORT					2
	#define DIP5_PIN					(1 << DIP5_PIN_NUM)
	
	#define DIP6_PORT					2
	#define DIP6_PIN					(1 << DIP6_PIN_NUM)
	
	#define DIP7_PORT					1
	#define DIP7_PIN					(1 << DIP7_PIN_NUM)
	
	#define DIP8_PORT					2
	#define DIP8_PIN					(1 << DIP8_PIN_NUM)
	
	#define DIP9_PORT					1
	#define DIP9_PIN					(1 << DIP9_PIN_NUM)
	
	#define DIP10_PORT					0
	#define DIP10_PIN					(1 << DIP10_PIN_NUM)
	
	#define DIP11_PORT					0
	#define DIP11_PIN					(1 << DIP11_PIN_NUM)
	
	#define DIP12_PORT					0
	#define DIP12_PIN					(1 << DIP12_PIN_NUM)
	
	#define POWER_ON_PORT				4
	#define POWER_ON_PIN				(1 << POWER_ON_PIN_NUM)
	
	#define READY_PORT					4
	#define READY_PIN					(1 << READY_PIN_NUM)
	
	#define DANGER_X_PORT				1
	#define DANGER_X_PIN				(1 << DANGER_X_PIN_NUM)
	
	#define FAILURE_X_PORT				1
	#define FAILURE_X_PIN				(1 << FAILURE_X_PIN_NUM)
	
	#define DANGER_C_PORT				1
	#define DANGER_C_PIN				(1 << DANGER_C_PIN_NUM)
	
	#define FAILURE_C_PORT				1
	#define FAILURE_C_PIN				(1 << FAILURE_C_PIN_NUM)
	
	#define BUTTON1_PORT				1
	#define BUTTON1_PIN					(1 << BUTTON1_PIN_NUM)
	
	#define BUTTON2_PORT				1
	#define BUTTON2_PIN					(1 << BUTTON2_PIN_NUM)
	
	#define BUTTON3_PORT				1
	#define BUTTON3_PIN					(1 << BUTTON3_PIN_NUM)
	
	#define BUTTON_P_PORT				1
	#define BUTTON_P_PIN				(1 << BUTTON_P_PIN_NUM)
	
	#define INDICATOR_CS_PORT			0
	#define INDICATOR_CS_PIN			(1 << INDICATOR_CS_PIN_NUM)
	
	#define HV_ON_PORT					1
	#define HV_ON_PIN					(1 << HV_ON_PIN_NUM)
	
	#define HV_IMPULSE_PORT				1
	#define HV_IMPULSE_PIN				(1 << HV_IMPULSE_PIN_NUM)
	
	#define HV_READY_PORT				2
	#define HV_READY_PIN				(1 << HV_READY_PIN_NUM)
	
	#define HV_POL_PORT					1
	#define HV_POL_PIN					(1 << HV_POL_PIN_NUM)
	
	#define HUB_PUMP1_PORT					FAILURE_C_PORT
	#define HUB_PUMP1_PIN_NUM				FAILURE_C_PIN_NUM
	#define HUB_PUMP1_PIN					FAILURE_C_PIN

	#define HUB_PUMP2_PORT					DANGER_C_PORT
	#define HUB_PUMP2_PIN_NUM				DANGER_C_PIN_NUM
	#define HUB_PUMP2_PIN					DANGER_C_PIN

	#define M1_PORT							2
	#define M1_PIN							(1 << M1_PIN_NUM)
	
	#define M2_PORT							3
	#define M2_PIN							(1 << M2_PIN_NUM)
	
	#define M3_PORT							3
	#define M3_PIN							(1 << M3_PIN_NUM)
	
	#define M4_PORT							1
	#define M4_PIN							(1 << M4_PIN_NUM)
	
	#define HEATER1_PORT					2
	#define HEATER1_PIN						(1 << HEATER1_PIN_NUM)
	
	#define HEATER2_PORT				2
	#define HEATER2_PIN					(1 << HEATER2_PIN_NUM)
	
	#define TEST_PORT						2
	#define TEST_PIN						(1 << TEST_PIN_NUM)

#endif // _SP020201_PINS_H_
