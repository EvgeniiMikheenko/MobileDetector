//=============================================================================
//								gs2r_buttons.h
//=============================================================================

#ifndef _GS2R_BUTTONS_H_
#define _GS2R_BUTTONS_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "board.h"
#include "project.h"

int gs2r_button_proc(int display_mode);

#endif // _GS2R_BUTTONS_H_
