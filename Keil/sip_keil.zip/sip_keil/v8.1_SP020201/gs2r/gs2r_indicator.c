//=============================================================================
//								gs2r_indicator.c
//=============================================================================

#include "gs2r_indicator.h"
#include "app_timers.h"

extern Params_Struct Params;
extern Flags_t m_flags;
extern int button_pressed;

void gs2r_update_leds(int displayMode, uint16_t devMode) {

	if(DIP_TEST_LED_BUT) {
		Board_ReadyLedOn();
		IND_FAILURE_ON;
		IND_DANGER_ON;
		Board_PowerLedOn();
		return;
	}

	if(!displayMode) {
		switch (devMode) {
			case MODE_SET_HV:
				Board_ReadyLedOff();
				FAILURE_X_OFF; 
				DANGER_X_OFF; 
				FAILURE_C_OFF; 
				DANGER_C_OFF; 
				break;
			case MODE_PREHEAT:
				Board_ReadyLedOff();
				FAILURE_X_OFF; 
				DANGER_X_OFF; 
				FAILURE_C_OFF; 
				DANGER_C_OFF; 
				break;
			case MODE_DETECT:
				Board_ReadyLedOn();
				FAILURE_X_OFF; 
				DANGER_X_OFF; 
				FAILURE_C_OFF; 
				DANGER_C_OFF; 
				break;
			case MODE_ALARM:
				Board_ReadyLedOn();
				if(!get_alarm_status())
					break;
				
				if((Params.FPGA_IN.PeaksFoundTable[ZARIN_ZONE_INDEX].Time != 0) ||
				   (Params.FPGA_IN.PeaksFoundTable[ZOMAN_ZONE_INDEX].Time != 0) ||
				   (Params.FPGA_IN.PeaksFoundTable[VX_ZONE_INDEX].Time != 0)) {		
					FAILURE_X_OFF; 
					DANGER_X_ON;
				} 
				
				if(Params.FPGA_IN.PeaksFoundTable[AMMIAK_ZONE_INDEX].Time != 0) {		
					FAILURE_C_OFF; 
					DANGER_C_ON;
				}
				
				if(displayMode == DEBUG_GS2R_DANGER_X) {		
					FAILURE_X_OFF; 
					DANGER_X_ON;
				} 
				
				if(displayMode == DEBUG_GS2R_DANGER_C) {		
					FAILURE_C_OFF; 
					DANGER_C_ON;
				} 
				
				break;
			case MODE_SET_TOTAL_FLOW:
				Board_ReadyLedOff();
				FAILURE_X_OFF; 
				DANGER_X_OFF; 
				FAILURE_C_OFF; 
				DANGER_C_OFF; 
				break;
			case MODE_FAILURE:
				Board_ReadyLedOff();
				FAILURE_X_ON; 
				DANGER_X_OFF;		
				FAILURE_C_ON; 
				DANGER_C_OFF;	
				break;
		}
	}
	else {
		switch (displayMode) {
			case DEBUG_GS2R_DANGER_X:
				Board_ReadyLedOff();
				DANGER_C_OFF;
				FAILURE_C_OFF;
				FAILURE_X_OFF; 
				DANGER_X_ON;
				break;
			case DEBUG_GS2R_DANGER_C:
				Board_ReadyLedOff();
				DANGER_X_OFF;
				FAILURE_X_OFF; 
				FAILURE_C_OFF; 
				DANGER_C_ON;
				break;
			case DEBUG_GS2R_FAILURE_X:
				Board_ReadyLedOff();
				DANGER_X_OFF;
				DANGER_C_OFF;
				FAILURE_C_OFF;
				FAILURE_X_ON;
				break;
			case DEBUG_GS2R_FAILURE_C:
				Board_ReadyLedOff();
				DANGER_X_OFF;
				DANGER_C_OFF;
				FAILURE_C_ON;
				FAILURE_X_OFF;
				break;
			default:
				
				break;
		}
	}
}

void gs2r_update_disp_rows_dbg(int displayMode, int *lpStatusTmp) {
	static TonTimerData_t alarmResetTmrdata;
	bool tmrEn = false;
	
	if(lpStatusTmp == NULL)
		return;
	
	switch (displayMode) {
		case DEBUG_GS2R_DANGER_X:
			*lpStatusTmp = MODE_ALARM;
			m_flags.IsCurFound = 1;
			tmrEn = true;
			break;
		case DEBUG_GS2R_DANGER_C:
			*lpStatusTmp = MODE_ALARM;
			m_flags.IsCurFound = 1;
			tmrEn = true;
			break;
		case DEBUG_GS2R_FAILURE_X:
			//*lpStatusTmp = MODE_FAILURE;
			tmrEn = true;
			break;
		case DEBUG_GS2R_FAILURE_C:
			//*lpStatusTmp = MODE_FAILURE;
			tmrEn = true;
			break;
		default:
			
			break;
	}
	
	if(ton_timer_run(&alarmResetTmrdata, 10000, tmrEn && (button_pressed == 0))) {
		m_flags.IsDebugDisplayReset = 1;
	}
}

