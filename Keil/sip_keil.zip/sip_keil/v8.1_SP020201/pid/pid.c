//=============================================================================
//
//=============================================================================

#include "pid.h"

extern uint32_t GetSystemTime(void);

//-----------------------------------------------------------------------------
// Private
float Clamp(float value, float min, float max);
float Scale(float value, float valueMin, float valueMax, float scaleMin, float scaleMax); 
//-----------------------------------------------------------------------------

bool pid_init_data(lpPidData_t lpData) {
	if(lpData == NULL)
		return false;
	
	lpData->errSum = 0;
	lpData->lastPv = 0;
	lpData->lastTime = 0;
	lpData->isIntegralCorrectorEn = false;
	
	lpData->isStarted = false;
	lpData->enable = true;
	lpData->isInit = true;
	
	return true;
}

float pid_poll(lpPidData_t lpData) {
	float sp, pv, dT, i_tmp, out_tmp, ki_tmp, kp_tmp, err, partialSumm;
	uint32_t time;
	
	if(lpData == NULL)
		return 0.0;
	
	if(!lpData->isInit) {
		pid_init_data(lpData);
	}
	
	if(!lpData->enable) {
		pid_reset(lpData);
		if(lpData->lpSetOutput != NULL)
			(*lpData->lpSetOutput)(0.0);
		
		return 0.0;
	}
	
	pv = (lpData->lpGetPv == NULL) ? 0.0 : ((*lpData->lpGetPv)());
	sp = (lpData->lpGetSp == NULL) ? 0.0 : ((*lpData->lpGetSp)());
	
	pv = Clamp(pv, lpData->pvMin, lpData->pvMax);
	pv = Scale(pv, lpData->pvMin, lpData->pvMax, -1.0, 1.0);
	
	sp = Clamp(sp, lpData->pvMin, lpData->pvMax);
	sp = Scale(sp, lpData->pvMin, lpData->pvMax, -1.0, 1.0);
	
	err = sp - pv;
	
	lpData->pValue = err * lpData->kP;
	lpData->iValue = 0.0;
	lpData->dValue = 0.0;
	i_tmp = 0.0;
	partialSumm = 0.0;
	
	
	if(!lpData->isStarted) {
		lpData->isStarted = true;
		lpData->errSum = 0;
		lpData->lastTime = GetSystemTime();
	}
	
	time = GetSystemTime();
	
	if((lpData->pValue > -1.0) && (lpData->pValue < 1.0)) {
		
		dT = (time - lpData->lastTime ) / 1000.0;
		
		i_tmp = dT * err;
		partialSumm = lpData->errSum + i_tmp;
		lpData->iValue = lpData->kI * partialSumm;
		
		if(dT != 0)
			lpData->dValue = lpData->kD * (pv - lpData->lastPv) / dT;
	}
	
	lpData->lastTime = time;
	lpData->errSum = partialSumm;
	lpData->lastPv = pv;
	
	lpData->outValue = lpData->pValue + lpData->iValue - lpData->dValue;
	out_tmp = lpData->outValue;
	
	lpData->outValue = Clamp(lpData->outValue, -1.0, 1.0);
	lpData->outValue = Scale(lpData->outValue, -1.0, 1.0, lpData->outMin, lpData->outMax);
	
	if(lpData->outValue >= lpData->outMax) {
		lpData->errSum -= i_tmp;
	}
	else if(lpData->isIntegralCorrectorEn) {
		if(out_tmp < 0) {
			ki_tmp = ((lpData->kI == 0.0) ? 1 : lpData->kI);
			kp_tmp = ((lpData->kP == 0.0) ? 1 : lpData->kP);
			lpData->errSum += ((0.0 - out_tmp) / ki_tmp / kp_tmp);
		}
	}
	
	lpData->pValue = Clamp(lpData->pValue, -1.0, 1.0);
	lpData->pValue = Scale(lpData->pValue, -1.0, 1.0, lpData->outMin, lpData->outMax);
	
	lpData->iValue = Clamp(lpData->iValue, -1.0, 1.0);
	lpData->iValue = Scale(lpData->iValue, -1.0, 1.0, lpData->outMin, lpData->outMax);
	
	lpData->dValue = Clamp(lpData->dValue, -1.0, 1.0);
	lpData->dValue = Scale(lpData->dValue, -1.0, 1.0, lpData->outMin, lpData->outMax);
	
	if(lpData->lpSetOutput != NULL)
		(*lpData->lpSetOutput)(lpData->outValue);
	
	return lpData->outValue;
}

void pid_enable(lpPidData_t lpData) {
	if(lpData == NULL)
		return;
	
	lpData->enable = true;
}

void pid_disable(lpPidData_t lpData) {
	if(lpData == NULL)
		return;
	
	lpData->enable = false;
	lpData->isStarted = false;
}

float Clamp(float value, float min, float max) {
	if(value < min)
		return min;
	
	if(value > max)
		return max;
	
	return value;
}

float Scale(float value, float valueMin, float valueMax, float scaleMin, float scaleMax) {
	float vPerc = (value - valueMin) / (valueMax - valueMin);
	float bigSpan = vPerc * (scaleMax - scaleMin);

	float retVal = scaleMin + bigSpan;

	return retVal;
}

void pid_reset(lpPidData_t lpData) {
	if(lpData == NULL)
		return;
	
	lpData->errSum = 0;
	lpData->outValue = 0;
	lpData->lastTime = GetSystemTime();
}
