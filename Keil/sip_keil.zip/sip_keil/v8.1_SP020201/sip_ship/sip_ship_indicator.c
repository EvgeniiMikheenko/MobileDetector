//=============================================================================
//							sip_ship_indicator.c
//=============================================================================

#include "sip_ship_indicator.h"
#include <stdio.h>
#include <string.h>
#include "app_timers.h"
#include "heater1.h"
#include <utils.h>


#ifdef _USE_SIP_SHIP_DEVICE_

const char strings[][RowLength] = {
	{ "   ����� �� �����    " },
	{ "    ����� ������     " },
	{ "	  ����������� ���   " },
	{ "      ���������      " },
	{ "   ��������� �����   " },
	{ "   ��������� �����  	" },
	{ "   ��������� VX      " },
	{ "   �������������     " },
	{ "     ��� %d          " },
	{ "�������� ������      " },
	{ "� ��������           " }, 
	{ "   ����� ���������   " },
	{ "       ��������      " },
	{ "        ������       " },
	{ "      ����������     " },
	{ "                     " },
	{ "   ���������� � ��   " },
	{ "      ��������       " },
};

enum StringIndexes {
	IndexModePrepare,
	IndexAnalize,
	IndexTestFov,
	IndexDangers,
	IndexZarinFound,
	IndexZomanFound,
	IndexVXFound,
	IndexFailure,
	IndexFailureCode,
	IndexTestButtons,
	IndexTestLights,
	IndexWorkTime,
	IndexControl,
	IndexDanger,
	IndexFail,
	IndexEmptyRow,
	IndexManualMode,
	IndexBlowDown
};

char buf1[TmpBufSize];
char buf2[TmpBufSize];

extern Params_Struct Params;
extern HV_Packet_Struct HV_IN_Packet;
extern HV_Packet_Struct HV_OUT_Packet;
extern unsigned char MD5digest[];
extern long long pump_time;
//extern int T_reg;
extern int	alarm_count;
extern char* ind_str1_pointer;
extern char* ind_str2_pointer;
extern char* ind_str1_pointer_tmp;
extern char* ind_str2_pointer_tmp;
extern int ind_cur_pos;

void sip_ship_update_leds(int displayMode, uint16_t devMode) {
	if(DIP_TEST_LED_BUT) {
		Board_ReadyLedOn();
		IND_FAILURE_ON;
		IND_DANGER_ON;
		Board_PowerLedOn();
		return;
	}
	
	if(!displayMode) {
		switch (devMode) {
			case MODE_SET_HV:
				Board_ReadyLedOff();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				break;
			case MODE_PREHEAT:
				Board_ReadyLedOff();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				VALVE2_OFF;
				break;
			case MODE_DETECT:
				Board_ReadyLedOn();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				break;
			case MODE_ALARM:
				if(!get_alarm_status())
					break;
				
				Board_ReadyLedOn();
				IND_FAILURE_OFF;
				IND_DANGER_ON;
				break;
			case MODE_SET_TOTAL_FLOW:
				Board_ReadyLedOff();
				IND_FAILURE_OFF;
				IND_DANGER_OFF;
				break;
			case MODE_FAILURE:
				Board_ReadyLedOff();
				IND_FAILURE_ON;
				IND_DANGER_OFF;
				break;
		}
	}
}

void sip_ship_update_disp_rows_dbg(int displayMode, int *lpStatusTmp) {
	switch (displayMode) {
		case DEBUG_MODE1:
			sprintf(buf1, "T%3dC%dA%dR%d          ", 	GetTreg(),  
															Params.CPU_OUT.Temp_Case, 
															Params.CPU_OUT.Athm_Pressure, 
															Params.FPGA_IN.PeaksFoundTable[0].Time * 100 * 20 / 65536);
			ind_str1_pointer_tmp = buf1;
			sprintf(buf2, "F%d/%dV%dP%d           ",	Params.CPU_OUT.Flow_Total, 
															Params.CPU_OUT.Flow_In, 
															(Params.CPU_OUT.Valve_Level * 1000) / 65536, 
															(Params.CPU_OUT.Pump_Total_Flow * 1000) / 65536);
			ind_str2_pointer_tmp = buf2;
			break;
		case DEBUG_MODE2:
			sprintf(buf1, "ID OV %d%d%d            ", 	Params.CPU_OUT.Heater_Power, 
															HV_IN_Packet.HV_Value / 13, 
															(pump_time >> 16) / 1000 / 3600);
		
			sprintf(buf2, "VER%d.%d              ", 	VERSION >> 8,
															VERSION & 0xFF);
			ind_str1_pointer_tmp = buf1;
			ind_str2_pointer_tmp = buf2;
			break;
		case DEBUG_MODE3:
			sprintf(buf1, "MD5:%2X%2X%2X%2X%2X%2X%2X%2X", 	MD5digest[0]  + 0x100, 
																MD5digest[1]  + 0x100,
																MD5digest[2]  + 0x100, 
																MD5digest[3]  + 0x100, 
																MD5digest[4]  + 0x100, 
																MD5digest[5]  + 0x100, 
																MD5digest[6]  + 0x100, 
																MD5digest[7]  + 0x100);
		
			sprintf(buf2, "    %2X%2X%2X%2X%2X%2X%2X%2X",	MD5digest[8]  + 0x100,
																MD5digest[9]  + 0x100,
																MD5digest[10] + 0x100,
																MD5digest[11] + 0x100,
																MD5digest[12] + 0x100,
																MD5digest[13] + 0x100,
																MD5digest[14] + 0x100,
																MD5digest[15] + 0x100);
			ind_str1_pointer_tmp = buf1;
			ind_str2_pointer_tmp = buf2;
			break;
		case DEBUG_CONTROL_DANGER:
			*lpStatusTmp = MODE_ALARM;
			alarm_count = ALARM_COUNT;
			Board_ReadyLedOff();
			IND_FAILURE_OFF;
			IND_DANGER_ON;
			ind_str1_pointer_tmp = (char*)strings[IndexControl]; 
			ind_str2_pointer_tmp = (char*)strings[IndexDanger];
			break;
		case DEBUG_CONTROL_FAILURE:
			*lpStatusTmp = MODE_FAILURE;
			Board_ReadyLedOff();
			IND_FAILURE_ON;
			IND_DANGER_OFF;
			ind_str1_pointer_tmp = (char*)strings[IndexControl]; 
			ind_str2_pointer_tmp =(char*)strings[IndexFail];
			break;
	}
}

void sip_ship_update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags) {
	volatile int index = 0;
	volatile int len = 0;
	char *str = NULL;
	char tBuf[30];
	
	EnterCritSection();
	
	if(DIP_TEST_LED_BUT) {
		ind_str1_pointer_tmp = (char*)strings[IndexTestButtons];
		ind_str2_pointer_tmp = (char*)strings[IndexTestLights];
	}
	else {
		if((flags & FLAG_MANUAL_MODE) != 0) {
			ind_str1_pointer_tmp = (char*)strings[IndexManualMode];
			return;
		}
			
		if((flags & FLAG_BLOWDOWN) != 0) {
			ind_str1_pointer_tmp = (char*)strings[IndexBlowDown]; 
			return;
		}
				
		if(!displayMode) {
			switch (devMode) {
				case MODE_SET_HV:
					ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
					break;
				case MODE_PREHEAT:
					ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
					break;
				case MODE_DETECT:					

					ind_str1_pointer_tmp = (char*)strings[IndexAnalize];					
					ind_str2_pointer_tmp = (char*)strings[IndexTestFov];
								
					break;
				case MODE_ALARM:
//					ind_str1_pointer_tmp = (char*)strings[IndexDangers];
					memset(buf1, ' ', RowLength - 1);
					memset(buf2, ' ', RowLength - 1);
					buf1[RowLength - 1] = '\0';
					buf2[RowLength - 1] = '\0';
					index = 0;
					if(run_on_off_timer(TimerIndexZone1Found, Params.FPGA_IN.PeaksFoundTable[ZARIN_ZONE_INDEX].Time != 0, 250, 250)) {		
						str = "�����";
						len = strlen(str);
						strncpy(buf2, str, len);
						index += len;
					} 
						
					if(run_on_off_timer(TimerIndexZone2Found, Params.FPGA_IN.PeaksFoundTable[ZOMAN_ZONE_INDEX].Time != 0, 250, 250)) {		
						if(index == 0)
							str = "�����";
						else
							str = "+�����";
						
						len = strlen(str);
						strncpy(&buf2[index], str, len);
						index += len;
					} 
						
					if(run_on_off_timer(TimerIndexZone3Found, Params.FPGA_IN.PeaksFoundTable[VX_ZONE_INDEX].Time != 0, 250, 250)) {		
						if(index == 0)
							str = "VX";
						else
							str = "+VX";
						
						len = strlen(str);
						strncpy(&buf2[index], str, len);
						index += len;
					} 
				
					if(run_on_off_timer(TimerIndexZone4Found, Params.FPGA_IN.PeaksFoundTable[AMMIAK_ZONE_INDEX].Time != 0, 250, 250)) {		
						if(index == 0)
							str = "������";
						else
							str = "+������";
						
						len = strlen(str);
						if((index + len) >= RowLength) {
							len = RowLength - (index + len);
						}
						strncpy(&buf2[index], str, len);
						index += len;
					}
					
					if(index < RowLength) {
						len = (RowLength - index) / 2;
						memset(tBuf, ' ', len);
						strncpy(&tBuf[len], (const char*)buf2, index);
						memset(&tBuf[len + index], ' ', RowLength - (index + len));
						strncpy(buf2, (const char*)tBuf, RowLength - 1);
					}
					
					strncpy(buf1, "��������� ��������� ", 20);
					ind_str1_pointer_tmp = buf1;//(char*)strings[IndexDangers];
					ind_str2_pointer_tmp = buf2;
							
					break;
				case MODE_SET_TOTAL_FLOW:
					ind_str1_pointer_tmp = (char*)strings[IndexModePrepare];
					break;
				case MODE_FAILURE:
					ind_str1_pointer_tmp = (char*)strings[IndexFailure]; //TODO: ������� ����������� ����� �������������
					sprintf(buf2, (char*)strings[IndexFailureCode] ,Params.CPU_OUT.Flags & FAILURE_MASK);
					ind_str2_pointer_tmp = buf2;
					break;
			}
		}
	}
	
	ExitCritSection();
}

#endif // #ifdef _USE_SIP_SHIP_DEVICE_
