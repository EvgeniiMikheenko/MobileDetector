//=============================================================================
//								gs2r_indicator.h
//=============================================================================

#ifndef _SIP_SHIP_INDICATOR_H_
#define _SIP_SHIP_INDICATOR_H_

#include <stdlib.h>
#include <stdint.h>
#include "LPC17xx.h"

#include "board.h"
#include "project.h"

#ifdef _USE_SIP_SHIP_DEVICE_

	void sip_ship_update_leds(int displayMode, uint16_t devMode);

	void sip_ship_update_disp_rows_dbg(int displayMode, int *lpStatusTmp);
	
	void sip_ship_update_disp_rows(int displayMode, uint16_t devMode, uint32_t flags);

#endif // _USE_SIP_SHIP_DEVICE_

#endif // _SIP_SHIP_INDICATOR_H_
