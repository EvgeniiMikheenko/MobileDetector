//=============================================================================
//
//=============================================================================

#ifndef _BOARD_H_
#define _BOARD_H_

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "LPC17xx.h"
#include "lpc17xx_timer.h"
#include "lpc17xx_rit.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pwm.h"
#include "lpc17xx_rtc.h"

#include "sp020201_pins.h"

//#define FAILURE_C_PORT					1
//#define FAILURE_C_PIN_NUM				8
//#define FAILURE_C_PIN					(1 << FAILURE_C_PIN_NUM)

//#define HUB_PUMP1_PORT					FAILURE_C_PORT
//#define HUB_PUMP1_PIN_NUM				FAILURE_C_PIN_NUM
//#define HUB_PUMP1_PIN					FAILURE_C_PIN

//#define DANGER_C_PORT					1
//#define DANGER_C_PIN_NUM				4
//#define DANGER_C_PIN					(1 << DANGER_C_PIN_NUM)

//#define HUB_PUMP2_PORT					DANGER_C_PORT
//#define HUB_PUMP2_PIN_NUM				DANGER_C_PIN_NUM
//#define HUB_PUMP2_PIN					DANGER_C_PIN

//#define M1_PORT							2
//#define M1_PIN_NUM						5
//#define M1_PIN							(1 << M1_PIN_NUM)

//#define HUB_VALVE_PORT					M1_PORT
//#define HUB_VALVE_PIN_NUM				M1_PIN_NUM
//#define HUB_VALVE_PIN					M1_PIN

//#define HEATER2_PORT					1
//#define HEATER2_PIN_NUM					1
//#define HEATER2_PIN						(1 << HEATER2_PIN_NUM)

//#define FPGA_DR         				(LPC_GPIO3->FIOPIN & (1 << 19))

//#define  FPGA_NSTATUS       			(LPC_GPIO1->FIOPIN & (1 << 22))
//#define  FPGA_CONF_DONE     			(LPC_GPIO0->FIOPIN & (1 << 11))

//#define IND_CS_ON       				LPC_GPIO0->FIOCLR = (1 << 3)
//#define IND_CS_OFF      				LPC_GPIO0->FIOSET = (1 << 3)

#define DIP_REPAIR    					0 /*(!(LPC_GPIO3->FIOPIN&(1<<26))) //P3.26 */

//#define ADC_CS_ON       				LPC_GPIO0->FIOCLR = (1 << 2)
//#define ADC_CS_OFF      				LPC_GPIO0->FIOSET = (1 << 2)

#define  FAILURE_X_ON   				LPC_GPIO1->FIOSET = (1 << 16)
#define  FAILURE_X_OFF  				LPC_GPIO1->FIOCLR = (1 << 16)
#define  DANGER_X_ON    				LPC_GPIO1->FIOSET = (1 << 17)
#define  DANGER_X_OFF   				LPC_GPIO1->FIOCLR = (1 << 17)
#define  FAILURE_C_ON   				LPC_GPIO1->FIOSET = (1 << 8)
#define  FAILURE_C_OFF  				LPC_GPIO1->FIOCLR = (1 << 8)
#define  DANGER_C_ON    				LPC_GPIO1->FIOSET = (1 << 4)
#define  DANGER_C_OFF   				LPC_GPIO1->FIOCLR = (1 << 4)

//#define HEATER1_ON      				LPC_GPIO1->FIOSET = (1 << 0)
//#define HEATER1_OFF     				LPC_GPIO1->FIOCLR = (1 << 0)

//#define HEATER2_ON      				LPC_GPIO1->FIOSET = (1 << 1)
//#define HEATER2_OFF   					LPC_GPIO1->FIOCLR = (1 << 1)

//#define RE_OFF 							LPC_GPIO0->FIOSET = (1 << 18)
//#define RE_ON 							LPC_GPIO0->FIOCLR = (1 << 18)
//#define DE_ON 							LPC_GPIO0->FIOSET = (1 << 17)
//#define DE_OFF 							LPC_GPIO0->FIOCLR = (1 << 17)

//#define LED_RX485_OFF 					LPC_GPIO0->FIOCLR = (1 << 23)
//#define LED_RX485_ON 					LPC_GPIO0->FIOSET = (1 << 23)

//#define LED_HEATER_OFF 					LPC_GPIO0->FIOCLR = (1 << 24)
//#define LED_HEATER_ON 					LPC_GPIO0->FIOSET = (1 << 24)

//#define LED_BUT_PRESS_OFF 				LPC_GPIO0->FIOCLR = (1 << 26)
//#define LED_BUT_PRESS_ON 				LPC_GPIO0->FIOSET = (1 << 26)

//#define LED_OK_OFF 						LPC_GPIO0->FIOCLR = (1 << 25)
//#define LED_OK_ON 						LPC_GPIO0->FIOSET = (1 << 25)

//#define DIP1_PORT						0
//#define DIP1_PIN_NUM					19
//#define DIP1_PIN						(1 << DIP1_PIN_NUM)

//#define DIP2_PORT						0
//#define DIP2_PIN_NUM					20
//#define DIP2_PIN						(1 << DIP2_PIN_NUM)

//#define DIP3_PORT						0
//#define DIP3_PIN_NUM					21
//#define DIP3_PIN						(1 << DIP3_PIN_NUM)

//#define DIP4_PORT						0
//#define DIP4_PIN_NUM					22
//#define DIP4_PIN						(1 << DIP4_PIN_NUM)

//#define DIP5_PORT						2
//#define DIP5_PIN_NUM					7
//#define DIP5_PIN						(1 << DIP5_PIN_NUM)

//#define DIP_FPGA_LOAD         			(  LPC_GPIO0->FIOPIN & (1 << 4))  /* DIP12 P0.4 (SW1)*/
//#define DIP_CLEAR_PUMP_TIME   			(!(LPC_GPIO0->FIOPIN & (1 << 5))) /* DIP11 P0.5 (SW2) */
//#define DIP_NO_FAILURE        			(!(LPC_GPIO0->FIOPIN & (1 << 6))) /* DIP10 P0.6 (SW3)*/
//#define DIP_FIX_MAX_TEMP      			(!(LPC_GPIO2->FIOPIN & (1 << 0))) /* DIP9 P2.0  (SW4) */
//#define DIP_OLD_PUMP          			(!(LPC_GPIO2->FIOPIN & (1 << 1))) /* DIP8 P2.1  (SW5) */
//#define DIP_NOFLOWERROR       			(!(LPC_GPIO2->FIOPIN & (1 << 2))) /* DIP7 P2.2  (SW6) */
//#define DIP_TEST_LED_BUT      			(!(LPC_GPIO2->FIOPIN & (1 << 6))) /* DIP6 P2.6  (SW7) */
//#define DIP_HUM_DANGER        			0/* //(!(LPC_GPIO2->FIOPIN&(1<<1))) //(!(LPC_GPIO2->FIOPIN&(1<<7))) //DIP8 P2.1  */
//#define DIP_BIG_PUMP  					0

//#define DIP_WAVE_ANALIZE_SUBSTANCE1_EN	(LPC_GPIO0->FIOPIN & (1 << 20))    /* DIP2 P0.20 (SW11) */
//#define DIP_WAVE_ANALIZE_SUBSTANCE2_EN	(LPC_GPIO0->FIOPIN & (1 << 21))    /* DIP3 P0.21 (SW10) */
//#define DIP_WAVE_ANALIZE_SUBSTANCE3_EN	(LPC_GPIO0->FIOPIN & (1 << 22))    /* DIP4 P0.20 (SW9) */
//#define DIP_ALARM_ONLY_HACK_BTN			(LPC_GPIO2->FIOPIN & DIP5_PIN)     /* DIP5 P2.7  (SW8) */


#define  IND_DANGER_ON      			LPC_GPIO1->FIOSET = (1 << 17)
#define  IND_DANGER_OFF     			LPC_GPIO1->FIOCLR = (1 << 17)

#define  IND_FAILURE_ON     			LPC_GPIO1->FIOSET = (1 << 16)
#define  IND_FAILURE_OFF    			LPC_GPIO1->FIOCLR = (1 << 16)

#define VALVE2_ON   					if (DIP_REPAIR) LPC_GPIO2->FIOSET = (1 << 8)
#define VALVE2_OFF  					if (DIP_REPAIR) LPC_GPIO2->FIOCLR = (1 << 8)
	
#define M2_PORT							3
#define M2_PIN_NUM						26
#define M2_PIN							(1 << M2_PIN_NUM)

#define HACK_BTN_PORT					0
#define HACK_BTN_PIN_NUM				19
#define HACK_BTN_PIN					(1 << HACK_BTN_PIN_NUM)

#define RS485_THR 						LPC_UART1->THR
#define RS232_THR 						LPC_UART3->THR
#define RS485_RBR 						LPC_UART1->RBR
#define RS232_RBR 						LPC_UART3->RBR
#define RS485_LSR 						LPC_UART1->LSR
#define RS232_LSR 						LPC_UART3->LSR
#define RS485_LCR 						LPC_UART1->LCR
#define RS232_LCR 						LPC_UART3->LCR
#define RS485_DLL 						LPC_UART1->DLL
#define RS232_DLL 						LPC_UART3->DLL
#define RS485_DLM 						LPC_UART1->DLM
#define RS232_DLM 						LPC_UART3->DLM
#define RS485_IIR 						LPC_UART1->IIR
#define RS232_IIR 						LPC_UART3->IIR
#define RS485_FCR 						LPC_UART1->FCR
#define RS232_FCR 						LPC_UART3->FCR
#define RS485_IER 						LPC_UART1->IER
#define RS232_IER 						LPC_UART3->IER
#define MB_SOURCE 						1
#define MB_SOURCE_RS232 				0
#define MB_SOURCE_RS485 				1
#define MB_THR 							((MB_SOURCE) ? RS485_THR : RS232_THR)
#define MB_RBR 							((MB_SOURCE) ? RS485_RBR : RS232_RBR)
#define MB_LSR 							((MB_SOURCE) ? RS485_LSR : RS232_LSR)

#define MB_ADDR 						1

#define RS485_DE_ENABLED  				(GPIO4->FIO0PIN & (1 << 4))
#define UART_LSR  						((mb_source == MB_SOURCE_RS485) ? LPC_UART1->LSR : LPC_UART3->LSR)
#define UART_RBR  						((mb_source == MB_SOURCE_RS485) ? LPC_UART1->RBR : LPC_UART3->RBR)

#define RX_TX_LED_TIMER_VALUE 			20

#define UART_DIVISOR  					54 /* for 100MHz */

#define HV_THR 							LPC_UART3->THR
#define HV_RBR 							LPC_UART3->RBR
#define HV_LSR 							LPC_UART3->LSR
#define HV_LCR 							LPC_UART3->LCR
#define HV_DLL 							LPC_UART3->DLL
#define HV_DLM 							LPC_UART3->DLM
#define HV_IIR 							LPC_UART3->IIR
#define HV_FCR	 						LPC_UART3->FCR
#define HV_IER 							LPC_UART3->IER
//-----------------------------------------------------------------------------
	#define SW1									12	/* DIP12 */
	#define SW2									11	/* DIP11 */
	#define SW3									10	/* DIP10 */
	#define SW4									9	/* DIP9 */
	#define SW5									8	/* DIP8 */
	#define SW6									7	/* DIP7 */
	#define SW7									6	/* DIP6 */
	#define SW8									5	/* DIP5 */
	#define SW9									4	/* DIP4 */
	#define SW10								3	/* DIP3 */
	#define SW11								2	/* DIP2 */
	#define SW12								1	/* DIP1 */
//-----------------------------------------------------------------------------
	#define HEATE2_PWM_CH						1
	#define M3_PWM_CH							2
	#define M2_PWM_CH							3
	#define VALVE1_PWM_CH						4
	#define BUZZER_PWM_CH						5
	#define M4_PWM_CH							6
//-----------------------------------------------------------------------------
#ifdef __cplusplus
	extern "C" {
#endif

	extern 			uint32_t 	GetSystemTime(void);
			
					void 		Board_Tick(void);

					void 		board_init(void);
			
	static inline 	void 		SetPinValue(uint8_t port, uint32_t pin, bool value) {
		if(value)
				GPIO_SetValue(port, pin); 
			else
				GPIO_ClearValue(port, pin);
	}
	
	static inline 	void 		TogglePinValue(uint8_t port, uint32_t pin) {
		if((GPIO_ReadValue(port) & pin) == 0)
				GPIO_SetValue(port, pin); 
			else
				GPIO_ClearValue(port, pin);
	}
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
					void 		Board_PWM1_Init(uint8_t resolution);
	static inline 	void 		Chip_PWM_EnableChannel(uint8_t num) { LPC_PWM1->PCR |= PWM_PCR_PWMENAn(num); LPC_PWM1->LER = 0xFF; }

	static inline 	void 		Board_SetPWM1_Ch1Duty(uint32_t duty) { LPC_PWM1->MR1 = (duty > LPC_PWM1->MR0) ? LPC_PWM1->MR0 : duty; LPC_PWM1->LER = 0xFF; }
	static inline 	void 		Board_SetPWM1_Ch2Duty(uint32_t duty) { LPC_PWM1->MR2 = (duty > LPC_PWM1->MR0) ? LPC_PWM1->MR0 : duty; LPC_PWM1->LER = 0xFF; }
	static inline 	void 		Board_SetPWM1_Ch3Duty(uint32_t duty) { LPC_PWM1->MR3 = (duty > LPC_PWM1->MR0) ? LPC_PWM1->MR0 : duty; LPC_PWM1->LER = 0xFF; }
	static inline 	void	 	Board_SetPWM1_Ch4Duty(uint32_t duty) { LPC_PWM1->MR4 = (duty > LPC_PWM1->MR0) ? LPC_PWM1->MR0 : duty; LPC_PWM1->LER = 0xFF; }
	static inline 	void 		Board_SetPWM1_Ch5Duty(uint32_t duty) { LPC_PWM1->MR5 = (duty > LPC_PWM1->MR0) ? LPC_PWM1->MR0 : duty; LPC_PWM1->LER = 0xFF; }
	static inline 	void 		Board_SetPWM1_Ch6Duty(uint32_t duty) { LPC_PWM1->MR6 = (duty > LPC_PWM1->MR0) ? LPC_PWM1->MR0 : duty; LPC_PWM1->LER = 0xFF; }

					void 		Board_PWM1_SetDuty(uint8_t ch, uint32_t duty);
					void 		Board_PWM_SetDutyPercentage(uint8_t ch, uint8_t duty);
	
					void		Board_SetHeater2(bool value);
	
	static inline	void		Board_SetHeater1(bool value) { SetPinValue(HEATER1_PORT, HEATER1_PIN, value); }
	static inline	void		Board_SetBuzzer(bool value) { Board_PWM_SetDutyPercentage(BUZZER_PWM_CH, (value) ? 100 : 0); }
	
	static inline	uint32_t	Board_PWM1_GetMaxDuty() { return LPC_PWM1->MR0; } 
//-----------------------------------------------------------------------------
					void 		Board_SetHubPump1(bool value);

					void 		Board_SetHubPump2(bool value);
	
	static inline	void 		Board_SetHubValve(bool value) 	{ SetPinValue(M1_PORT, M1_PIN, value); }	
//-----------------------------------------------------------------------------
	static inline 	bool		Board_GetDip1() { return ((GPIO_ReadValue(DIP1_PORT) & DIP1_PIN) != 0); }
	static inline 	bool		Board_GetDip2() { return ((GPIO_ReadValue(DIP2_PORT) & DIP2_PIN) != 0); }
	static inline 	bool		Board_GetDip3() { return ((GPIO_ReadValue(DIP3_PORT) & DIP3_PIN) != 0); }
	static inline 	bool		Board_GetDip4() { return ((GPIO_ReadValue(DIP4_PORT) & DIP4_PIN) != 0); }
	static inline 	bool		Board_GetDip5() { return ((GPIO_ReadValue(DIP5_PORT) & DIP5_PIN) != 0); }
	static inline 	bool		Board_GetDip6() { return ((GPIO_ReadValue(DIP6_PORT) & DIP6_PIN) != 0); }
	static inline 	bool		Board_GetDip7() { return ((GPIO_ReadValue(DIP7_PORT) & DIP7_PIN) != 0); }
	static inline 	bool		Board_GetDip8() { return ((GPIO_ReadValue(DIP8_PORT) & DIP8_PIN) != 0); }
	static inline 	bool		Board_GetDip9() { return ((GPIO_ReadValue(DIP9_PORT) & DIP9_PIN) != 0); }
	static inline 	bool		Board_GetDip10() { return ((GPIO_ReadValue(DIP10_PORT) & DIP10_PIN) != 0); }
	static inline 	bool		Board_GetDip11() { return ((GPIO_ReadValue(DIP11_PORT) & DIP11_PIN) != 0); }
	static inline 	bool		Board_GetDip12() { return ((GPIO_ReadValue(DIP12_PORT) & DIP12_PIN) != 0); }

					bool		Board_GetDipState(uint8_t num);
//-----------------------------------------------------------------------------
	static inline 	void 		Board_SetTestPin(bool value) { SetPinValue(TEST_PORT, TEST_PIN, value); }
	static inline 	void 		Board_ToggleTestPin() { TogglePinValue(TEST_PORT, TEST_PIN); }
	
//-----------------------------------------------------------------------------
	#define DIP_FPGA_LOAD         			(  Board_GetDipState(SW1) )  			/* DIP12 P0.4 (SW1)  */
	#define DIP_CLEAR_PUMP_TIME   			(!(Board_GetDipState(SW2))) 			/* DIP11 P0.5 (SW2)  */
	#define DIP_NO_FAILURE        			(!(Board_GetDipState(SW3))) 			/* DIP10 P0.6 (SW3)  */
	// #define DIP_FIX_MAX_TEMP      			(!(Board_GetDipState(SW4))) 			/* DIP9 P2.0  (SW4)  */
	#define GetDipDisableFlowInOnHubStT1()	(!(Board_GetDipState(SW4))) 			/* DIP9 P2.0  (SW4)  */
	//#define DIP_OLD_PUMP          			(!(Board_GetDipState(SW5))) 			/* DIP8 P2.1  (SW5)  */
	#define GetDipDisableBlowdown()			(!(Board_GetDipState(SW5))) 			/* DIP8 P2.1  (SW5) */
	#define DIP_NOFLOWERROR       			(!(Board_GetDipState(SW6))) 			/* DIP7 P2.2  (SW6)  */
	#define DIP_TEST_LED_BUT      			(!(Board_GetDipState(SW7))) 			/* DIP6 P2.6  (SW7)  */
	#define DIP_HUM_DANGER        			0/* //(!(LPC_GPIO2->FIOPIN&(1<<1))) //(!(LPC_GPIO2->FIOPIN&(1<<7))) //DIP8 P2.1  */
	#define DIP_BIG_PUMP  					0

	#define DIP_ALARM_ONLY_HACK_BTN			( Board_GetDipState(SW8))     					/* DIP5 P2.7  (SW8)  */
	static inline 	bool 		GetWaSubstance3En()	{ return Board_GetDipState(SW9); }    	/* DIP4 P0.20 (SW9)  */
	static inline 	bool 		GetWaSubstance2En()	{ return Board_GetDipState(SW10); }    	/* DIP3 P0.21 (SW10) */
	static inline 	bool 		GetWaSubstance1En()	{ return Board_GetDipState(SW11); }    	/* DIP2 P0.20 (SW11) */
	
	static bool GetHackBtnState()			{ return Board_GetDipState(SW12); }
//-----------------------------------------------------------------------------
	static inline 	void 		Board_SetFPGA_nConfig() { SetPinValue(FPGA_nCONFIG_PORT, FPGA_nCONFIG_PIN, true); }
	static inline 	void 		Board_ClrFPGA_nConfig() { SetPinValue(FPGA_nCONFIG_PORT, FPGA_nCONFIG_PIN, false); }

	static inline 	bool 		Board_GetFPGA_Nstatus() { return ((GPIO_ReadValue(FPGA_NSTATUS_PORT) & FPGA_NSTATUS_PIN) != 0); }
	static inline 	bool 		Board_GetFPGA_ConfDone() { return ((GPIO_ReadValue(FPGA_CONF_DONE_PORT) & FPGA_CONF_DONE_PIN) != 0); }
	static inline 	bool 		Board_GetFPGA_DR() { return ((GPIO_ReadValue(FPGA_DR_PORT) & FPGA_DR_PIN) != 0); }

	static inline 	void 		Board_SetFPGA_Data0() { SetPinValue(FPGA_DATA0_PORT, FPGA_DATA0_PIN, true); }
	static inline 	void 		Board_ClrFPGA_Data0() { SetPinValue(FPGA_DATA0_PORT, FPGA_DATA0_PIN, false); }

	static inline 	void 		Board_SetFPGA_Dclk() { SetPinValue(FPGA_DCLK_PORT, FPGA_DCLK_PIN, true); }
	static inline 	void 		Board_ClrFPGA_Dclk() { SetPinValue(FPGA_DCLK_PORT, FPGA_DCLK_PIN, false); }
//-----------------------------------------------------------------------------
					void 		Board_SetRS485_TxEn(bool value);
	static inline 	void 		Board_SetLedRS485(bool value) 	{ SetPinValue(LED_RS485_PORT, LED_RS485_PIN, value); }
	static inline 	void 		Board_SetLedHeater(bool value) 	{ SetPinValue(LED_HEATER_PORT, LED_HEATER_PIN, value); }
	static inline 	void 		Board_SetLedButton(bool value) 	{ SetPinValue(LED_BUTTON_PORT, LED_BUTTON_PIN, value); }
	static inline 	void 		Board_SetLedOk(bool value) 		{ SetPinValue(LED_OK_PORT, LED_OK_PIN, value); }
//-----------------------------------------------------------------------------
	static inline 	void 		Board_ExtAdcSelect() 		{ SetPinValue(ADC_CS_PORT, ADC_CS_PIN, false); }
	static inline 	void 		Board_ExtAdcUnSelect() 		{ SetPinValue(ADC_CS_PORT, ADC_CS_PIN, true); }
	static inline 	void 		Board_IndicatorSelect() 	{ SetPinValue(INDICATOR_CS_PORT, INDICATOR_CS_PIN, false); }
	static inline 	void 		Board_IndicatorUnSelect() 	{ SetPinValue(INDICATOR_CS_PORT, INDICATOR_CS_PIN, true); }
//-----------------------------------------------------------------------------
	
//-----------------------------------------------------------------------------


//static inline void Board_SetPumpInDuty(uint32_t duty) 			{ LPC_PWM1->MR3 = duty; }
//static inline void Board_SetPumpTotalDuty(uint32_t duty) 		{ LPC_PWM1->MR4 = duty; }

static inline void Board_SelectFpga() 							{ LPC_GPIO1->FIOCLR = (1 << 21); }
static inline void Board_UnSelectFpga() 						{ LPC_GPIO1->FIOSET = (1 << 21); }

static inline void Board_PowerLedOn() { LPC_GPIO4->FIOSET = (1 << 29); }
static inline void Board_PowerLedOff() { LPC_GPIO4->FIOCLR = (1 << 29); }
static inline void Board_ReadyLedOn() { LPC_GPIO4->FIOSET = (1 << 28); }
static inline void Board_ReadyLedOff() { LPC_GPIO4->FIOCLR = (1 << 28); }

#ifdef __cplusplus
	}
#endif

#endif // _BOARD_H_
