//=============================================================================
//									buttons.c
//=============================================================================

#include "buttons.h"

#ifdef _USE_GS2R_DEVICE_
	#include <gs2r_buttons.h>
#endif // #ifdef _USE_GS2R_DEVICE_

#ifdef _USE_SIP_SHIP_DEVICE_
	#include <sip_ship_buttons.h>
#endif // #ifdef _USE_SIP_SHIP_DEVICE_

extern Params_Struct Params;

int buttons 				= 0;
int buttons_prev 			= 0;
int buttons_time 			= 0;
int button_pressed 			= 0;
uint16_t but_test 			= 0;

#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_
int kostyl 					= 0;
#endif

int sip_button_proc(int display_mode);

int button_proc(int display_mode) {
	#ifdef _USE_GS2R_DEVICE_
		return gs2r_button_proc(display_mode);
	#else // _USE_GS2R_DEVICE_
		#ifdef _USE_SIP_SHIP_DEVICE_
			return sip_ship_button_proc(display_mode);
		#else
			return sip_button_proc(display_mode);
		#endif
	#endif
}

void button_poll(void) {
	buttons_prev = buttons;
	buttons = LPC_GPIO1->FIOPIN & (BUTTON1_MASK + BUTTON2_MASK + BUTTON3_MASK + BUTTONP_MASK);

	if ((buttons == buttons_prev) && (buttons != 0x0)) {
		
		if(buttons_time < BUTTONS_COUNTER_MAX)
			buttons_time++;
		
		if (buttons_time >= BUTTONS_PRESS_TIME) {
			button_pressed = 1;
		}
	}
	else {
		buttons_time = 0;
		button_pressed = 0;
	}
}

int sip_button_proc(int display_mode) {
	
	if (!button_pressed) {
		Board_SetLedButton(false);
		if(DIP_TEST_LED_BUT) {
			//BUZZER_OFF;
		}
		return display_mode;
	}
	
	button_pressed = 0;
	buttons_time = 0;
	but_test = 1500;
	
	switch(buttons) {
		case BUTTON1_MASK:
			
			if (display_mode)
				display_mode = DEBUG_MODE1;
			else
				Params.CPU_OUT.Substance = 1;
			
			break;
		case BUTTON2_MASK:
			if (display_mode)
				display_mode = DEBUG_MODE2;
			else
				Params.CPU_OUT.Substance = 2;
			
			break;
		case BUTTON3_MASK:
			if (display_mode)
				display_mode = DEBUG_MODE3;
			else {
#ifdef _USE_DISPLAY_STRINGS_IPRIT_LUIZIT_
				if(kostyl == 1)
					kostyl = 0;
				else
					kostyl = 1;
#else
				Params.CPU_OUT.Substance = 3;
#endif
			}
			
			break;
		case BUTTON1_MASK + BUTTON2_MASK:
			display_mode = DEBUG_CONTROL_DANGER;
		
			break;
		case BUTTON2_MASK + BUTTON3_MASK:
			display_mode = DEBUG_CONTROL_FAILURE;
		
			break;
		case BUTTON1_MASK + BUTTON2_MASK + BUTTON3_MASK:
			
			if(display_mode) 
				display_mode = 0; 
			else 
				display_mode  =DEBUG_MODE1;
			
			break;
		case BUTTONP_MASK:
			display_mode = 0;
		
			break;
	}
	
	return display_mode;
}
