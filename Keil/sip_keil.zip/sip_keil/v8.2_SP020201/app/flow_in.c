//=============================================================================
//									flow_in.c
//=============================================================================

#include "flow_in.h"
#include <pid.h>
#include <ton_timer.h>

extern Params_Struct Params;

static float GetFlowInSp(void) { return (float)Params.CPU_IN.Flow_In_Setpoint / 10.0; }
static float GetFlowInPv(void) { return (float)Params.CPU_OUT.Flow_In / 10.0; }
static void SetFlowInPwm(float value) {
	if(value < 0)
		value = 0;
	
	//uint32_t percentage = (uint32_t)(value / 10);

#if (PUMP_MODE == INVERSION_PUMP_MODE)	 
	
	//if(PUMP_MODE == INVERSION_PUMP_MODE) {
		//Board_SetPumpInDuty((uint32_t)PWM1_CYCLES_COUNT - value);
		//Board_PWM1_SetDuty(M2_PWM_CH, Board_PWM1_GetMaxDuty() - percentage);
		Board_PWM1_SetDuty(M2_PWM_CH, Board_PWM1_GetMaxDuty() - (uint32_t)value);
	//	return;
	//}
#else
	//Board_SetPumpInDuty((uint32_t)value);
	//Board_PWM1_SetDuty(M2_PWM_CH, percentage);
	Board_PWM1_SetDuty(M2_PWM_CH, (uint32_t)value);
#endif
}

PidData_t m_flowInPidData =  {		
	0.5,//1.5, //float kP;
	0.35,//0.1,//0.025, //float kI;
	0.01,//0.001, //float kD;
	
	1000, //float pvMax;
	-1000, //float pvMin;
	
	PWM1_CYCLES_COUNT, // float outMax;
	-PWM1_CYCLES_COUNT, //float outMin;
	
	false, //float outValue;
	
	0, //uint32_t lastTime;
	0.0, //float lastPv;
	0.0, //float errSum;
	
	false, //bool enable;
	false, //bool isInit;
	false, //bool isStarted;
	false, //bool isIntegralCorrectorEn;
	
	0.0, //float pValue;
	0.0, //float iValue;
	0.0, //float dValue;
	
	GetFlowInPv, //GetFloat lpGetPv;
	GetFlowInSp, //GetFloat lpGetSp;
	
	SetFlowInPwm //SetFloat lpSetOutput;
};

void flow_in_set_pid_enable(bool en) {
	if(en) {
		pid_enable(&m_flowInPidData);
		return;
	}
	
	pid_disable(&m_flowInPidData);
}

void flow_in_pid_poll(void) {
	static TonTimerData_t flowInTimerData;
	
	if(!ton_timer_run(&flowInTimerData, 10, true))
		return;
	
	ton_timer_reset(&flowInTimerData);
	pid_poll(&m_flowInPidData);
}

void flow_in_set_pid_factors(void) {
	m_flowInPidData.kP = Params.Config.FlowInPidFactors.kP.value;
	m_flowInPidData.kI = Params.Config.FlowInPidFactors.kI.value;
	m_flowInPidData.kD = Params.Config.FlowInPidFactors.kD.value;
}

void flow_in_update_pid_data(void) {
	Params.FlowInPidData.pValue.value = m_flowInPidData.pValue;
	Params.FlowInPidData.iValue.value = m_flowInPidData.iValue;
	Params.FlowInPidData.dValue.value = m_flowInPidData.dValue;
	Params.FlowInPidData.errSumm.value = m_flowInPidData.errSum;
	Params.FlowInPidData.outValue.value = m_flowInPidData.outValue;
}

uint16_t flow_in_get_power_value(void) {
	return (uint16_t)m_flowInPidData.outValue;
}
