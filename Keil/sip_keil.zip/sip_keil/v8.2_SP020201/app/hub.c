//=============================================================================
//
//=============================================================================

#include "hub.h"
#include <soft_pwm.h>
#include <ton_timer.h>

#ifdef _USE_SIP1_DEVICE_

//  |            Period  			  |
//  |------------------|----|----|----|
//           T1          T2   T3   T4
// � ������� ������� T1, ������� ����� PUMP1.
// 
uint32_t m_hubPeriod 				= 0; // Period
uint32_t m_hubCounter 				= 0; // �������, �� �������� �������������� �������� �������
uint32_t m_localCounter 			= 0; // ��������� �������, ��� ������� ��������� ����������� ������� �1, �2, �3, �4
uint32_t m_localCounterStartTime 	= 0;
uint32_t m_hubCounterStartTime		= 0;

extern Flags_t m_flags;

HubSTate_t m_hubState = StOff;

#ifdef _USE_SOFT_HUB_HEATER_PWM_
SwPwmData_t m_hubPwrPwmData = {
	100,
	0,
	0,
	0,
	0,
	false,
	hub_set_pwm_value
};
#endif // _USE_SOFT_HUB_HEATER_PWM_

OnOffFilterData_t m_hubFilterData;

//-----------------------------------------------------------------------------
// Private
static inline uint32_t GetHubPeriod() { return GetT1Time() + GetT2Time() + GetT3Time() + GetT4Time(); }

static inline uint8_t GetPwr1()    { return (uint8_t)Params.CPU_IN.Dummy[HUB_PWR1_PARAM_INDEX]; }
static inline uint8_t GetPwr2()    { return (uint8_t)Params.CPU_IN.Dummy[HUB_PWR2_PARAM_INDEX]; }
//static inline uint8_t GetPwr3()    { return (uint8_t)Params.CPU_IN.HubPwr3; }

#ifdef _USE_SOFT_HUB_HEATER_PWM_
	static inline void SetPwrDuty(uint8_t value) { m_hubPwrPwmData.DutyNew = (value <= HUB_PWR_MAX) ? value : HUB_PWR_MAX; }
#else
	static inline void SetPwrDuty(uint8_t value) { Board_PWM_SetDutyPercentage(HEATE2_PWM_CH, (value <= HUB_PWR_MAX) ? value : HUB_PWR_MAX); }
#endif // _USE_SOFT_HUB_HEATER_PWM_

static bool GetHubOffValue(void);

void HubForceClear() {
	Board_SetHubPump1(false);
	Board_SetHubPump2(true);
	Board_SetHubValve(true);
	
	SetPwrDuty(0);
	SetHubPwr1Value(0);
	SetHubPwr2Value(0);
}	
//-----------------------------------------------------------------------------

int get_hub_state(void) {
	return m_hubState;
}

uint32_t get_hub_time_left(void) {
	return m_hubCounter;
}

void hub_poll(void) {
	uint8_t duty = 0;
	
	SetHubState(m_hubState);
	SetHubLocalCounter(m_localCounter);
#ifdef USE_HUB_HEATER_ON_T2_T3
	SetHubSelectPeriod(2);
#else
	SetHubSelectPeriod(3);
#endif // USE_HUB_HEATER_ON_T2_T3
	
	//if((Params.FPGA_OUT.FPGA_Flags & FLAG_HUB_OFF)) { // || (GetHubOffValue())) {
	if(GetHubOffValue()) {
		Board_SetHubPump2(false);
		Board_SetHubPump1(false);
		Board_SetHubValve(false);
		
		m_localCounter = 0;
		m_localCounterStartTime = GetSystemTime();
		m_hubCounter = 0;
		m_hubCounterStartTime = GetSystemTime();
		m_hubPeriod = GetHubPeriod();
		
		m_hubState = StOff;
		SetPwrDuty(0);
		m_flags.IsCheckResultEn = 0;
		
		SetHubPwr1Value(0);
		SetHubPwr2Value(0);
		
		return;
	}
	
	//m_hubCounter++;
	m_hubCounter = GetSystemTime() - m_hubCounterStartTime;
	m_localCounter = GetSystemTime() - m_localCounterStartTime;
	

	switch(m_hubState) {
		case StOff:
			m_hubState = StT1;
			break;
		case StT1:
			
			// m_localCounter++;
			if(m_localCounter >= GetT1Time()) {
				m_localCounter = 0;
				m_localCounterStartTime = GetSystemTime();
				m_hubState = StT2;
				m_flags.IsCheckResultEn = 1;
			}
		
			if(IsHubFlagsForceClean()) {
				HubForceClear();
				break;
			}
			//
			Board_SetHubPump1(true);
			Board_SetHubPump2(false);
			Board_SetHubValve(false);
		
			SetPwrDuty(0);
			SetHubPwr1Value(0);
			SetHubPwr2Value(0);
		
//			m_localCounter++;
//			if(m_localCounter < GetT1Time()) 
//				break;
//			
//			m_localCounter = 0;
//			m_hubState = StT2;
//			m_flags.IsCheckResultEn = 1;
			break;
		case StT2:
			
			// m_localCounter++;
			if(m_localCounter >= GetT2Time()) {
				m_localCounter = 0;
				m_localCounterStartTime = GetSystemTime();
				m_hubState = StT3;
				m_flags.IsCheckResultEn = 1;
			}
		
			if(IsHubFlagsForceClean()) {
				HubForceClear();
				break;
			}
			
			Board_SetHubPump1(false);
			Board_SetHubPump2(true);
			Board_SetHubValve(true);
		
#ifdef USE_HUB_HEATER_ON_T2_T3		
			duty = GetPwr1();
			SetPwrDuty(duty);
			SetHubPwr1Value(duty);
			SetHubPwr2Value(0);
#else
			SetPwrDuty(0);
			SetHubPwr1Value(0);
			SetHubPwr2Value(0);
#endif // USE_HUB_HEATER_ON_T2_T3	
		
//			m_localCounter++;
//			if(m_localCounter < GetT2Time()) 
//				break;
//			
//			m_localCounter = 0;
//			m_hubState = StT3;
			
			break;
		case StT3:
			
			// m_localCounter++;
			if(m_localCounter >= GetT3Time()) {
				m_localCounter = 0;
				m_localCounterStartTime = GetSystemTime();
				m_hubState = StT4;
				m_flags.IsCheckResultEn = 0;
			}
		
			if(IsHubFlagsForceClean()) {
				HubForceClear();
				break;
			}
		
			Board_SetHubPump1(false);
			Board_SetHubPump2(true);
			Board_SetHubValve(true);

#ifdef 	USE_HUB_HEATER_ON_T2_T3	
			duty = GetPwr2();
			SetPwrDuty(duty);
			SetHubPwr1Value(0);
			SetHubPwr2Value(duty);
#else
			duty = GetPwr1();
			SetPwrDuty(duty);
			SetHubPwr1Value(duty);
			SetHubPwr2Value(0);
#endif // USE_HUB_HEATER_ON_T2_T3	
		
//			m_localCounter++;
//			if(m_localCounter < GetT3Time()) 
//				break;
//			
//			m_localCounter = 0;
//			m_hubState = StT4;
			
			break;
		case StT4:
			
			// m_localCounter++;
			if(m_localCounter >= GetT4Time()) {
				m_localCounter = 0;
				m_localCounterStartTime = GetSystemTime();
				m_hubState = StT1;
				m_hubPeriod = GetHubPeriod();
				m_hubCounter = 0;
				m_hubCounterStartTime = GetSystemTime();
				m_flags.IsCheckResultEn = 0;
			}
		
			if(IsHubFlagsForceClean()) {
				HubForceClear();
				break;
			}
			
			Board_SetHubPump1(false);
			Board_SetHubPump2(true);
			Board_SetHubValve(true);

#ifdef USE_HUB_HEATER_ON_T2_T3
			SetPwrDuty(0);
			SetHubPwr1Value(0);
			SetHubPwr2Value(0);
#else		
			duty = GetPwr2();
			SetPwrDuty(duty);
			SetHubPwr1Value(0);
			SetHubPwr2Value(duty);
#endif // USE_HUB_HEATER_ON_T2_T3
			
//			m_localCounter++;
//			if(m_localCounter < GetT4Time()) 
//				break;
//			
//			m_localCounter = 0;
//			m_hubState = StT1;
//			m_hubPeriod = GetHubPeriod();
//			m_hubCounter = 0;
//			m_flags.IsCheckResultEn = 0;
			
			break;
		default:
			m_localCounter = 0;
			m_localCounterStartTime = GetSystemTime();
			m_hubCounter = 0;
			m_hubCounterStartTime = GetSystemTime();
			m_hubPeriod = GetHubPeriod();
			m_hubState = StT1;
			SetPwrDuty(0);
			break;
	}
}

void hub_set_t3(void) {
	m_hubState = StT3;
	m_localCounter = 0;
}

void hub_set_t4(void) {
	m_hubState = StT4;
	m_localCounter = 0;
}

#ifdef _USE_SOFT_HUB_HEATER_PWM_

void hub_set_pwm_value(bool value) {
	Board_SetHeater2(value);
}

void hub_heater_off(void) {
	if(m_hubPwrPwmData.lpSetValueFunc != NULL) {
		m_hubPwrPwmData.lpSetValueFunc(false);
	}
}

#else

void hub_heater_off(void) {
//	if(m_hubPwrPwmData.lpSetValueFunc != NULL) {
//		m_hubPwrPwmData.lpSetValueFunc(false);
//	}
	SetPwrDuty(0);
}

#endif // _USE_SOFT_HUB_HEATER_PWM_



bool GetHubOffValue(void) {
	bool en = true;
//	
//	if(Params.CPU_OUT.Device_Mode == MODE_FAILURE) {
//		m_hubFilterData.isInit = false;
//		return true;
//	}
//	
//	if((Params.CPU_OUT.Device_Mode == MODE_DETECT) ||
//	   (Params.CPU_OUT.Device_Mode == MODE_ALARM))
//		en = true;
//	
//	return !on_off_filter_run(&m_hubFilterData, en, HUB_START_DELAY, HUB_OFF_DELAY);
	
	if((Params.FPGA_OUT.FPGA_Flags & FLAG_HUB_OFF) != 0)
		return true;
	
	return !on_off_filter_run(&m_hubFilterData, en, HUB_START_DELAY, HUB_OFF_DELAY);
}

#endif // _USE_SIP1_DEVICE_

