//=============================================================================
//
//=============================================================================

#include "lpc1768_it.h"
#include <LPC17xx.H>
#include <project.h>
#include <board.h>
#include <heater1.h>
#include <buttons.h>
#include <soft_pwm.h>

//-------------------------------------------------------------------------
#ifdef _USE_SIP1_DEVICE_
	#include <hub.h>
	extern SwPwmData_t m_hubPwrPwmData;
#endif // _USE_SIP1_DEVICE_

extern volatile Flags_t m_flags;
extern int hv_fail;
extern HV_Packet_Struct HV_IN_Packet;
extern Params_Struct Params;
//-------------------------------------------------------------------------

void TIMER0_IRQHandler (void) {
		/*  Clear Interrupt */
	TIM_ClearIntPending(LPC_TIM0, TIM_MR0_INT);
	/* Code...*/
	
	heater1_soft_pwm_poll();
	
#ifdef _USE_SIP1_DEVICE_

	#ifdef _USE_SOFT_HUB_HEATER_PWM_	
		SoftPwmPoll(&m_hubPwrPwmData);
	#endif // _USE_SOFT_HUB_HEATER_PWM_
	hub_poll();
	
#endif // _USE_SIP1_DEVICE_
}

void SysTick_Handler(void) {
	Board_Tick();
}

void UART3_IRQHandler(void) {
	int stat_HV = HV_IIR & 0xF, in_byte;
	if (stat_HV == 4)
	{
		in_byte = HV_RBR;
		if (in_byte == 0xAC)
		{
			hv_fail = 0;
			HV_IN_Packet.Flags = HV_RBR;
			HV_IN_Packet.HV_Value = HV_RBR;
			HV_IN_Packet.HV_Value += (HV_RBR << 8);
			Params.CPU_OUT.HV_Value = HV_IN_Packet.HV_Value;
		}
	}
	if (stat_HV == 0xC)
	{
		in_byte = HV_RBR;
	}

	stat_HV = HV_LSR & 0x20;

	return;
}
