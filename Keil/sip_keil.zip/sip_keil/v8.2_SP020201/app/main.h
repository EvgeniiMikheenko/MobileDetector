

#ifndef _MAIN_H_
#define _MAIN_H_

//+#include<core_cm3.h>
#include <LPC17xx.H>
#include <math.H>
#include <stdio.h>
#include <stdbool.h>

//#include "clock-arch.h"
//#include "lpc17xx_systick.h"
//#include "timer.h"
//#include "uip.h"
//#include "uip_arp.h"
//#include "tapdev.h"
//#include "uip_sip.h"
#include "flash.h"
#include <md5_module.h>

#include "project.h"

#include <crc16.h>
#include <soft_pwm.h>
#include <average_filter.h>
#include <utils.h>
#include <ton_timer.h>

#include <pid.h>

#include "hub.h"
#include "ssp.h"
#include "buttons.h"
#include "app_timers.h"
#include "host.h"
#include "heater1.h"
#include "flow_in.h"
#include "flow_total.h"
#include "indicator.h"
#include "adc.h"
#include "fpga.h"
#include "../sip100/wave_analizer.h"

#include <stdint.h>

#include "lpc17xx_timer.h"
#include "lpc17xx_wdt.h"

long long Athm_Int = 0, Athm = 0;
int buzzer_counter = 0, buzzer_period;
long long pump_time;

int fpga_fail = 0;
int fail_counter = 0;
int	alarm_count = 0;
int main_peak_count = 0;
int blowing = 0;

#define HV_READY_FLAG 				(HV_IN_Packet.Flags & 0x4)
#define HV_ON_FLAG   				(HV_IN_Packet.Flags & 0x1)

#define SET_HV_ON     				hv_on = 1
#define SET_HV_OFF    				hv_on = 0

#define HV_FAIL_COUNT   			250
#define FPGA_FAIL_COUNT 			2000

//#define PUMP2_PWM           		0

//#define TEMP_INT_CONST  			400000

//#define TEMP_INT_MAX    			(TEMP_INT_CONST * 200)

#define MAX_T_ERROR 				100

#define MAX_F_ERROR 				500 /* (DIP_NOFLOWERROR ? 100000 : ( DIP_OLD_PUMP ? 500 : (1 ? 1500 : 200))) */
#define MAX_F_ERROR_DIV2			((MAX_F_ERROR) / 2)

#define PWM_HEATER_MAX 				256

#define BUZZER_PERIOD   			1000 //msec

#define  SIP1_BTN       			LPC_GPIO1->FIOPIN&(1<<10)
#define  SIP2_BTN       			LPC_GPIO1->FIOPIN&(1<<9)
#define  SIP3_BTN       			LPC_GPIO0->FIOPIN&(1<<15)
#define  POWER_BTN      			LPC_GPIO0->FIOPIN&(1<<14)

#define WAIT_SPI1 					while((LPC_SSP1->SR&0x10))
#define WAIT_SSP0_TX 				while((LPC_SSP0->SR&0x2))
#define WAIT_SPI0_RX 				while((LPC_SSP0->SR&0x2))

#define HV_READY        			(LPC_GPIO1->FIOPIN&(1<<26))
#define HV_IMPULSE      			((LPC_GPIO1->FIOPIN&(1<<29))>>29)
#define HV_POL          			(LPC_GPIO1->FIOPIN&(1<<28))

#define SET_HV_PIN_ON           	LPC_GPIO1->FIOSET=(1<<27)
#define SET_HV_PIN_OFF          	LPC_GPIO1->FIOCLR=(1<<27)

#define MB_MAX_INPUT_PARAMS 		64

#define MB_SENDPAUSE  				20
#define MB_RCVPAUSE   				20
#define MB_SL_TIMEOUT 				3000
#define MB_SLAVE_BUFSIZE 			1024
#define MB_SEND_MODE  				1
#define MB_RECEIVE_MODE 			0
#define UART_RDA  					0x4
#define UART_CTI  					0xC
#define UART_RLS  					0x6
#define UART_THRE  					0x2

#ifndef __WEBSERVER_H__
#define __WEBSERVER_H__

//#include "httpd.h"

void uip_appcall(void);

struct httpd_state
{
    unsigned char    timer;
    //  struct psock sin, sout;
    //  struct pt outputpt, scriptpt;
    char             inputbuf[50];
    char             filename[20];
    char             state;
    //  struct httpd_fs_file file;
    int              len;
    char           * scriptptr;
    int              scriptlen;

    unsigned short   count;
};

typedef struct httpd_state uip_tcp_appstate_t;
/* UIP_APPCALL: the name of the application function. This function
must return void and take no arguments (i.e., C type "void
appfunc(void)"). */
#ifndef UIP_APPCALL
#define UIP_APPCALL     uip_appcall
#endif

#endif /* __WEBSERVER_H__ */

bool 	IsManualMode(void);
int 	flash_restore(void);
void 	init_data(void);
void 	update_time(void);
void 	update_flags(void);
void 	check_params(void);
int 	detect_alarm(int oldStatus);
void 	test_alarm(bool isFound);
int 	test_flow(int status);
int 	test_temp1(int status);
void 	test_mode_ok(void);
void 	set_new_device_mode(int newMode);
bool 	CheckReperData(void);
void 	init_wave_data(void);
void 	blowDown_proc(bool isAlarm);

#endif // _MAIN_H_
