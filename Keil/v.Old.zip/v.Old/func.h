#include "main.h"
#include "main.c"
void LedControl();

void LedControl()
{
	if(LED_MODE_AUTO);
}